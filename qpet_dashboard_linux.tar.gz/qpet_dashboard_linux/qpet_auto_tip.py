#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""qpet_auto_tip.py — 自动打赏守护进程（按配置时刻自动向指定帖子打赏）

单进程守护，循环逻辑（与 qpet_auto_tournament.py 同构）：
  1. 读 data/auto_tip_config.json：enabled + tasks 列表
  2. 每个任务：{postId, amount, message, accounts, weekdays, times}
     - accounts 空=全部账号；否则只对指定账号
     - weekdays 空=每天；否则只在选中星期执行
     - times 每日北京时间点(可多个)
  3. 到点后对每个任务的每个账号执行打赏，结果写 tip_log + state

配置文件 data/auto_tip_config.json 格式：
    {
      "enabled": true,
      "tasks": [
        {
          "postId": "11232",
          "amount": 1,
          "message": "加油～",
          "accounts": ["不想睡"],       // 空=全部账号
          "weekdays": [1,2,3,4,5],      // 空=每天
          "times": ["08:00", "20:00"]
        }
      ]
    }

用法：python qpet_auto_tip.py              # 守护模式
      python qpet_auto_tip.py --once       # 只跑一轮后退出（测试用）
"""
import os
import sys
import json
import time
import random
import sqlite3
import argparse
from datetime import datetime, timezone, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qpet_tip import tip_post

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ACCOUNTS_FILE = os.path.join(BASE_DIR, "accounts.txt")
DATA_DIR = os.path.join(BASE_DIR, "data")
LOG_DIR = os.path.join(BASE_DIR, "logs")
DB_FILE = os.path.join(DATA_DIR, "farm.db")
STATE_FILE = os.path.join(DATA_DIR, "auto_tip_state.json")
CONFIG_FILE = os.path.join(DATA_DIR, "auto_tip_config.json")
PID_FILE = os.path.join(LOG_DIR, "auto_tip.pid")

BJ = timezone(timedelta(hours=8))

DEFAULT_CONFIG = {"enabled": True, "tasks": []}


# ---------------------------------------------------------------------------
# 账号 / 配置 / 状态 / pidfile
# ---------------------------------------------------------------------------
def read_accounts():
    accs = []
    if not os.path.exists(ACCOUNTS_FILE):
        return accs
    with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                accs.append((parts[0], parts[1]))
    return accs


def _norm_times(times):
    valid = []
    if isinstance(times, list):
        for t in times:
            s = str(t).strip()
            if ":" in s:
                h, m = s.split(":", 1)
                if h.isdigit() and m.isdigit():
                    valid.append(f"{int(h):02d}:{int(m):02d}")
    return sorted(set(valid)) or ["00:30"]


def _norm_weekdays(raw):
    out = []
    if isinstance(raw, list):
        for w in raw:
            try:
                w = int(w)
            except Exception:
                continue
            if w == 7:
                w = 0
            if 0 <= w <= 6 and w not in out:
                out.append(w)
    return sorted(out)  # 空=每天


def _norm_task(t):
    """规范化单个打赏任务。"""
    if not isinstance(t, dict):
        return None
    post_id = str(t.get("postId") or t.get("post_id") or "").strip()
    if not post_id:
        return None
    try:
        amount = int(t.get("amount", 0) or 0)
    except Exception:
        amount = 0
    if amount <= 0:
        return None
    return {
        "postId": post_id,
        "amount": amount,
        "message": str(t.get("message") or ""),
        "accounts": [str(a) for a in (t.get("accounts") or [])],
        "weekdays": _norm_weekdays(t.get("weekdays")),
        "times": _norm_times(t.get("times")),
    }


def load_config():
    cfg = dict(DEFAULT_CONFIG)
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                cfg.update(data)
    except Exception:
        pass
    cfg["enabled"] = bool(cfg.get("enabled", True))
    tasks = []
    if isinstance(cfg.get("tasks"), list):
        for t in cfg["tasks"]:
            nt = _norm_task(t)
            if nt:
                tasks.append(nt)
    cfg["tasks"] = tasks
    return cfg


def task_accounts(task):
    """返回任务实际要打赏的 [(user, pass), ...]：accounts 空=全部。"""
    all_accs = read_accounts()
    sel = task.get("accounts") or []
    if not sel:
        return all_accs
    selset = set(sel)
    return [(u, p) for u, p in all_accs if u in selset]


def write_state(state):
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        state["updated"] = int(time.time() * 1000)
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def write_pid():
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(PID_FILE, "w") as f:
            f.write(str(os.getpid()))
    except Exception:
        pass


def clear_pid():
    try:
        if os.path.exists(PID_FILE):
            os.remove(PID_FILE)
    except Exception:
        pass


def log(msg):
    ts = time.strftime("%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(os.path.join(LOG_DIR, "auto_tip.log"), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def db_tip_log(account, post_id, amount, message, success, detail):
    """记录到 tip_log（与面板打赏共用一张表）。"""
    try:
        con = sqlite3.connect(DB_FILE)
        con.execute(
            "INSERT INTO tip_log(account, ts, post_id, amount, message, success, detail) "
            "VALUES(?,?,?,?,?,?,?)",
            (account, int(time.time() * 1000), post_id, int(amount), message,
             1 if success else 0, detail))
        con.commit()
        con.close()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# 调度：合并所有任务的「选中星期 + 时刻」取最近一次
# ---------------------------------------------------------------------------
def seconds_until_next_run(cfg, now=None):
    """距离所有任务中最近的「命中星期 + 时刻」的秒数。带随机抖动。"""
    now = now or datetime.now(BJ)
    tasks = cfg.get("tasks") or []
    if not tasks:
        return 3600  # 无任务，1 小时后再查
    candidates = []
    for task in tasks:
        times = task.get("times") or ["00:30"]
        weekdays = task.get("weekdays") or []
        wdset = set(int(w) for w in weekdays) if weekdays else set(range(7))
        for day_offset in range(8):
            d = now + timedelta(days=day_offset)
            cfg_wd = 0 if d.weekday() == 6 else d.weekday() + 1
            if cfg_wd not in wdset:
                continue
            for t in times:
                h, m = t.split(":", 1)
                target = d.replace(hour=int(h), minute=int(m), second=0, microsecond=0)
                if target > now:
                    candidates.append(target)
    if not candidates:
        return 3600
    nxt = min(candidates)
    jitter = random.randint(0, 600)  # 0~10 分钟
    return max(60, int((nxt - now).total_seconds()) + jitter)


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------
def run_once(cfg):
    """对所有到期任务执行一轮打赏。返回汇总 dict。"""
    tasks = cfg.get("tasks") or []
    now = datetime.now(BJ)
    today_wd = 0 if now.weekday() == 6 else now.weekday() + 1
    results = []
    total_ok = 0
    total_fail = 0
    for idx, task in enumerate(tasks):
        # 只执行「命中今天星期」的任务（时刻由调度保证到期才跑）
        wdset = set(task.get("weekdays") or list(range(7)))
        if today_wd not in wdset:
            continue
        post_id = task["postId"]
        amount = task["amount"]
        message = task.get("message") or ""
        accs = task_accounts(task)
        log(f"任务#{idx+1} 帖子{post_id} 打赏{amount}经验 → {len(accs)} 账号")
        task_res = {"postId": post_id, "amount": amount, "message": message, "results": []}
        for user, pwd in accs:
            r = tip_post(user, pwd, post_id, amount, message)
            ok = bool(r.get("success"))
            detail = r.get("message") or ("成功" if ok else "失败")
            log(f"  [{user}] 帖子{post_id}: {detail}")
            db_tip_log(user, post_id, amount, message, ok, detail)
            task_res["results"].append({"account": user, "success": ok, "detail": detail})
            if ok:
                total_ok += 1
            else:
                total_fail += 1
            time.sleep(0.5)
        results.append(task_res)
        time.sleep(1)
    state = {
        "lastRun": now.strftime("%Y-%m-%d %H:%M:%S"),
        "tasks": results,
        "totalOk": total_ok,
        "totalFail": total_fail,
    }
    write_state(state)
    log(f"本轮完成：打赏成功 {total_ok} · 失败 {total_fail}")
    return state


def main():
    parser = argparse.ArgumentParser(description="QPet 自动打赏守护进程")
    parser.add_argument("--once", action="store_true", help="只跑一轮后退出（测试用）")
    args = parser.parse_args()

    write_pid()
    log(f"=== 自动打赏守护启动 (PID {os.getpid()}) ===")
    try:
        while True:
            cfg = load_config()
            if not cfg.get("enabled", True):
                log("配置已禁用(enabled=false)，1 小时后再查")
                if args.once:
                    break
                time.sleep(3600)
                continue
            if not cfg.get("tasks"):
                log("无打赏任务，1 小时后再查")
                if args.once:
                    break
                time.sleep(3600)
                continue
            try:
                run_once(cfg)
            except Exception as e:
                log(f"执行异常: {e}")
            if args.once:
                log("--once 模式，退出")
                break
            wait = seconds_until_next_run(cfg)
            log(f"下次执行：约 {wait/60:.0f} 分钟后")
            time.sleep(wait)
    finally:
        clear_pid()


if __name__ == "__main__":
    main()
