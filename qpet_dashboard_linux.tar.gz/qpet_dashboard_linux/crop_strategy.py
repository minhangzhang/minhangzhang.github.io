#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""crop_strategy.py — 种植策略（dashboard 与 daemon 共享同一份 crop_strategy.json）

策略 = 一组按「北京小时」生效的规则 + 可选的「按账号覆盖」：
    {"rules":[{"startHour":22,"endHour":24,"crop":"ghost_orchid"},
              {"startHour":0,"endHour":22,"crop":"vanilla"}],
     "fallback":"vanilla",
     "overrides": {
        "不想睡": {"rules":[...], "fallback":"vanilla"}
     }}

crop_now(account=None) 依据当前北京小时返回应种作物 key（vanilla / ghost_orchid）。
若 account 在 overrides 中，则用该账号自己的 rules/fallback，否则用全局默认。
"""
import os
import json
from datetime import datetime, timezone, timedelta

# 始终基于本文件所在目录定位策略文件，避免受进程 CWD 影响
FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "crop_strategy.json")

CROPS = {
    "vanilla":      {"name": "香荚兰", "growMin": 120, "emoji": "🌿"},
    "ghost_orchid": {"name": "幽灵兰", "growMin": 600, "emoji": "👻"},
}
DEFAULT_STRATEGY = {
    "rules": [
        {"startHour": 22, "endHour": 24, "crop": "ghost_orchid"},  # 22:00–24:00 幽灵兰(10h)
        {"startHour": 0,  "endHour": 22, "crop": "vanilla"},       # 00:00–22:00 香荚兰(2h)
    ],
    "fallback": "vanilla",
    "overrides": {},
}

BJ = timezone(timedelta(hours=8))


def load():
    """读取策略；文件不存在时写入默认策略并返回。确保 overrides 字段存在。"""
    if os.path.exists(FILE):
        try:
            with open(FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict) and "rules" in data:
                if not isinstance(data.get("overrides"), dict):
                    data["overrides"] = {}
                return data
        except Exception:
            pass
    save(DEFAULT_STRATEGY)
    return json.loads(json.dumps(DEFAULT_STRATEGY))


def _normalize_strategy(data):
    """规范化单个策略块（rules + fallback）。data 可能是全局策略或某账号 override。"""
    normalized = {"rules": [], "fallback": data.get("fallback", "vanilla")}
    for r in data.get("rules", []):
        try:
            sh = int(r["startHour"]); eh = int(r["endHour"]); crop = r["crop"]
        except Exception:
            continue
        if crop not in CROPS:
            continue
        normalized["rules"].append({
            "startHour": max(0, min(23, sh)),
            "endHour": max(1, min(24, eh)),
            "crop": crop,
        })
    return normalized


def save(data):
    """规范化并落盘（含按账号 overrides）。返回规范化后的策略。"""
    normalized = _normalize_strategy(data)
    # 按账号覆盖：规范化每个账号的 rules，过滤掉空规则的账号
    overrides = {}
    if isinstance(data.get("overrides"), dict):
        for acc, strat in data["overrides"].items():
            if not isinstance(strat, dict):
                continue
            ov = _normalize_strategy(strat)
            # 保留账号级 fallback；rules 为空也允许（仅靠 fallback 选种）
            overrides[acc] = ov
    normalized["overrides"] = overrides
    with open(FILE, "w", encoding="utf-8") as f:
        json.dump(normalized, f, ensure_ascii=False, indent=2)
    return normalized


def _resolve(strategy, account=None):
    """返回某账号实际生效的策略块（rules + fallback）。
    优先用 overrides[account]，否则用全局 rules/fallback。"""
    if account:
        ov = (strategy.get("overrides") or {}).get(account)
        if isinstance(ov, dict) and ("rules" in ov or "fallback" in ov):
            return ov
    return strategy


def crop_now(strategy=None, account=None):
    """返回当前北京小时应种的作物 key。
    若 account 在 overrides 中，则用该账号自己的 rules/fallback，否则用全局默认。"""
    strategy = strategy or load()
    eff = _resolve(strategy, account)
    h = datetime.now(BJ).hour
    for r in eff.get("rules", []):
        sh, eh = r["startHour"], r["endHour"]
        if sh <= eh:
            if sh <= h < eh:
                return r["crop"]
        else:  # 跨午夜区间兼容
            if h >= sh or h < eh:
                return r["crop"]
    return eff.get("fallback", "vanilla")


if __name__ == "__main__":
    s = load()
    print("当前策略:", json.dumps(s, ensure_ascii=False))
    print("此刻应种(全局):", CROPS[crop_now(s)]["name"])
    for acc in (s.get("overrides") or {}):
        print(f"此刻应种({acc}):", CROPS[crop_now(s, account=acc)]["name"])

# 别名，兼容旧调用方（dashboard_server 仍引用 load_strategy/save_strategy/strategy_crop_now）
load_strategy = load
save_strategy = save
strategy_crop_now = crop_now

