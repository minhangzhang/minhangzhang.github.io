#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""qpet_dashboard_server.py — QPet 农场多账号监控面板后端

零第三方依赖（仅标准库 http.server + sqlite3 + subprocess + threading）。
职责：
  1. 读取 accounts.txt 账号列表
  2. GET  /api/status  —— 聚合每个账号的农场数据 + daemon 进程状态（带缓存）
  3. POST /api/tip     —— 批量对指定帖子打赏（调用 qpet_tip.py，env 传凭据）
  4. POST /api/daemon  —— 批量 start / stop / restart 守护进程（Popen + pidfile 管理）
  5. GET  /api/history —— 从 SQLite 读取经验趋势 / 打赏记录 / daemon 事件
  6. 静态托管 dashboard/ 目录（index.html 等）
  7. 收菜信号触发快照：守护进程每轮收菜后写入 data/last_harvest 时间戳，
     面板轮询 /api/status 时检测到变化即写入一条 farm_snapshot（不再定时刷点）

数据库：data/farm.db
  farm_snapshot(id, account, ts, exp, level, harvestable, growing, empty)
  tip_log(id, account, ts, post_id, amount, message, success, detail)
  daemon_event(id, account, ts, event, detail)

依赖说明：农场数据 / 打赏子进程需要 requests + cryptography，
因此本服务应以「带依赖的 Python」启动（当前环境为系统 Python）。
子进程默认复用启动本服务的解释器 sys.executable。
"""
import os
import sys
import json
import time
import socket
import queue
import sqlite3
import threading
import subprocess
from datetime import datetime, timezone, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

# ---------------------------------------------------------------------------
# 路径与常量
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# 确保同目录下的 crop_strategy / qpet_farm_vip 等模块无论以何种 CWD 启动都能被导入
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

ACCOUNTS_FILE = os.path.join(BASE_DIR, "accounts.txt")
DATA_DIR = os.path.join(BASE_DIR, "data")
DB_FILE = os.path.join(DATA_DIR, "farm.db")
LOG_DIR = os.path.join(BASE_DIR, "logs")
STATIC_DIR = os.path.join(BASE_DIR, "dashboard")

FARM_HELPER = os.path.join(BASE_DIR, "farm_helper.py")
TIP_SCRIPT = os.path.join(BASE_DIR, "qpet_tip.py")
CHEST_SCRIPT = os.path.join(BASE_DIR, "qpet_chest.py")
BATTLE_SCRIPT = os.path.join(BASE_DIR, "qpet_battle.py")
TOURNAMENT_SCRIPT = os.path.join(BASE_DIR, "qpet_tournament.py")
DAEMON_SCRIPT = os.path.join(BASE_DIR, "qpet_farm_daemon.py")
AUTO_BATTLE_SCRIPT = os.path.join(BASE_DIR, "qpet_auto_battle.py")
AUTO_BATTLE_PIDFILE = os.path.join(LOG_DIR, "autobattle.pid")
AUTO_BATTLE_STATE = os.path.join(DATA_DIR, "autobattle_state.json")
AUTO_BATTLE_CONFIG = os.path.join(DATA_DIR, "autobattle_config.json")
AUTO_TOURNAMENT_SCRIPT = os.path.join(BASE_DIR, "qpet_auto_tournament.py")
AUTO_TOURNAMENT_PIDFILE = os.path.join(LOG_DIR, "auto_tournament.pid")
AUTO_TOURNAMENT_STATE = os.path.join(DATA_DIR, "auto_tournament_state.json")
AUTO_TOURNAMENT_CONFIG = os.path.join(DATA_DIR, "auto_tournament_config.json")
AUTO_TIP_SCRIPT = os.path.join(BASE_DIR, "qpet_auto_tip.py")
AUTO_TIP_PIDFILE = os.path.join(LOG_DIR, "auto_tip.pid")
AUTO_TIP_STATE = os.path.join(DATA_DIR, "auto_tip_state.json")
AUTO_TIP_CONFIG = os.path.join(DATA_DIR, "auto_tip_config.json")
AUCTION_SCRIPT = os.path.join(BASE_DIR, "qpet_auction.py")
AUCTION_PIDFILE = os.path.join(LOG_DIR, "auction.pid")
AUCTION_STATE = os.path.join(DATA_DIR, "auction_state.json")
AUCTION_CONFIG = os.path.join(DATA_DIR, "auction_config.json")
STRATEGY_FILE = os.path.join(BASE_DIR, "crop_strategy.json")     # 种植策略（与 daemon 共享）
HARVEST_SIGNAL = os.path.join(DATA_DIR, "last_harvest")          # 守护进程每轮收菜后写入时间戳

# --- 领地抢占 (多账号，每账号独立pidfile/state/log) ---
TERRITORY_SCRIPT = os.path.join(BASE_DIR, "qpet_territory_daemon.py")

PYTHON = os.environ.get("QPET_PYTHON", sys.executable)  # 子进程解释器（需含依赖）
PORT = int(os.environ.get("QPET_DASH_PORT", "8787"))

STATUS_CACHE_TTL = 3600         # /api/status 农场数据缓存秒数（1 小时，降低对网站请求）
SUBPROC_TIMEOUT = 40           # 单账号子进程超时

# 种植策略由共享模块 crop_strategy 提供（dashboard / daemon 共用同一份 crop_strategy.json）
from crop_strategy import CROPS, DEFAULT_STRATEGY, load_strategy, save_strategy, strategy_crop_now  # noqa: E402

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)

BJ = timezone(timedelta(hours=8))


def now_str():
    return datetime.now(BJ).strftime("%Y-%m-%d %H:%M:%S")


def now_ms():
    return int(time.time() * 1000)


# ---------------------------------------------------------------------------
# SQLite（每次操作开新连接，规避线程限制）
# ---------------------------------------------------------------------------
def db_init():
    con = sqlite3.connect(DB_FILE)
    cur = con.cursor()
    cur.executescript(
        """
        CREATE TABLE IF NOT EXISTS farm_snapshot(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            account TEXT NOT NULL,
            ts INTEGER NOT NULL,
            exp INTEGER, level INTEGER,
            harvestable INTEGER, growing INTEGER, empty INTEGER
        );
        CREATE INDEX IF NOT EXISTS idx_snap_acc_ts ON farm_snapshot(account, ts);

        CREATE TABLE IF NOT EXISTS tip_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            account TEXT NOT NULL,
            ts INTEGER NOT NULL,
            post_id TEXT, amount INTEGER, message TEXT,
            success INTEGER, detail TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_tip_ts ON tip_log(ts);

        CREATE TABLE IF NOT EXISTS daemon_event(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            account TEXT NOT NULL,
            ts INTEGER NOT NULL,
            event TEXT, detail TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_evt_ts ON daemon_event(ts);

        CREATE TABLE IF NOT EXISTS chest_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            account TEXT NOT NULL,
            ts INTEGER NOT NULL,
            reward TEXT, free INTEGER, skipped INTEGER, success INTEGER, detail TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_chest_ts ON chest_log(ts);

        CREATE TABLE IF NOT EXISTS battle_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            account TEXT NOT NULL,
            ts INTEGER NOT NULL,
            kind TEXT, done INTEGER, exp INTEGER, detail TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_battle_ts ON battle_log(ts);

        CREATE TABLE IF NOT EXISTS tournament_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            account TEXT NOT NULL,
            ts INTEGER NOT NULL,
            kind TEXT, success INTEGER, skipped INTEGER, detail TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_tour_ts ON tournament_log(ts);

        CREATE TABLE IF NOT EXISTS auction_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts INTEGER NOT NULL,
            account TEXT,
            item_id TEXT, item_name TEXT, price INTEGER, quantity INTEGER,
            success INTEGER, detail TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_auction_ts ON auction_log(ts);

        CREATE TABLE IF NOT EXISTS territory_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts INTEGER NOT NULL,
            event TEXT, map_name TEXT, slot_name TEXT,
            occupier TEXT, result TEXT, exp INTEGER, coins INTEGER, detail TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_territory_ts ON territory_log(ts);
        """
    )
    con.commit()
    con.close()


def db_exec(sql, params=()):
    con = sqlite3.connect(DB_FILE)
    cur = con.cursor()
    cur.execute(sql, params)
    con.commit()
    lastid = cur.lastrowid
    con.close()
    return lastid


def db_query(sql, params=()):
    con = sqlite3.connect(DB_FILE)
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute(sql, params)
    rows = [dict(r) for r in cur.fetchall()]
    con.close()
    return rows


# ---------------------------------------------------------------------------
# 账号读取
# ---------------------------------------------------------------------------
def read_accounts():
    """返回 [(user, pass), ...]。忽略注释与空行。"""
    return read_accounts_raw()


def account_map():
    return {u: p for u, p in read_accounts()}


# ---------------------------------------------------------------------------
# 种植策略相关函数（load_strategy / save_strategy / strategy_crop_now 见顶部 import）
# ---------------------------------------------------------------------------
def read_harvest_signal():
    """读取守护进程写入的最后收菜时间戳（ms），无则 0。"""
    try:
        with open(HARVEST_SIGNAL, "r") as f:
            return int(f.read().strip() or "0")
    except Exception:
        return 0


# ---------------------------------------------------------------------------
# 账号文件读写（accounts.txt：每行 "用户名 密码"，# 开头为注释）
# ---------------------------------------------------------------------------
def read_accounts_raw():
    """返回 [(user, pass), ...]，保留顺序；不忽略注释。"""
    out = []
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
            for line in f:
                s = line.strip()
                if not s or s.startswith("#"):
                    continue
                parts = s.split()
                if len(parts) >= 2:
                    out.append((parts[0], parts[1]))
    return out


def write_accounts(accs):
    """整体覆写 accounts.txt（保留文件头注释）。"""
    header = (
        "# QPet 农场账号配置\n"
        "# 格式: 每行一个账号，\"用户名 密码\" 用空格分隔\n"
        "# 以 # 开头的行为注释。账号管理面板会同步修改本文件。\n"
    )
    lines = [header]
    for u, p in accs:
        lines.append(f"{u} {p}\n")
    with open(ACCOUNTS_FILE, "w", encoding="utf-8") as f:
        f.write("".join(lines))


# ---------------------------------------------------------------------------
# 子进程调用：农场状态 / 打赏
# ---------------------------------------------------------------------------
def _run_py(script, args, env_extra, timeout=SUBPROC_TIMEOUT):
    env = os.environ.copy()
    env.update(env_extra)
    env["PYTHONIOENCODING"] = "utf-8"
    try:
        p = subprocess.run(
            [PYTHON, script, *args],
            capture_output=True, text=True, encoding="utf-8",
            env=env, timeout=timeout, cwd=BASE_DIR,
        )
        return p.returncode, p.stdout or "", p.stderr or ""
    except subprocess.TimeoutExpired:
        return -1, "", "子进程超时"
    except Exception as e:
        return -2, "", f"子进程异常: {e}"


def fetch_farm(user, pwd):
    """调用 farm_helper.py 拿农场原始 data。返回 dict 或 {'error':...}"""
    rc, out, err = _run_py(FARM_HELPER, [], {"QPET_USER": user, "QPET_PASSWORD": pwd})
    if rc != 0:
        # farm_helper 把错误写到 stderr
        msg = (err.strip().splitlines() or ["未知错误"])[-1]
        return {"error": msg}
    line = ""
    for ln in reversed(out.strip().splitlines()):
        ln = ln.strip()
        if ln.startswith("{"):
            line = ln
            break
    if not line:
        return {"error": "无有效农场数据"}
    try:
        return json.loads(line)
    except Exception as e:
        return {"error": f"解析失败: {e}"}


def summarize_farm(data):
    """把农场原始 data 归纳为面板需要的精简结构。"""
    slots = data.get("slots", []) or []
    harvestable = sum(1 for s in slots if s.get("canHarvest"))
    growing = sum(1 for s in slots if s.get("state") == "growing")
    empty = sum(1 for s in slots if s.get("state") == "empty")
    lvl = data.get("levelInfo", {}) or {}
    return {
        "exp": data.get("experience"),
        "level": data.get("level"),
        "levelName": lvl.get("levelName"),
        "progress": lvl.get("progress"),
        "isPremium": data.get("isPremium"),
        "unlockedSlots": data.get("unlockedSlots"),
        "harvestCountToday": data.get("harvestCountToday"),
        "todayHarvestExp": data.get("todayHarvestExp"),
        "todayTaskExp": data.get("todayTaskExp"),
        "harvestable": harvestable,
        "growing": growing,
        "empty": empty,
        "slots": [
            {
                "slotIndex": s.get("slotIndex"),
                "cropName": s.get("cropName"),
                "state": s.get("state"),
                "remainingMinutes": s.get("remainingMinutes"),
                "canHarvest": s.get("canHarvest"),
                "doubleExp": s.get("doubleExp"),
            }
            for s in slots
        ],
    }


def tip_account(user, pwd, post_id, amount, message):
    args = [str(post_id), str(amount)]
    if message:
        args.append(message)
    rc, out, err = _run_py(TIP_SCRIPT, args, {"QPET_USER": user, "QPET_PASSWORD": pwd})
    blob = (out + "\n" + err)
    success = "'success': True" in blob or '"success": true' in blob.lower()
    tip_id = None
    detail = (out.strip().splitlines() or [""])[-1]
    # 尝试解析 tipId
    try:
        for ln in out.strip().splitlines():
            ln = ln.strip()
            if ln.startswith("{"):
                d = eval(ln, {"__builtins__": {}}, {"True": True, "False": False, "None": None})
                if isinstance(d, dict):
                    detail = d.get("message", detail)
                    tip_id = (d.get("data") or {}).get("tipId")
                    success = bool(d.get("success"))
    except Exception:
        pass
    if not success and not detail:
        detail = (err.strip().splitlines() or ["失败"])[-1]
    return success, detail, tip_id


def chest_account(user, pwd, times=1):
    """开启典藏宝箱。times>1 为连开模式（消耗经验）。子进程 qpet_chest.py 输出一行 JSON。

    返回 (success, detail, reward, free, skipped, opened, spent)。
    """
    args = ["--times", str(times)] if times and int(times) > 1 else []
    rc, out, err = _run_py(CHEST_SCRIPT, args, {"QPET_USER": user, "QPET_PASSWORD": pwd})
    success, detail, reward, free, skipped, opened, spent = False, "无响应", "", 0, 0, 0, 0
    # 优先解析最后一行 JSON（qpet_chest.py 用 json.dumps 输出）
    for ln in reversed(out.strip().splitlines()):
        ln = ln.strip()
        if ln.startswith("{"):
            try:
                d = json.loads(ln)
            except Exception:
                continue
            if isinstance(d, dict):
                success = bool(d.get("success"))
                detail = d.get("detail", detail)
                reward = d.get("reward", "")
                free = 1 if d.get("free") else 0
                skipped = 1 if d.get("skipped") else 0
                opened = int(d.get("opened", 0) or 0)
                spent = int(d.get("spent", 0) or 0)
                break
    if not success and (not detail or detail == "无响应"):
        detail = (err.strip().splitlines() or ["开启失败"])[-1]
    return success, detail, reward, free, skipped, opened, spent


def battle_account(user, pwd, kind="quick", times=1):
    """执行快速乐斗/斗魂塔。子进程 qpet_battle.py 输出一行 JSON。

    kind: "quick"(快速乐斗,消耗体力) 或 "tower"(斗魂塔,用免费次数)。
    返回 (success, detail, done, exp)。
    """
    args = [kind, str(times)]
    # 快速乐斗连开有「战斗处理中」间隔，给足超时（每次约 2s 间隔）
    timeout = SUBPROC_TIMEOUT + max(0, int(times) - 1) * 3
    rc, out, err = _run_py(BATTLE_SCRIPT, args, {"QPET_USER": user, "QPET_PASSWORD": pwd}, timeout=timeout)
    success, detail, done, exp = False, "无响应", 0, 0
    for ln in reversed(out.strip().splitlines()):
        ln = ln.strip()
        if ln.startswith("{"):
            try:
                d = json.loads(ln)
            except Exception:
                continue
            if isinstance(d, dict):
                success = bool(d.get("success"))
                detail = d.get("detail", detail)
                done = int(d.get("done", 0) or 0)
                exp = int(d.get("expGained", 0) or 0)
                break
    if not success and (not detail or detail == "无响应"):
        detail = (err.strip().splitlines() or ["执行失败"])[-1]
    return success, detail, done, exp


def tournament_account(user, pwd, action="register", kind="wulin"):
    """报名/查询大会。子进程 qpet_tournament.py 输出一行 JSON。
    action: "register"(报名) 或 "status"(查状态)。
    kind: "wulin"(武林大会) 或 "rookie"(菜鸟大会)。仅 register 用到。
    返回 (success, detail, skipped)。
    """
    args = [action] if action == "status" else [action, kind]
    rc, out, err = _run_py(TOURNAMENT_SCRIPT, args, {"QPET_USER": user, "QPET_PASSWORD": pwd})
    success, detail, skipped = False, "无响应", 0
    for ln in reversed(out.strip().splitlines()):
        ln = ln.strip()
        if ln.startswith("{"):
            try:
                d = json.loads(ln)
            except Exception:
                continue
            if isinstance(d, dict):
                # status 动作返回的不是报名结果，单独处理
                if action == "status":
                    return d
                success = bool(d.get("success"))
                detail = d.get("detail", detail)
                skipped = 1 if d.get("skipped") else 0
                break
    if not success and (not detail or detail == "无响应"):
        detail = (err.strip().splitlines() or ["执行失败"])[-1]
    return success, detail, skipped


# ---------------------------------------------------------------------------
# Daemon 进程管理（Popen + pidfile，跨平台）
# ---------------------------------------------------------------------------
def _pidfile(user):
    safe = user.replace("/", "_").replace("\\", "_")
    return os.path.join(LOG_DIR, f"{safe}.pid")


def _logfile(user):
    safe = user.replace("/", "_").replace("\\", "_")
    return os.path.join(LOG_DIR, f"{safe}.log")


def pid_alive(pid):
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            out = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}", "/NH"],
                capture_output=True, text=True, timeout=8,
            )
            return str(pid) in (out.stdout or "")
        except Exception:
            return False
    else:
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False


def daemon_status(user):
    pf = _pidfile(user)
    if not os.path.exists(pf):
        return {"running": False, "pid": None}
    try:
        pid = int(open(pf).read().strip())
    except Exception:
        return {"running": False, "pid": None}
    if pid_alive(pid):
        return {"running": True, "pid": pid}
    # 残留 pidfile 清理
    try:
        os.remove(pf)
    except Exception:
        pass
    return {"running": False, "pid": None}


def daemon_start(user, pwd):
    st = daemon_status(user)
    if st["running"]:
        return False, f"已在运行 (PID {st['pid']})"
    env = os.environ.copy()
    env.update({"QPET_USER": user, "QPET_PASSWORD": pwd, "PYTHONIOENCODING": "utf-8"})
    logf = open(_logfile(user), "a", encoding="utf-8")
    kwargs = {}
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    else:
        kwargs["start_new_session"] = True
    p = subprocess.Popen(
        [PYTHON, "-u", DAEMON_SCRIPT],
        stdout=logf, stderr=subprocess.STDOUT, env=env, cwd=BASE_DIR, **kwargs
    )
    with open(_pidfile(user), "w") as f:
        f.write(str(p.pid))
    return True, f"已启动 (PID {p.pid})"


def daemon_stop(user):
    st = daemon_status(user)
    if not st["running"]:
        return False, "未在运行"
    pid = st["pid"]
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                           capture_output=True, timeout=10)
        else:
            os.kill(pid, 15)
    except Exception as e:
        return False, f"停止失败: {e}"
    try:
        os.remove(_pidfile(user))
    except Exception:
        pass
    return True, f"已停止 (PID {pid})"


# ---------------------------------------------------------------------------
# 领地抢占守护进程（单进程，单账号）
# ---------------------------------------------------------------------------
def _terr_pidfile(user):
    return os.path.join(LOG_DIR, f"territory_{user}.pid")

def _terr_statefile(user):
    return os.path.join(DATA_DIR, f"territory_state_{user}.json")

def _terr_logfile(user):
    return os.path.join(LOG_DIR, f"territory_log_{user}.jsonl")

def territory_status():
    """返回 {accounts: [{user, running, pid, state, recentLogs}], total_running}"""
    accs = read_accounts()
    result = []
    total_running = 0
    for user, _pwd in accs:
        running, pid = False, None
        pidfile = _terr_pidfile(user)
        if os.path.exists(pidfile):
            try:
                pid = int(open(pidfile).read().strip())
                running = pid_alive(pid)
            except Exception:
                running = False
        state = {}
        sf = _terr_statefile(user)
        try:
            if os.path.exists(sf):
                with open(sf, "r", encoding="utf-8") as f:
                    state = json.load(f)
        except Exception:
            state = {}
        recent_logs = []
        lf = _terr_logfile(user)
        try:
            if os.path.exists(lf):
                with open(lf, "r", encoding="utf-8") as f:
                    lines = f.readlines()
                for ln in lines[-10:]:
                    ln = ln.strip()
                    if ln:
                        recent_logs.append(ln)
        except Exception:
            pass
        if running:
            total_running += 1
        result.append({"user": user, "running": running, "pid": pid if running else None,
                        "state": state, "recentLogs": recent_logs})
    return {"accounts": result, "total_running": total_running}


def territory_start(user, pwd):
    # 检查是否已运行
    pidfile = _terr_pidfile(user)
    if os.path.exists(pidfile):
        try:
            old_pid = int(open(pidfile).read().strip())
            if pid_alive(old_pid):
                return False, f"{user} 已在运行 (PID {old_pid})"
        except Exception:
            pass
    env = os.environ.copy()
    env.update({"QPET_USER": user, "QPET_PASSWORD": pwd, "PYTHONIOENCODING": "utf-8"})
    logf = open(os.path.join(LOG_DIR, f"territory_daemon_{user}.log"), "a", encoding="utf-8")
    kwargs = {}
    if os.name != "nt":
        kwargs["start_new_session"] = True
    else:
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    p = subprocess.Popen(
        [PYTHON, "-u", TERRITORY_SCRIPT],
        stdout=logf, stderr=subprocess.STDOUT, env=env, cwd=BASE_DIR, **kwargs
    )
    with open(pidfile, "w") as f:
        f.write(str(p.pid))
    return True, f"{user} 已启动 (PID {p.pid})"


def territory_stop(user):
    pidfile = _terr_pidfile(user)
    pid = None
    if os.path.exists(pidfile):
        try:
            pid = int(open(pidfile).read().strip())
        except Exception:
            pass
    if not pid or not pid_alive(pid):
        try:
            os.remove(pidfile)
        except Exception:
            pass
        return False, f"{user} 未在运行"
    try:
        if os.name != "nt":
            os.kill(pid, 15)
        else:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], capture_output=True, timeout=10)
    except Exception as e:
        return False, f"{user} 停止失败: {e}"
    try:
        os.remove(pidfile)
    except Exception:
        pass
    return True, f"{user} 已停止 (PID {pid})"


def territory_stop_all():
    """停止所有运行中的领地daemon"""
    stopped = []
    accs = read_accounts()
    for user, _ in accs:
        done, msg = territory_stop(user)
        if done:
            stopped.append(user)
    return True, f"已停止 {len(stopped)} 个: {', '.join(stopped)}" if stopped else (False, "无运行中的实例")


def territory_read_logs(limit=50):
    """读取领地日志最近N条"""
    logs = []
    try:
        if os.path.exists(TERRITORY_LOG):
            with open(TERRITORY_LOG, "r", encoding="utf-8") as f:
                lines = f.readlines()
            for ln in lines[-limit:]:
                ln = ln.strip()
                if ln.startswith("{"):
                    try:
                        logs.append(json.loads(ln))
                    except Exception:
                        pass
                elif ln:
                    logs.append({"raw": ln})
    except Exception:
        pass
    return logs


# ---------------------------------------------------------------------------
# 自动乐斗守护进程（单进程，管理全部账号）
# ---------------------------------------------------------------------------
def autobattle_status():
    """返回 {running, pid, state}。state 为上次执行结果（读 data/autobattle_state.json）。"""
    running, pid = False, None
    if os.path.exists(AUTO_BATTLE_PIDFILE):
        try:
            pid = int(open(AUTO_BATTLE_PIDFILE).read().strip())
            running = pid_alive(pid)
        except Exception:
            running = False
    state = {}
    try:
        if os.path.exists(AUTO_BATTLE_STATE):
            with open(AUTO_BATTLE_STATE, "r", encoding="utf-8") as f:
                state = json.load(f)
    except Exception:
        state = {}
    return {"running": running, "pid": pid if running else None, "state": state}


def autobattle_start(quick=None):
    st = autobattle_status()
    if st["running"]:
        return False, f"已在运行 (PID {st['pid']})"
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    args = [PYTHON, "-u", AUTO_BATTLE_SCRIPT]
    if quick:
        args += ["--quick", str(quick)]
    kwargs = {}
    if os.name != "nt":
        kwargs["start_new_session"] = True
    else:
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    logf = open(os.path.join(LOG_DIR, "autobattle.log"), "a", encoding="utf-8")
    p = subprocess.Popen(args, stdout=logf, stderr=subprocess.STDOUT,
                         env=env, cwd=BASE_DIR, **kwargs)
    return True, f"已启动 (PID {p.pid})"


def autobattle_stop():
    st = autobattle_status()
    if not st["running"]:
        return False, "未在运行"
    pid = st["pid"]
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                           capture_output=True, timeout=10)
        else:
            os.kill(pid, 15)
    except Exception as e:
        return False, f"停止失败: {e}"
    try:
        os.remove(AUTO_BATTLE_PIDFILE)
    except Exception:
        pass
    return True, f"已停止 (PID {pid})"


_AUTO_BATTLE_DEFAULT_CFG = {"enabled": True, "accounts": [], "times": ["00:30"], "quick": None}


def autobattle_load_config():
    """读取自动乐斗配置。缺失返回默认。"""
    cfg = dict(_AUTO_BATTLE_DEFAULT_CFG)
    try:
        if os.path.exists(AUTO_BATTLE_CONFIG):
            with open(AUTO_BATTLE_CONFIG, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                cfg.update(data)
    except Exception:
        pass
    if not isinstance(cfg.get("accounts"), list):
        cfg["accounts"] = []
    if not isinstance(cfg.get("times"), list) or not cfg["times"]:
        cfg["times"] = ["00:30"]
    # 规范化时刻
    valid = []
    for t in cfg["times"]:
        s = str(t).strip()
        if ":" in s:
            h, m = s.split(":", 1)
            if h.isdigit() and m.isdigit():
                valid.append(f"{int(h):02d}:{int(m):02d}")
    cfg["times"] = sorted(set(valid)) or ["00:30"]
    return cfg


def autobattle_save_config(cfg):
    """规范化并保存配置。守护进程下一轮会自动重读。"""
    normalized = {
        "enabled": bool(cfg.get("enabled", True)),
        "accounts": [str(a) for a in (cfg.get("accounts") or [])],
        "times": cfg.get("times") or ["00:30"],
        "quick": cfg.get("quick"),
    }
    return _save_cfg_raw(normalized)


def _save_cfg_raw(cfg):
    """落盘并返回规范化后的配置。"""
    # 先规范化 times（同 load 逻辑）
    valid = []
    for t in cfg["times"]:
        s = str(t).strip()
        if ":" in s:
            h, m = s.split(":", 1)
            if h.isdigit() and m.isdigit():
                valid.append(f"{int(h):02d}:{int(m):02d}")
    cfg["times"] = sorted(set(valid)) or ["00:30"]
    cfg["quick"] = int(cfg["quick"]) if cfg.get("quick") else None
    with open(AUTO_BATTLE_CONFIG, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    return cfg


# ---------------------------------------------------------------------------
# 自动打赏守护进程（单进程，按时刻向指定帖子打赏）
# ---------------------------------------------------------------------------
def _read_state_json(path):
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def auto_tip_status():
    """返回 {running, pid, state}。"""
    running, pid = False, None
    if os.path.exists(AUTO_TIP_PIDFILE):
        try:
            pid = int(open(AUTO_TIP_PIDFILE).read().strip())
            running = pid_alive(pid)
        except Exception:
            running = False
    return {"running": running, "pid": pid if running else None,
            "state": _read_state_json(AUTO_TIP_STATE)}


def auto_tip_start():
    st = auto_tip_status()
    if st["running"]:
        return False, f"已在运行 (PID {st['pid']})"
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    kwargs = {}
    if os.name != "nt":
        kwargs["start_new_session"] = True
    else:
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    logf = open(os.path.join(LOG_DIR, "auto_tip.log"), "a", encoding="utf-8")
    p = subprocess.Popen([PYTHON, "-u", AUTO_TIP_SCRIPT],
                         stdout=logf, stderr=subprocess.STDOUT,
                         env=env, cwd=BASE_DIR, **kwargs)
    with open(AUTO_TIP_PIDFILE, "w") as f:
        f.write(str(p.pid))
    return True, f"已启动 (PID {p.pid})"


def auto_tip_stop():
    st = auto_tip_status()
    if not st["running"]:
        return False, "未在运行"
    pid = st["pid"]
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                           capture_output=True, timeout=10)
        else:
            os.kill(pid, 15)
    except Exception as e:
        return False, f"停止失败: {e}"
    try:
        os.remove(AUTO_TIP_PIDFILE)
    except Exception:
        pass
    return True, f"已停止 (PID {pid})"


def _norm_tip_task(t):
    """规范化单个打赏任务。返回 dict 或 None（无效）。"""
    if not isinstance(t, dict):
        return None
    post_id = str(t.get("postId") or t.get("post_id") or "").strip()
    if not post_id:
        return None
    try:
        amount = int(t.get("amount", 0) or 0)
    except Exception:
        amount = 0
    if amount <= 0:
        return None
    return {
        "postId": post_id,
        "amount": amount,
        "message": str(t.get("message") or ""),
        "accounts": [str(a) for a in (t.get("accounts") or [])],
        "weekdays": _norm_weekdays(t.get("weekdays")),
        "times": _norm_tip_times(t.get("times")),
    }


def _norm_tip_times(times):
    valid = []
    if isinstance(times, list):
        for t in times:
            s = str(t).strip()
            if ":" in s:
                h, m = s.split(":", 1)
                if h.isdigit() and m.isdigit():
                    valid.append(f"{int(h):02d}:{int(m):02d}")
    return sorted(set(valid)) or ["00:30"]


def auto_tip_load_config():
    """读取自动打赏配置。缺失返回默认。"""
    cfg = {"enabled": True, "tasks": []}
    try:
        if os.path.exists(AUTO_TIP_CONFIG):
            with open(AUTO_TIP_CONFIG, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                cfg.update(data)
    except Exception:
        pass
    cfg["enabled"] = bool(cfg.get("enabled", True))
    tasks = []
    if isinstance(cfg.get("tasks"), list):
        for t in cfg["tasks"]:
            nt = _norm_tip_task(t)
            if nt:
                tasks.append(nt)
    cfg["tasks"] = tasks
    return cfg


def auto_tip_save_config(cfg):
    """规范化并保存配置。守护进程下一轮会自动重读。"""
    tasks = []
    if isinstance(cfg.get("tasks"), list):
        for t in cfg["tasks"]:
            nt = _norm_tip_task(t)
            if nt:
                tasks.append(nt)
    normalized = {"enabled": bool(cfg.get("enabled", True)), "tasks": tasks}
    with open(AUTO_TIP_CONFIG, "w", encoding="utf-8") as f:
        json.dump(normalized, f, ensure_ascii=False, indent=2)
    return normalized


# ---------------------------------------------------------------------------
# 拍卖行监控守护进程（单进程，拉取技能书行情 + 命中限价自动购买）
# ---------------------------------------------------------------------------
def auction_status():
    """返回 {running, pid, state}。state 为上次行情快照（读 data/auction_state.json）。"""
    running, pid = False, None
    if os.path.exists(AUCTION_PIDFILE):
        try:
            pid = int(open(AUCTION_PIDFILE).read().strip())
            running = pid_alive(pid)
        except Exception:
            running = False
    state = {}
    try:
        if os.path.exists(AUCTION_STATE):
            with open(AUCTION_STATE, "r", encoding="utf-8") as f:
                state = json.load(f)
    except Exception:
        state = {}
    return {"running": running, "pid": pid if running else None, "state": state}


def auction_start():
    st = auction_status()
    if st["running"]:
        return False, f"已在运行 (PID {st['pid']})"
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    kwargs = {}
    if os.name != "nt":
        kwargs["start_new_session"] = True
    else:
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    logf = open(os.path.join(LOG_DIR, "auction.log"), "a", encoding="utf-8")
    p = subprocess.Popen([PYTHON, "-u", AUCTION_SCRIPT],
                         stdout=logf, stderr=subprocess.STDOUT,
                         env=env, cwd=BASE_DIR, **kwargs)
    with open(AUCTION_PIDFILE, "w") as f:
        f.write(str(p.pid))
    return True, f"已启动 (PID {p.pid})"


def auction_stop():
    st = auction_status()
    if not st["running"]:
        return False, "未在运行"
    pid = st["pid"]
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                           capture_output=True, timeout=10)
        else:
            os.kill(pid, 15)
    except Exception as e:
        return False, f"停止失败: {e}"
    try:
        os.remove(AUCTION_PIDFILE)
    except Exception:
        pass
    return True, f"已停止 (PID {pid})"


_AUCTION_DEFAULT_CFG = {
    "enabled": True, "intervalMin": 30, "activeRanges": ["00:00-23:59"],
    "buyer": "", "autoBuy": False, "limits": {},
}


def _norm_active_ranges(ranges):
    """规范化时段列表：["08:00-23:00", ...]，非法丢弃，空则全天。"""
    out = []
    if not isinstance(ranges, list):
        ranges = []
    for rng in ranges:
        s = str(rng).strip()
        if "-" not in s:
            continue
        a, b = s.split("-", 1)
        try:
            ah, am = a.strip().split(":")
            bh, bm = b.strip().split(":")
            ah, am, bh, bm = int(ah), int(am), int(bh), int(bm)
            if 0 <= ah < 24 and 0 <= am < 60 and 0 <= bh < 24 and 0 <= bm < 60:
                out.append(f"{ah:02d}:{am:02d}-{bh:02d}:{bm:02d}")
        except Exception:
            continue
    return out or ["00:00-23:59"]


def auction_load_config():
    """读取拍卖行监控配置。缺失返回默认。"""
    cfg = dict(_AUCTION_DEFAULT_CFG)
    try:
        if os.path.exists(AUCTION_CONFIG):
            with open(AUCTION_CONFIG, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                cfg.update(data)
    except Exception:
        pass
    try:
        cfg["intervalMin"] = max(5, int(cfg.get("intervalMin", 30) or 30))
    except Exception:
        cfg["intervalMin"] = 30
    cfg["activeRanges"] = _norm_active_ranges(cfg.get("activeRanges"))
    cfg["autoBuy"] = bool(cfg.get("autoBuy", False))
    cfg["buyer"] = str(cfg.get("buyer") or "")
    limits = cfg.get("limits")
    if not isinstance(limits, dict):
        limits = {}
    norm_limits = {}
    for k, v in limits.items():
        try:
            norm_limits[str(k)] = int(v)
        except Exception:
            continue
    cfg["limits"] = norm_limits
    return cfg


def auction_save_config(cfg):
    """规范化并保存拍卖行配置。守护进程下一轮会自动重读。"""
    normalized = {
        "enabled": bool(cfg.get("enabled", True)),
        "intervalMin": max(5, int(cfg.get("intervalMin", 30) or 30)),
        "activeRanges": _norm_active_ranges(cfg.get("activeRanges")),
        "buyer": str(cfg.get("buyer") or ""),
        "autoBuy": bool(cfg.get("autoBuy", False)),
    }
    limits = cfg.get("limits")
    if not isinstance(limits, dict):
        limits = {}
    norm_limits = {}
    for k, v in limits.items():
        try:
            norm_limits[str(k)] = int(v)
        except Exception:
            continue
    normalized["limits"] = norm_limits
    with open(AUCTION_CONFIG, "w", encoding="utf-8") as f:
        json.dump(normalized, f, ensure_ascii=False, indent=2)
    return normalized


def auction_buy_now(account, listing_id, item_id, item_name, price, quantity=1):
    """面板「立即购买」：用指定账号直接购买一个 listing（不走子进程，import 调用）。
    记录到 auction_log。返回 (success, detail)。"""
    amap = account_map()
    pwd = amap.get(account)
    if not pwd:
        return False, "买手账号不存在"
    try:
        import qpet_auction as _a
    except Exception as e:
        return False, f"加载拍卖模块失败: {e}"
    from qpet_farm_vip import login as _login
    token, pk = _login(account, pwd)
    if not token:
        return False, "登录失败"
    import time as _t
    _t.sleep(0.3)
    b = _a.buy_one(token, pk, listing_id)
    ok = bool(b.get("success"))
    db_exec(
        "INSERT INTO auction_log(ts, account, item_id, item_name, price, quantity, success, detail) "
        "VALUES(?,?,?,?,?,?,?,?)",
        (now_ms(), account, item_id, item_name, int(price or 0), int(quantity or 1),
         1 if ok else 0, b.get("detail", "")))
    return ok, b.get("detail", "")


def auction_get_reference_price(token, pk, item_type, item_id):
    """查市场参考价（同物品最低售价）。接收已登录的 token/pk 避免重复登录。
    无在售返回 None。"""
    from qpet_farm_vip import signed_request as _sr
    r = _sr(token, pk, "GET", "/qpet/auction/listings", query={
        "itemType": item_type,
        "itemId": item_id,
        "page": 1,
        "pageSize": 5,
        "sortBy": "price",
        "order": "ASC",
    })
    if not r.get("success"):
        return None
    ls = (r.get("data") or {}).get("listings") or []
    if not ls:
        return None
    prices = []
    for it in ls:
        try:
            prices.append(int(it.get("price") or 0))
        except Exception:
            continue
    return min(prices) if prices else None


def auction_get_inventory(account):
    """查指定账号背包，返回可上架物品列表（含每物品参考价）。
    返回 {success, items:[{item_type,item_id,item_name,quantity,reference_price}]} 或 {success, error}。"""
    amap = account_map()
    pwd = amap.get(account)
    if not pwd:
        return {"success": False, "error": "账号不存在"}
    try:
        from qpet_farm_vip import login as _login, signed_request as _sr
    except Exception as e:
        return {"success": False, "error": f"加载拍卖模块失败: {e}"}
    token, pk = _login(account, pwd)
    if not token:
        return {"success": False, "error": "登录失败"}
    time.sleep(0.3)
    r = _sr(token, pk, "GET", "/qpet/inventory")
    if not r.get("success"):
        return {"success": False, "error": r.get("message", "查询背包失败")}
    items_raw = (r.get("data") or {}).get("items") or []
    items = []
    for it in items_raw:
        itype = it.get("item_type")
        iid = it.get("item_id")
        iname = it.get("item_name") or ""
        try:
            qty = int(it.get("quantity") or 0)
        except Exception:
            qty = 0
        try:
            ref = auction_get_reference_price(token, pk, itype, iid)
        except Exception:
            ref = None
        items.append({
            "item_type": itype,
            "item_id": iid,
            "item_name": iname,
            "quantity": qty,
            "reference_price": ref,
        })
        time.sleep(0.1)  # 避免请求过快被限流
    return {"success": True, "items": items}


def auction_get_my_listings(account):
    """查指定账号在售列表（仅 active 状态）。返回 {success, listings:[...]}。"""
    amap = account_map()
    pwd = amap.get(account)
    if not pwd:
        return {"success": False, "error": "账号不存在"}
    try:
        from qpet_farm_vip import login as _login, signed_request as _sr
    except Exception as e:
        return {"success": False, "error": f"加载拍卖模块失败: {e}"}
    token, pk = _login(account, pwd)
    if not token:
        return {"success": False, "error": "登录失败"}
    time.sleep(0.3)
    r = _sr(token, pk, "GET", "/qpet/auction/my-listings")
    if not r.get("success"):
        return {"success": False, "error": r.get("message", "查询在售失败")}
    all_listings = (r.get("data") or {}).get("listings") or []
    # 只返回 active 状态的，过滤掉 sold/cancelled/expired
    active = [l for l in all_listings if l.get("status") == "active"]
    return {"success": True, "listings": active}


def auction_sell_item(account, item_type, item_id, item_name, quantity, price):
    """上架物品到拍卖行。记录到 auction_log。返回 (success, detail)。"""
    amap = account_map()
    pwd = amap.get(account)
    if not pwd:
        return False, "账号不存在"
    try:
        from qpet_farm_vip import login as _login, signed_request as _sr
    except Exception as e:
        return False, f"加载拍卖模块失败: {e}"
    import uuid as _uuid
    token, pk = _login(account, pwd)
    if not token:
        return False, "登录失败"
    time.sleep(0.3)
    try:
        quantity = int(quantity)
        price = int(price)
    except Exception:
        return False, "数量或价格非法"
    if quantity <= 0:
        return False, "数量必须 > 0"
    if price <= 0:
        return False, "价格必须 > 0"
    body = {
        "itemType": item_type,
        "itemId": item_id,
        "quantity": quantity,
        "price": price,
        "clientRequestId": f"qpet-auction-list-{_uuid.uuid4()}",
    }
    r = _sr(token, pk, "POST", "/qpet/auction/list", body)
    ok = bool(r.get("success"))
    detail = "上架成功" if ok else ("上架失败: " + str(r.get("message", "")))
    db_exec(
        "INSERT INTO auction_log(ts, account, item_id, item_name, price, quantity, success, detail) "
        "VALUES(?,?,?,?,?,?,?,?)",
        (now_ms(), account, str(item_id), item_name or "", price, quantity,
         1 if ok else 0, detail))
    return ok, detail


def auction_cancel_listing(account, listing_id, item_name=""):
    """下架物品。记录到 auction_log。返回 (success, detail)。"""
    amap = account_map()
    pwd = amap.get(account)
    if not pwd:
        return False, "账号不存在"
    try:
        from qpet_farm_vip import login as _login, signed_request as _sr
    except Exception as e:
        return False, f"加载拍卖模块失败: {e}"
    import uuid as _uuid
    token, pk = _login(account, pwd)
    if not token:
        return False, "登录失败"
    time.sleep(0.3)
    body = {
        "listingId": listing_id,
        "clientRequestId": f"qpet-auction-cancel-{_uuid.uuid4()}",
    }
    r = _sr(token, pk, "POST", "/qpet/auction/cancel", body)
    ok = bool(r.get("success"))
    detail = "下架成功" if ok else ("下架失败: " + str(r.get("message", "")))
    db_exec(
        "INSERT INTO auction_log(ts, account, item_id, item_name, price, quantity, success, detail) "
        "VALUES(?,?,?,?,?,?,?,?)",
        (now_ms(), account, str(listing_id), item_name or "", 0, 0,
         1 if ok else 0, detail))
    return ok, detail


def auction_cancel_expired(account):
    """一键下架所有过期商品。返回 (success, detail, cancelled_count)。"""
    amap = account_map()
    pwd = amap.get(account)
    if not pwd:
        return False, "账号不存在", 0
    try:
        from qpet_farm_vip import login as _login, signed_request as _sr
    except Exception as e:
        return False, f"加载拍卖模块失败: {e}", 0
    import uuid as _uuid
    token, pk = _login(account, pwd)
    if not token:
        return False, "登录失败", 0
    time.sleep(0.3)
    body = {
        "clientRequestId": f"qpet-auction-cancel-expired-{_uuid.uuid4()}",
    }
    r = _sr(token, pk, "POST", "/qpet/auction/cancel-expired", body)
    ok = bool(r.get("success"))
    data = r.get("data") or {}
    cancelled = int(data.get("cancelled", 0) or 0)
    if ok:
        detail = f"已下架 {cancelled} 件过期商品" if cancelled else "当前没有过期商品"
    else:
        detail = "一键下架失败: " + str(r.get("message", ""))
    db_exec(
        "INSERT INTO auction_log(ts, account, item_id, item_name, price, quantity, success, detail) "
        "VALUES(?,?,?,?,?,?,?,?)",
        (now_ms(), account, "cancel-expired", "一键下架过期", 0, cancelled,
         1 if ok else 0, detail))
    return ok, detail, cancelled


# ---------------------------------------------------------------------------
# 大会自动报名守护进程（单进程，按每日时刻自动报名武林/菜鸟）
# ---------------------------------------------------------------------------
def auto_tournament_status():
    """返回 {running, pid, state}。state 为上次执行结果（读 data/auto_tournament_state.json）。"""
    running, pid = False, None
    if os.path.exists(AUTO_TOURNAMENT_PIDFILE):
        try:
            pid = int(open(AUTO_TOURNAMENT_PIDFILE).read().strip())
            running = pid_alive(pid)
        except Exception:
            running = False
    state = {}
    try:
        if os.path.exists(AUTO_TOURNAMENT_STATE):
            with open(AUTO_TOURNAMENT_STATE, "r", encoding="utf-8") as f:
                state = json.load(f)
    except Exception:
        state = {}
    return {"running": running, "pid": pid if running else None, "state": state}


def auto_tournament_start():
    st = auto_tournament_status()
    if st["running"]:
        return False, f"已在运行 (PID {st['pid']})"
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    kwargs = {}
    if os.name != "nt":
        kwargs["start_new_session"] = True
    else:
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    logf = open(os.path.join(LOG_DIR, "auto_tournament.log"), "a", encoding="utf-8")
    p = subprocess.Popen([PYTHON, "-u", AUTO_TOURNAMENT_SCRIPT],
                         stdout=logf, stderr=subprocess.STDOUT,
                         env=env, cwd=BASE_DIR, **kwargs)
    with open(AUTO_TOURNAMENT_PIDFILE, "w") as f:
        f.write(str(p.pid))
    return True, f"已启动 (PID {p.pid})"


def auto_tournament_stop():
    st = auto_tournament_status()
    if not st["running"]:
        return False, "未在运行"
    pid = st["pid"]
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                           capture_output=True, timeout=10)
        else:
            os.kill(pid, 15)
    except Exception as e:
        return False, f"停止失败: {e}"
    try:
        os.remove(AUTO_TOURNAMENT_PIDFILE)
    except Exception:
        pass
    return True, f"已停止 (PID {pid})"


_AUTO_TOURNAMENT_DEFAULT_CFG = {
    "enabled": True, "accounts": [], "times": ["00:30"],
    "weekdays": [1, 2, 3, 4, 5], "kinds": ["wulin", "rookie"],
}


def _norm_weekdays(raw):
    """规范化星期列表：0-6（0=周日）。7 视作周日(0)。空=每天（返回 []）。"""
    out = []
    if isinstance(raw, list):
        for w in raw:
            try:
                w = int(w)
            except Exception:
                continue
            if w == 7:
                w = 0
            if 0 <= w <= 6 and w not in out:
                out.append(w)
    return sorted(out)


def auto_tournament_load_config():
    """读取大会自动报名配置。缺失返回默认。"""
    cfg = dict(_AUTO_TOURNAMENT_DEFAULT_CFG)
    try:
        if os.path.exists(AUTO_TOURNAMENT_CONFIG):
            with open(AUTO_TOURNAMENT_CONFIG, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                cfg.update(data)
    except Exception:
        pass
    if not isinstance(cfg.get("accounts"), list):
        cfg["accounts"] = []
    if not isinstance(cfg.get("times"), list) or not cfg["times"]:
        cfg["times"] = ["00:30"]
    valid = []
    for t in cfg["times"]:
        s = str(t).strip()
        if ":" in s:
            h, m = s.split(":", 1)
            if h.isdigit() and m.isdigit():
                valid.append(f"{int(h):02d}:{int(m):02d}")
    cfg["times"] = sorted(set(valid)) or ["00:30"]
    cfg["weekdays"] = _norm_weekdays(cfg.get("weekdays"))
    kinds = []
    if isinstance(cfg.get("kinds"), list):
        for k in cfg["kinds"]:
            if k in ("wulin", "rookie") and k not in kinds:
                kinds.append(k)
    cfg["kinds"] = kinds or ["wulin", "rookie"]
    return cfg


def auto_tournament_save_config(cfg):
    """规范化并保存配置。守护进程下一轮会自动重读。"""
    times = cfg.get("times") or ["00:30"]
    valid = []
    for t in times:
        s = str(t).strip()
        if ":" in s:
            h, m = s.split(":", 1)
            if h.isdigit() and m.isdigit():
                valid.append(f"{int(h):02d}:{int(m):02d}")
    kinds = []
    if isinstance(cfg.get("kinds"), list):
        for k in cfg["kinds"]:
            if k in ("wulin", "rookie") and k not in kinds:
                kinds.append(k)
    normalized = {
        "enabled": bool(cfg.get("enabled", True)),
        "accounts": [str(a) for a in (cfg.get("accounts") or [])],
        "times": sorted(set(valid)) or ["00:30"],
        "weekdays": _norm_weekdays(cfg.get("weekdays")),
        "kinds": kinds or ["wulin", "rookie"],
    }
    with open(AUTO_TOURNAMENT_CONFIG, "w", encoding="utf-8") as f:
        json.dump(normalized, f, ensure_ascii=False, indent=2)
    return normalized


# ---------------------------------------------------------------------------
# 状态缓存
# ---------------------------------------------------------------------------
_status_cache = {"ts": 0, "data": None, "_last_harvest": read_harvest_signal()}
_status_lock = threading.Lock()


def build_status(force=False):
    with _status_lock:
        if not force and _status_cache["data"] and (time.time() - _status_cache["ts"] < STATUS_CACHE_TTL):
            return _status_cache["data"]

    accounts = read_accounts()
    result = []

    # farm 数据并发抓取
    q = queue.Queue()

    def worker(u, p):
        farm = fetch_farm(u, p)
        q.put((u, farm))

    threads = []
    for u, p in accounts:
        t = threading.Thread(target=worker, args=(u, p), daemon=True)
        t.start()
        threads.append(t)
    for t in threads:
        t.join(timeout=SUBPROC_TIMEOUT + 5)

    farms = {}
    while not q.empty():
        u, farm = q.get()
        farms[u] = farm

    for u, p in accounts:
        farm = farms.get(u, {"error": "无响应"})
        ds = daemon_status(u)
        if "error" in farm:
            result.append({
                "account": u, "ok": False, "error": farm["error"],
                "daemon": ds,
            })
        else:
            s = summarize_farm(farm)
            s.update({"account": u, "ok": True, "daemon": ds})
            result.append(s)

    payload = {"serverTime": now_str(), "accounts": result, "strategy": load_strategy()}
    # 收菜信号触发快照（仅在确有关键信号时落库一条）
    maybe_snapshot_on_harvest()
    with _status_lock:
        _status_cache["ts"] = time.time()
        _status_cache["data"] = payload
    return payload


# ---------------------------------------------------------------------------
# 快照：仅在「收菜」时触发（由守护进程写 last_harvest 信号驱动），不再定时
# ---------------------------------------------------------------------------
def snapshot_once():
    accounts = read_accounts()
    ts = now_ms()
    for u, p in accounts:
        farm = fetch_farm(u, p)
        if "error" in farm:
            continue
        s = summarize_farm(farm)
        db_exec(
            "INSERT INTO farm_snapshot(account, ts, exp, level, harvestable, growing, empty) "
            "VALUES(?,?,?,?,?,?,?)",
            (u, ts, s.get("exp"), s.get("level"), s.get("harvestable"),
             s.get("growing"), s.get("empty")),
        )


def maybe_snapshot_on_harvest():
    """每次 build_status 调用时检查收菜信号；若自上次以来有收菜则快照一次。"""
    sig = read_harvest_signal()
    last = _status_cache.get("_last_harvest", 0)
    if sig and sig > last:
        try:
            snapshot_once()
        except Exception as e:
            print(f"[snapshot] 异常: {e}", flush=True)
        _status_cache["_last_harvest"] = sig


# ---------------------------------------------------------------------------
# HTTP Handler
# ---------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "QPetDash/1.0"

    def log_message(self, fmt, *args):
        # 精简日志
        sys.stderr.write(f"[{now_str()}] {self.address_string()} {fmt % args}\n")

    # ---- 工具 ----
    def _send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self):
        length = int(self.headers.get("Content-Length", 0) or 0)
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    def _serve_static(self, path):
        if path in ("/", ""):
            path = "/index.html"
        rel = path.lstrip("/")
        target = os.path.normpath(os.path.join(STATIC_DIR, rel))
        if not target.startswith(STATIC_DIR):
            self._send_json({"error": "非法路径"}, 403)
            return
        if not os.path.isfile(target):
            self._send_json({"error": "未找到", "path": path}, 404)
            return
        ctype = {
            ".html": "text/html; charset=utf-8",
            ".js": "application/javascript; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".svg": "image/svg+xml",
            ".json": "application/json; charset=utf-8",
        }.get(os.path.splitext(target)[1], "application/octet-stream")
        with open(target, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")  # 避免浏览器缓存旧版 index.html
        self.end_headers()
        self.wfile.write(data)

    # ---- GET ----
    def do_GET(self):
        u = urlparse(self.path)
        path = u.path
        if path == "/api/status":
            force = parse_qs(u.query).get("force", ["0"])[0] == "1"
            try:
                self._send_json(build_status(force=force))
            except Exception as e:
                self._send_json({"error": str(e)}, 500)
            return
        if path == "/api/history":
            self._handle_history(parse_qs(u.query))
            return
        if path == "/api/accounts":
            self._send_json({"accounts": [u for u, _ in read_accounts()]})
            return
        if path == "/api/strategy":
            self._send_json({"strategy": load_strategy(), "crops": CROPS})
            return
        if path == "/api/autobattle":
            self._send_json(autobattle_status())
            return
        if path == "/api/autobattle-config":
            self._send_json({"config": autobattle_load_config()})
            return
        if path == "/api/auction":
            self._send_json(auction_status())
            return
        if path == "/api/auction-config":
            self._send_json({"config": auction_load_config()})
            return
        if path == "/api/auction-log":
            self._handle_auction_log(parse_qs(u.query))
            return
        if path == "/api/auto-tournament":
            self._send_json(auto_tournament_status())
            return
        if path == "/api/auto-tournament-config":
            self._send_json({"config": auto_tournament_load_config()})
            return
        if path == "/api/auto-tip":
            self._send_json(auto_tip_status())
            return
        if path == "/api/auto-tip-config":
            self._send_json({"config": auto_tip_load_config()})
            return
        if path == "/api/tournament":
            self._handle_tournament(parse_qs(u.query))
            return
        if path == "/api/server-info":
            self._send_json({"port": PORT, "lan": lan_ips()})
            return
        if path == "/api/territory":
            self._send_json(territory_status())
            return
        if path == "/api/territory-logs":
            self._send_json({"logs": territory_read_logs(100)})
            return
        if path == "/api/auction-inventory":
            self._handle_auction_inventory(parse_qs(u.query))
            return
        if path == "/api/auction-my-listings":
            self._handle_auction_my_listings(parse_qs(u.query))
            return
        if path == "/api/accounts":
            accs = [{"user": u, "daemon": daemon_status(u)} for u, _ in read_accounts()]
            self._send_json({"accounts": accs})
            return
        self._serve_static(path)

    def _handle_history(self, qs):
        account = (qs.get("account", [""])[0]) or None
        hours = int(qs.get("hours", ["24"])[0])
        since = now_ms() - hours * 3600 * 1000

        if account:
            snaps = db_query(
                "SELECT ts, exp, level, harvestable, growing, empty FROM farm_snapshot "
                "WHERE account=? AND ts>=? ORDER BY ts ASC", (account, since))
        else:
            snaps = db_query(
                "SELECT ts, exp, level, harvestable, growing, empty, account FROM farm_snapshot "
                "WHERE ts>=? ORDER BY ts ASC", (since,))

        tips = db_query(
            "SELECT account, ts, post_id, amount, message, success, detail FROM tip_log "
            "ORDER BY ts DESC LIMIT 100")
        events = db_query(
            "SELECT account, ts, event, detail FROM daemon_event "
            "ORDER BY ts DESC LIMIT 100")
        chests = db_query(
            "SELECT account, ts, reward, free, skipped, success, detail FROM chest_log "
            "ORDER BY ts DESC LIMIT 100")
        battles = db_query(
            "SELECT account, ts, kind, done, exp, detail FROM battle_log "
            "ORDER BY ts DESC LIMIT 100")
        tournaments = db_query(
            "SELECT account, ts, kind, success, skipped, detail FROM tournament_log "
            "ORDER BY ts DESC LIMIT 100")
        auctions = db_query(
            "SELECT ts, account, item_id, item_name, price, quantity, success, detail "
            "FROM auction_log ORDER BY ts DESC LIMIT 100")

        # 按账号分组趋势
        trend = {}
        for r in snaps:
            acc = r.get("account", account)
            trend.setdefault(acc, []).append(
                {"ts": r["ts"], "exp": r["exp"], "harvestable": r["harvestable"],
                 "growing": r["growing"], "empty": r["empty"]})

        self._send_json({"trend": trend, "tips": tips, "events": events,
                         "chests": chests, "battles": battles, "tournaments": tournaments,
                         "auctions": auctions})

    # ---- POST ----
    def do_POST(self):
        u = urlparse(self.path)
        path = u.path
        body = self._read_body()
        if path == "/api/tip":
            self._handle_tip(body)
            return
        if path == "/api/chest":
            self._handle_chest(body)
            return
        if path == "/api/battle":
            self._handle_battle(body)
            return
        if path == "/api/autobattle":
            self._handle_autobattle(body)
            return
        if path == "/api/autobattle-config":
            self._handle_autobattle_config(body)
            return
        if path == "/api/auction":
            self._handle_auction(body)
            return
        if path == "/api/auction-config":
            self._handle_auction_config(body)
            return
        if path == "/api/auto-tournament":
            self._handle_auto_tournament(body)
            return
        if path == "/api/auto-tournament-config":
            self._handle_auto_tournament_config(body)
            return
        if path == "/api/auto-tip":
            self._handle_auto_tip(body)
            return
        if path == "/api/auto-tip-config":
            self._handle_auto_tip_config(body)
            return
        if path == "/api/tournament":
            self._handle_tournament_post(body)
            return
        if path == "/api/daemon":
            self._handle_daemon(body)
            return
        if path == "/api/snapshot":
            try:
                snapshot_once()
                self._send_json({"success": True})
            except Exception as e:
                self._send_json({"success": False, "error": str(e)}, 500)
            return
        if path == "/api/strategy":
            self._handle_strategy(body)
            return
        if path == "/api/territory":
            self._handle_territory(body)
            return
        if path == "/api/accounts":
            self._handle_accounts(body)
            return
        if path == "/api/auction-sell":
            self._handle_auction_sell(body)
            return
        if path == "/api/auction-cancel":
            self._handle_auction_cancel(body)
            return
        if path == "/api/auction-cancel-expired":
            self._handle_auction_cancel_expired(body)
            return
        self._send_json({"error": "未知接口"}, 404)

    def _handle_tip(self, body):
        post_id = str(body.get("postId") or body.get("post_id") or "").strip()
        amount = body.get("amount")
        message = body.get("message") or ""
        targets = body.get("accounts") or []  # 空 = 全部
        if not post_id or not amount:
            self._send_json({"success": False, "error": "缺少 postId 或 amount"}, 400)
            return
        amap = account_map()
        if not targets:
            targets = list(amap.keys())
        results = []
        ok = 0
        for user in targets:
            pwd = amap.get(user)
            if not pwd:
                results.append({"account": user, "success": False, "detail": "账号不存在"})
                continue
            success, detail, tip_id = tip_account(user, pwd, post_id, amount, message)
            if success:
                ok += 1
            db_exec(
                "INSERT INTO tip_log(account, ts, post_id, amount, message, success, detail) "
                "VALUES(?,?,?,?,?,?,?)",
                (user, now_ms(), post_id, int(amount), message, 1 if success else 0, detail))
            results.append({"account": user, "success": success, "detail": detail, "tipId": tip_id})
        self._send_json({"success": ok > 0, "ok": ok, "total": len(targets), "results": results})

    def _handle_chest(self, body):
        targets = body.get("accounts") or []  # 空 = 全部
        times = int(body.get("times") or 1)   # >1 = 连开模式（消耗经验）
        amap = account_map()
        if not targets:
            targets = list(amap.keys())
        results = []
        ok = 0          # 开启成功（含免费开启）
        opened = 0      # 实际开启了（非跳过）；连开模式下为各账号实际开的次数之和
        skipped = 0     # 今日免费已用，跳过
        spent = 0       # 连开模式累计消耗经验
        for user in targets:
            pwd = amap.get(user)
            if not pwd:
                results.append({"account": user, "success": False, "detail": "账号不存在"})
                continue
            success, detail, reward, free, skip, op, sp = chest_account(user, pwd, times)
            if success:
                ok += 1
                if skip:
                    skipped += 1
                else:
                    opened += (op or 1)
                    spent += sp
            db_exec(
                "INSERT INTO chest_log(account, ts, reward, free, skipped, success, detail) "
                "VALUES(?,?,?,?,?,?,?)",
                (user, now_ms(), reward, free, skip, 1 if success else 0, detail))
            results.append({"account": user, "success": success, "skipped": bool(skip),
                            "opened": (op or (0 if skip else 1)), "spent": sp,
                            "reward": reward, "detail": detail})
        # 宝箱状态变化后使状态缓存失效
        with _status_lock:
            _status_cache["ts"] = 0
        self._send_json({"success": ok > 0, "ok": ok, "opened": opened, "skipped": skipped,
                         "spent": spent, "total": len(targets), "results": results})

    def _handle_battle(self, body):
        kind = (body.get("kind") or "quick").lower()  # quick / tower
        times = int(body.get("times") or (1 if kind == "quick" else 6))
        targets = body.get("accounts") or []  # 空 = 全部
        if kind not in ("quick", "tower"):
            self._send_json({"success": False, "error": "kind 需为 quick 或 tower"}, 400)
            return
        amap = account_map()
        if not targets:
            targets = list(amap.keys())
        results = []
        done_total = 0      # 各账号实际次数之和
        exp_total = 0
        for user in targets:
            pwd = amap.get(user)
            if not pwd:
                results.append({"account": user, "success": False, "detail": "账号不存在"})
                continue
            success, detail, done, exp = battle_account(user, pwd, kind, times)
            if success:
                done_total += done
                exp_total += exp
            db_exec(
                "INSERT INTO battle_log(account, ts, kind, done, exp, detail) VALUES(?,?,?,?,?,?)",
                (user, now_ms(), kind, done, exp, detail))
            results.append({"account": user, "success": success, "done": done,
                            "exp": exp, "detail": detail})
        # 经验变化后失效状态缓存
        with _status_lock:
            _status_cache["ts"] = 0
        self._send_json({"success": any(r.get("success") for r in results),
                         "done": done_total, "exp": exp_total,
                         "total": len(targets), "results": results})

    def _handle_tournament(self, query):
        """GET /api/tournament：查全部账号两个大会报名状态（不接参数，避免中文账号编码问题）。"""
        amap = account_map()
        results = []
        for user, pwd in read_accounts():
            d = tournament_account(user, pwd, action="status")
            results.append({"account": user, "success": bool(d.get("success")),
                            "wulin": d.get("wulin"), "rookie": d.get("rookie")})
        self._send_json({"success": True, "results": results})

    def _handle_tournament_post(self, body):
        """POST /api/tournament：批量报名。{kind, accounts}"""
        kind = (body.get("kind") or "wulin").lower()  # wulin / rookie
        if kind not in ("wulin", "rookie"):
            self._send_json({"success": False, "error": "kind 需为 wulin 或 rookie"}, 400)
            return
        targets = body.get("accounts") or []  # 空=全部
        amap = account_map()
        if not targets:
            targets = list(amap.keys())
        results = []
        ok = 0
        skipped = 0
        for user in targets:
            pwd = amap.get(user)
            if not pwd:
                results.append({"account": user, "success": False, "detail": "账号不存在"})
                continue
            success, detail, skip = tournament_account(user, pwd, "register", kind)
            if success:
                ok += 1
                if skip:
                    skipped += 1
            db_exec(
                "INSERT INTO tournament_log(account, ts, kind, success, skipped, detail) VALUES(?,?,?,?,?,?)",
                (user, now_ms(), kind, 1 if success else 0, skip, detail))
            results.append({"account": user, "success": success, "skipped": bool(skip), "detail": detail})
        self._send_json({"success": ok > 0, "ok": ok, "skipped": skipped,
                         "total": len(targets), "results": results})

    def _handle_autobattle(self, body):
        action = (body.get("action") or "").lower()  # start / stop / status
        quick = body.get("quick")  # 可选：每次快速乐斗上限
        if action == "start":
            done, msg = autobattle_start(quick)
            self._send_json({"success": done, "detail": msg, "status": autobattle_status()})
        elif action == "stop":
            done, msg = autobattle_stop()
            self._send_json({"success": done, "detail": msg, "status": autobattle_status()})
        else:
            self._send_json({"success": True, "status": autobattle_status()})

    def _handle_autobattle_config(self, body):
        # POST 保存配置（body 即配置）；GET 已在 do_GET 返回
        if not isinstance(body, dict):
            self._send_json({"success": False, "error": "配置格式错误"}, 400)
            return
        try:
            saved = autobattle_save_config(body)
        except Exception as e:
            self._send_json({"success": False, "error": str(e)}, 500)
            return
        self._send_json({"success": True, "config": saved})

    def _handle_auction(self, body):
        """POST /api/auction：{action:"start"|"stop"|"buy"}。
        buy: {listingId, account, itemId, itemName, price, quantity} 立即购买。"""
        action = (body.get("action") or "").lower()
        if action == "start":
            done, msg = auction_start()
            self._send_json({"success": done, "detail": msg, "status": auction_status()})
        elif action == "stop":
            done, msg = auction_stop()
            self._send_json({"success": done, "detail": msg, "status": auction_status()})
        elif action == "buy":
            listing_id = body.get("listingId")
            account = (body.get("account") or "").strip()
            if not listing_id or not account:
                self._send_json({"success": False, "error": "缺少 listingId 或 account"}, 400)
                return
            ok, detail = auction_buy_now(account, listing_id, body.get("itemId"),
                                         body.get("itemName"), body.get("price"),
                                         body.get("quantity", 1))
            self._send_json({"success": ok, "detail": detail})
        else:
            self._send_json({"success": True, "status": auction_status()})

    def _handle_auction_config(self, body):
        """POST /api/auction-config：保存监控配置（body 即配置）。"""
        if not isinstance(body, dict):
            self._send_json({"success": False, "error": "配置格式错误"}, 400)
            return
        try:
            saved = auction_save_config(body)
        except Exception as e:
            self._send_json({"success": False, "error": str(e)}, 500)
            return
        self._send_json({"success": True, "config": saved})

    def _handle_auction_log(self, qs):
        """GET /api/auction-log：返回最近买入记录（默认 100 条）。"""
        limit = int(qs.get("limit", ["100"])[0] or 100)
        rows = db_query(
            "SELECT ts, account, item_id, item_name, price, quantity, success, detail "
            "FROM auction_log ORDER BY ts DESC LIMIT ?", (limit,))
        self._send_json({"success": True, "logs": rows})

    def _handle_auction_inventory(self, qs):
        """GET /api/auction-inventory?account=X：返回指定账号背包 + 每物品参考价。"""
        account = (qs.get("account", [""])[0] or "").strip()
        if not account:
            self._send_json({"success": False, "error": "缺少 account"}, 400)
            return
        try:
            res = auction_get_inventory(account)
        except Exception as e:
            self._send_json({"success": False, "error": str(e)}, 500)
            return
        self._send_json(res)

    def _handle_auction_my_listings(self, qs):
        """GET /api/auction-my-listings?account=X：返回指定账号在售列表。"""
        account = (qs.get("account", [""])[0] or "").strip()
        if not account:
            self._send_json({"success": False, "error": "缺少 account"}, 400)
            return
        try:
            res = auction_get_my_listings(account)
        except Exception as e:
            self._send_json({"success": False, "error": str(e)}, 500)
            return
        self._send_json(res)

    def _handle_auction_sell(self, body):
        """POST /api/auction-sell：{account, itemType, itemId, itemName, quantity, price}。"""
        account = (body.get("account") or "").strip()
        item_type = body.get("itemType")
        item_id = body.get("itemId")
        item_name = body.get("itemName") or ""
        quantity = body.get("quantity")
        price = body.get("price")
        if not account:
            self._send_json({"success": False, "error": "缺少 account"}, 400)
            return
        if not item_type or not item_id:
            self._send_json({"success": False, "error": "缺少 itemType 或 itemId"}, 400)
            return
        try:
            ok, detail = auction_sell_item(account, item_type, item_id,
                                           item_name, quantity, price)
        except Exception as e:
            self._send_json({"success": False, "error": str(e)}, 500)
            return
        self._send_json({"success": ok, "detail": detail})

    def _handle_auction_cancel(self, body):
        """POST /api/auction-cancel：{account, listingId, itemName}。"""
        account = (body.get("account") or "").strip()
        listing_id = body.get("listingId")
        item_name = body.get("itemName") or ""
        if not account or not listing_id:
            self._send_json({"success": False, "error": "缺少 account 或 listingId"}, 400)
            return
        try:
            ok, detail = auction_cancel_listing(account, listing_id, item_name)
        except Exception as e:
            self._send_json({"success": False, "error": str(e)}, 500)
            return
        self._send_json({"success": ok, "detail": detail})

    def _handle_auction_cancel_expired(self, body):
        """POST /api/auction-cancel-expired：{account}。一键下架所有过期商品。"""
        account = (body.get("account") or "").strip()
        if not account:
            self._send_json({"success": False, "error": "缺少 account"}, 400)
            return
        try:
            ok, detail, cancelled = auction_cancel_expired(account)
        except Exception as e:
            self._send_json({"success": False, "error": str(e)}, 500)
            return
        self._send_json({"success": ok, "detail": detail, "cancelled": cancelled})

    def _handle_auto_tournament(self, body):
        """POST /api/auto-tournament：{action:"start"|"stop"|"status"}。"""
        action = (body.get("action") or "").lower()
        if action == "start":
            done, msg = auto_tournament_start()
            self._send_json({"success": done, "detail": msg, "status": auto_tournament_status()})
        elif action == "stop":
            done, msg = auto_tournament_stop()
            self._send_json({"success": done, "detail": msg, "status": auto_tournament_status()})
        else:
            self._send_json({"success": True, "status": auto_tournament_status()})

    def _handle_auto_tournament_config(self, body):
        """POST /api/auto-tournament-config：保存配置（body 即配置）。"""
        if not isinstance(body, dict):
            self._send_json({"success": False, "error": "配置格式错误"}, 400)
            return
        try:
            saved = auto_tournament_save_config(body)
        except Exception as e:
            self._send_json({"success": False, "error": str(e)}, 500)
            return
        self._send_json({"success": True, "config": saved})

    def _handle_auto_tip(self, body):
        """POST /api/auto-tip：{action:"start"|"stop"|"status"}。"""
        action = (body.get("action") or "").lower()
        if action == "start":
            done, msg = auto_tip_start()
            self._send_json({"success": done, "detail": msg, "status": auto_tip_status()})
        elif action == "stop":
            done, msg = auto_tip_stop()
            self._send_json({"success": done, "detail": msg, "status": auto_tip_status()})
        else:
            self._send_json({"success": True, "status": auto_tip_status()})

    def _handle_auto_tip_config(self, body):
        """POST /api/auto-tip-config：保存打赏任务配置（body 即配置）。"""
        if not isinstance(body, dict):
            self._send_json({"success": False, "error": "配置格式错误"}, 400)
            return
        try:
            saved = auto_tip_save_config(body)
        except Exception as e:
            self._send_json({"success": False, "error": str(e)}, 500)
            return
        self._send_json({"success": True, "config": saved})

    def _handle_daemon(self, body):
        action = (body.get("action") or "").lower()
        targets = body.get("accounts") or []
        amap = account_map()
        if not targets:
            targets = list(amap.keys())
        if action not in ("start", "stop", "restart"):
            self._send_json({"success": False, "error": "action 必须为 start/stop/restart"}, 400)
            return
        results = []
        for user in targets:
            pwd = amap.get(user, "")
            if action == "start":
                done, msg = daemon_start(user, pwd)
            elif action == "stop":
                done, msg = daemon_stop(user)
            else:
                daemon_stop(user)
                time.sleep(0.6)
                done, msg = daemon_start(user, pwd)
            db_exec(
                "INSERT INTO daemon_event(account, ts, event, detail) VALUES(?,?,?,?)",
                (user, now_ms(), action, msg))
            results.append({"account": user, "success": done, "detail": msg})
        # daemon 变化后使状态缓存失效
        with _status_lock:
            _status_cache["ts"] = 0
        self._send_json({"success": True, "results": results})

    def _handle_strategy(self, body):
        if not isinstance(body, dict) or "rules" not in body:
            self._send_json({"success": False, "error": "body 需含 rules 数组"}, 400)
            return
        try:
            normalized = save_strategy(body)
        except Exception as e:
            self._send_json({"success": False, "error": str(e)}, 500)
            return
        # 使策略缓存失效（下次 build_status 会带上新策略）
        with _status_lock:
            _status_cache["ts"] = 0
        self._send_json({"success": True, "strategy": normalized})

    def _handle_accounts(self, body):
        action = (body.get("action") or "").lower()
        if action == "test":
            user = (body.get("user") or "").strip()
            pwd = body.get("password") or ""
            if not user or not pwd:
                self._send_json({"success": False, "error": "缺少 user/password"}, 400)
                return
            # 直接打登录接口验证凭据（不依赖 ~/.qpet_keys 会话缓存，结果最权威）
            try:
                import urllib.request as _ur, ssl as _ssl
                req = _ur.Request(
                    "https://api.duanwuqiufenmao.top/api/auth/login",
                    data=json.dumps({"username": user, "password": pwd}).encode(),
                    headers={"Content-Type": "application/json"}, method="POST")
                raw = _ur.urlopen(req, timeout=20, context=_ssl._create_unverified_context()).read().decode()
                d = json.loads(raw)
                if d.get("success"):
                    self._send_json({"success": True, "username": (d.get("data") or {}).get("user", {}).get("username", user)})
                else:
                    self._send_json({"success": False, "error": d.get("message", "登录失败")})
            except Exception as e:
                self._send_json({"success": False, "error": "登录失败：" + str(e)})
            return

        if action in ("add", "update", "remove"):
            user = (body.get("user") or "").strip()
            if not user:
                self._send_json({"success": False, "error": "缺少 user"}, 400)
                return
            accs = read_accounts()
            idx = next((i for i, (u, _) in enumerate(accs) if u == user), None)
            if action == "add":
                if idx is not None:
                    self._send_json({"success": False, "error": "账号已存在"}, 409)
                    return
                pwd = body.get("password") or ""
                if not pwd:
                    self._send_json({"success": False, "error": "缺少 password"}, 400)
                    return
                accs.append((user, pwd))
            elif action == "update":
                if idx is None:
                    self._send_json({"success": False, "error": "账号不存在"}, 404)
                    return
                pwd = body.get("password") or ""
                if not pwd:
                    self._send_json({"success": False, "error": "缺少 password"}, 400)
                    return
                accs[idx] = (user, pwd)
            else:  # remove
                if idx is None:
                    self._send_json({"success": False, "error": "账号不存在"}, 404)
                    return
                accs.pop(idx)
            try:
                write_accounts(accs)
            except Exception as e:
                self._send_json({"success": False, "error": str(e)}, 500)
                return
            # 使状态缓存失效（账号集合变化）
            with _status_lock:
                _status_cache["ts"] = 0
            result = [{"user": u, "daemon": daemon_status(u)} for u, _ in accs]
            self._send_json({"success": True, "accounts": result})
            return
        self._send_json({"success": False, "error": "action 须为 add/update/remove/test"}, 400)

    def _handle_territory(self, body):
        """POST /api/territory: {action: start|stop|stopall, account}"""
        action = (body.get("action") or "").lower()
        if action == "start":
            user = body.get("account") or ""
            amap = account_map()
            pwd = amap.get(user)
            if not pwd:
                accs = read_accounts()
                if accs:
                    user, pwd = accs[-1]
                else:
                    self._send_json({"success": False, "error": "无可用账号"})
                    return
            done, msg = territory_start(user, pwd)
            self._send_json({"success": done, "detail": msg, "status": territory_status()})
        elif action == "stop":
            user = body.get("account") or ""
            if not user:
                self._send_json({"success": False, "error": "需要指定 account"})
                return
            done, msg = territory_stop(user)
            self._send_json({"success": done, "detail": msg, "status": territory_status()})
        elif action == "stopall":
            done, msg = territory_stop_all()
            self._send_json({"success": done, "detail": msg, "status": territory_status()})
        else:
            self._send_json({"success": False, "error": "action 须为 start/stop/stopall"}, 400)


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
def lan_ips():
    """探测本机局域网 IPv4 地址（用于展示给同网段设备访问）。"""
    ips = []
    try:
        # 优先：建一个到外网的 UDP socket，读其本端地址（不发包，最准）
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ips.append(s.getsockname()[0])
        finally:
            s.close()
    except Exception:
        pass
    # 兜底：解析主机名
    try:
        host = socket.gethostbyname(socket.gethostname())
        if host and not host.startswith("127.") and host not in ips:
            ips.append(host)
    except Exception:
        pass
    return ips


def main():
    db_init()
    if not os.path.exists(STATIC_DIR):
        os.makedirs(STATIC_DIR, exist_ok=True)
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    print(f"[{now_str()}] QPet 监控面板已启动", flush=True)
    print(f"  本机访问 → http://127.0.0.1:{PORT}", flush=True)
    for ip in lan_ips():
        print(f"  局域网访问 → http://{ip}:{PORT}  （同 WiFi/网段设备可用）", flush=True)
    print(f"  解释器: {PYTHON}", flush=True)
    print(f"  账号数: {len(read_accounts())}  数据库: {DB_FILE}", flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止", flush=True)
        srv.shutdown()


if __name__ == "__main__":
    main()
