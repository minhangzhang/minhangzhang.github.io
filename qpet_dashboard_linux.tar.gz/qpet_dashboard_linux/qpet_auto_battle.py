#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""qpet_auto_battle.py — 自动乐斗守护进程（按配置的每日时刻自动执行）

单进程守护，循环逻辑：
  1. 读 data/autobattle_config.json：参与账号 + 每日执行时刻(可多个)
  2. 到点后对每个参与账号：
     - 快速乐斗打光体力
     - 斗魂塔打满 6 次免费
     - 世界Boss参战一次（拿参与经验，伤害由服务端按真实战力计算）
  3. 写汇总到 data/autobattle_state.json（供面板展示）
  4. 等待到下一个配置时刻

配置文件 data/autobattle_config.json 格式：
    {
      "enabled": true,
      "accounts": ["不想睡", "2377331212@qq.com"],   // 空数组=全部账号
      "times": ["00:30", "12:00", "20:00"],          // 每日北京时间点(可多个)
      "quick": null                                    // 每次快速乐斗上限(空=打光体力)
    }

用法：python qpet_auto_battle.py              # 守护模式，按配置时刻循环
      python qpet_auto_battle.py --once       # 只跑一轮后退出（测试用）
"""
import os
import sys
import json
import time
import argparse
from datetime import datetime, timezone, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qpet_battle import quick_battle, tower_battle, world_boss_fight

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ACCOUNTS_FILE = os.path.join(BASE_DIR, "accounts.txt")
DATA_DIR = os.path.join(BASE_DIR, "data")
LOG_DIR = os.path.join(BASE_DIR, "logs")
STATE_FILE = os.path.join(DATA_DIR, "autobattle_state.json")
CONFIG_FILE = os.path.join(DATA_DIR, "autobattle_config.json")
PID_FILE = os.path.join(LOG_DIR, "autobattle.pid")

BJ = timezone(timedelta(hours=8))
TOWER_FREE_DAILY = 6

DEFAULT_CONFIG = {
    "enabled": True,
    "accounts": [],          # 空=全部账号
    "times": ["00:30"],      # 默认每日 00:30
    "quick": None,           # None=打光体力
}


def read_accounts():
    """返回 [(user, pass), ...]，跳过注释/空行。"""
    accs = []
    if not os.path.exists(ACCOUNTS_FILE):
        return accs
    with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                accs.append((parts[0], parts[1]))
    return accs


def load_config():
    """读取 autobattle_config.json。缺失时返回默认配置。"""
    cfg = dict(DEFAULT_CONFIG)
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                cfg.update(data)
    except Exception:
        pass
    # 规范化
    if not isinstance(cfg.get("accounts"), list):
        cfg["accounts"] = []
    if not isinstance(cfg.get("times"), list):
        cfg["times"] = ["00:30"]
    # 过滤无效时刻，排序去重
    valid = []
    for t in cfg["times"]:
        s = str(t).strip()
        if ":" in s:
            h, m = s.split(":", 1)
            if h.isdigit() and m.isdigit():
                valid.append(f"{int(h):02d}:{int(m):02d}")
    cfg["times"] = sorted(set(valid)) or ["00:30"]
    return cfg


def selected_accounts(cfg):
    """根据配置返回 [(user, pass), ...]：配置 accounts 为空则全部，否则取交集。"""
    all_accs = read_accounts()
    sel = cfg.get("accounts") or []
    if not sel:
        return all_accs
    selset = set(sel)
    return [(u, p) for u, p in all_accs if u in selset]


def write_state(state):
    """写入状态文件供面板读取。"""
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        state["updated"] = int(time.time() * 1000)
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def write_pid():
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(PID_FILE, "w") as f:
            f.write(str(os.getpid()))
    except Exception:
        pass


def clear_pid():
    try:
        if os.path.exists(PID_FILE):
            os.remove(PID_FILE)
    except Exception:
        pass


def log(user, msg):
    ts = time.strftime("%m-%d %H:%M:%S")
    line = f"[{ts}] {('['+user+'] ') if user else ''}{msg}"
    print(line, flush=True)
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(os.path.join(LOG_DIR, "autobattle.log"), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def seconds_until_next_run(cfg, now=None):
    """距离下一个配置时刻的秒数。带 0~10 分钟随机抖动避免整点扎堆。"""
    import random
    now = now or datetime.now(BJ)
    times = cfg.get("times") or ["00:30"]
    candidates = []
    for t in times:
        h, m = t.split(":", 1)
        target = now.replace(hour=int(h), minute=int(m), second=0, microsecond=0)
        if target <= now:
            target += timedelta(days=1)  # 已过，挪到明天
        candidates.append(target)
    nxt = min(candidates) if candidates else now + timedelta(days=1)
    jitter = random.randint(0, 600)  # 0~10 分钟
    return max(60, int((nxt - now).total_seconds()) + jitter)


def run_once(cfg):
    """对配置选中的账号执行一轮：快速乐斗 + 斗魂塔 + 世界Boss。返回汇总 dict。"""
    accounts = selected_accounts(cfg)
    quick_times = cfg.get("quick")
    results = []
    total_quick = 0
    total_tower = 0
    total_exp = 0
    total_wboss = 0       # 世界Boss实际参战次数（非跳过）
    total_wboss_dmg = 0   # 世界Boss累计伤害
    for user, pwd in accounts:
        log(user, "=== 自动乐斗：快速乐斗 ===")
        # 快速乐斗：quick_times 给定则用，否则用一个较大值（脚本会因体力耗尽自动停）
        qt = int(quick_times) if quick_times else 50
        q = quick_battle(user, pwd, qt)
        qdone = int(q.get("done", 0) or 0)
        qexp = int(q.get("expGained", 0) or 0)
        log(user, f"快速乐斗: {q.get('detail')}")
        time.sleep(1)
        # 斗魂塔：打满每日免费
        log(user, "=== 自动乐斗：斗魂塔 ===")
        t = tower_battle(user, pwd, TOWER_FREE_DAILY)
        tdone = int(t.get("done", 0) or 0)
        texp = int(t.get("expGained", 0) or 0)
        log(user, f"斗魂塔: {t.get('detail')}")
        time.sleep(1)
        # 世界Boss：每日参战一次（拿参与经验）
        log(user, "=== 自动乐斗：世界Boss ===")
        w = world_boss_fight(user, pwd)
        wexp = int(w.get("expGained", 0) or 0)
        wdmg = int(w.get("damage", 0) or 0)
        wdone = 0 if w.get("skipped") else 1
        log(user, f"世界Boss: {w.get('detail')}")
        # 乐斗等级：从各战斗结果中取（优先 quick > tower > wboss）
        level = q.get("level") or t.get("level") or w.get("level")
        results.append({
            "account": user,
            "level": level,
            "quick": qdone, "tower": tdone, "wboss": wdone, "wbossDmg": wdmg,
            "exp": qexp + texp + wexp,
            "quickDetail": q.get("detail"), "towerDetail": t.get("detail"),
            "wbossDetail": w.get("detail"),
        })
        total_quick += qdone
        total_tower += tdone
        total_exp += qexp + texp + wexp
        total_wboss += wdone
        total_wboss_dmg += wdmg
        time.sleep(2)  # 账号间隔
    state = {
        "lastRun": datetime.now(BJ).strftime("%Y-%m-%d %H:%M:%S"),
        "accounts": results,
        "totalQuick": total_quick,
        "totalTower": total_tower,
        "totalWboss": total_wboss,
        "totalWbossDmg": total_wboss_dmg,
        "totalExp": total_exp,
    }
    write_state(state)
    log(None, f"本轮完成：乐斗 {total_quick} 次 · 斗魂塔 {total_tower} 次 · "
              f"世界Boss {total_wboss} 次(伤害 {total_wboss_dmg}) · 经验 +{total_exp}")
    return state


def main():
    parser = argparse.ArgumentParser(description="QPet 自动乐斗守护进程")
    parser.add_argument("--once", action="store_true", help="只跑一轮后退出（测试用）")
    args = parser.parse_args()

    write_pid()
    log(None, f"=== 自动乐斗守护启动 (PID {os.getpid()}) ===")
    try:
        while True:
            cfg = load_config()  # 每轮重读配置（面板可热改）
            if not cfg.get("enabled", True):
                log(None, "配置已禁用(enabled=false)，1 小时后再查")
                if args.once:
                    break
                time.sleep(3600)
                continue
            try:
                run_once(cfg)
            except Exception as e:
                log(None, f"执行异常: {e}")
            if args.once:
                log(None, "--once 模式，退出")
                break
            wait = seconds_until_next_run(cfg)
            log(None, f"下次执行：约 {wait/3600:.1f} 小时后（配置时刻 {cfg.get('times')}）")
            time.sleep(wait)
    finally:
        clear_pid()


if __name__ == "__main__":
    main()
