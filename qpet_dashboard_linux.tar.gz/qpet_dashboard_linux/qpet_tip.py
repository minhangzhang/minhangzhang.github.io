#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QPet 社区帖子自动打赏（赠送经验）功能

复用 qpet_farm_vip 的登录与 ECDSA 签名机制，对接社区帖子打赏接口：
    POST /api/community/posts/{post_id}/tip
    Body: {"amount": <经验点数>, "message": <可选留言>}

说明：
    - amount 即要赠送的「经验」点数（前端默认 50，这里按需传值）。
    - 不能打赏自己的帖子（服务端会返回提示）。
    - 凭据优先读环境变量 QPET_USER / QPET_PASSWORD，否则取命令行参数。

用法：
    QPET_USER=xxx QPET_PASSWORD=yyy python qpet_tip.py <post_id> <amount> [message]
    python qpet_tip.py <post_id> <amount> [message] <user> <password>
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qpet_farm_vip import login, signed_request


def tip_post(user, password, post_id, amount, message=None):
    """对指定帖子打赏 amount 点经验。返回接口原始 JSON。"""
    token, pk = login(user, password)
    if not token:
        return {"success": False, "message": "登录失败"}

    body = {"amount": int(amount)}
    if message:
        body["message"] = message

    return signed_request(token, pk, "POST", f"/community/posts/{post_id}/tip", body)


def main():
    args = sys.argv[1:]
    user = os.environ.get("QPET_USER")
    pwd = os.environ.get("QPET_PASSWORD")

    if user and pwd and len(args) >= 2:
        post_id, amount = args[0], args[1]
        message = args[2] if len(args) > 2 else None
    elif len(args) >= 4:
        post_id, amount, user, pwd = args[0], args[1], args[2], args[3]
        message = args[4] if len(args) > 4 else None
    else:
        print("用法: python qpet_tip.py <post_id> <amount> [message] [user] [password]")
        print("      或设置环境变量 QPET_USER / QPET_PASSWORD 后: python qpet_tip.py <post_id> <amount> [message]")
        sys.exit(1)

    print(f"[打赏] 帖子 {post_id} | 经验 {amount}" + (f" | 留言: {message}" if message else ""))
    res = tip_post(user, pwd, post_id, amount, message)
    print(res)


if __name__ == "__main__":
    main()
