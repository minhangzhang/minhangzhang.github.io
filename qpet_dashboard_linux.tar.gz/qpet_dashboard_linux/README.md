# QPet Farm Manager — 宠物农场多账号自动化管理平台

逆向对接 `api.duanwuqiufenmao.top` 游戏服务端，实现多账号自动种菜收菜、乐斗、大会报名、拍卖行监控、社区打赏等全套自动化，并提供 Web 监控面板。

---

## 一、部署指南

### 1. 环境要求

- **Python 3.9+**
- 依赖：`requests >= 2.28`、`cryptography >= 39.0`
- 操作系统：macOS / Linux / Windows 均可

### 2. 安装步骤

```bash
# 1. 解压项目
unzip qpet-farm-manager.zip
cd qpet-farm-manager

# 2. 创建虚拟环境并安装依赖
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 3. 配置账号
#    复制模板并填入账号密码（每行一个："用户名 密码" 空格分隔）
cp accounts.txt.example accounts.txt
vi accounts.txt

# 4. 启动监控面板
#    方式一：一键脚本（自动检测并优先使用 .venv）
./start.sh              # Linux/macOS
#    Windows 双击 start.bat
#    方式二：手动启动
python qpet_dashboard_server.py
```

启动后终端会输出访问地址：

```
本机访问 → http://127.0.0.1:8787
局域网访问 → http://192.168.x.x:8787  （同 WiFi/网段设备可用）
```

浏览器打开即可使用。

### 3. 账号配置格式

`accounts.txt` 每行一个账号，格式 `用户名 密码`，空格分隔，`#` 开头为注释：

```
# QPet 农场账号配置
# 格式: 每行一个账号，"用户名 密码" 用空格分隔
不想睡 Qwer@123
3088180635@qq.com Qwer@123
dianhu0001@163.com xtt20010615
```

> 账号也可在 Web 面板的「账号管理」弹窗中增删改，会自动同步写入 `accounts.txt`。

### 4. 后台运行（可选）

```bash
# Linux/macOS：nohup 后台运行
nohup .venv/bin/python -u qpet_dashboard_server.py > logs/dashboard.out 2>&1 &

# 停止：在面板里停止各守护进程，然后 kill dashboard 进程
kill $(lsof -ti :8787)
```

### 5. 目录结构说明

```
qpet-farm-manager/
├── qpet_dashboard_server.py   # Web 面板后端（主入口）
├── qpet_farm_vip.py           # 核心签名客户端（ECDSA）
├── crop_strategy.py / .json   # 种植策略模块 + 配置
├── qpet_battle.py             # 乐斗/斗魂塔/世界Boss
├── qpet_chest.py              # 典藏宝箱
├── qpet_tip.py                # 社区打赏
├── qpet_tournament.py         # 大会报名
├── qpet_auction.py            # 拍卖行监控
├── qpet_farm_daemon.py        # 农场守护（收菜种菜）
├── qpet_auto_battle.py        # 自动乐斗守护
├── qpet_auto_tournament.py    # 自动大会报名守护
├── qpet_auto_tip.py           # 自动打赏守护
├── farm_helper.py             # 农场状态查询助手
├── dashboard/index.html       # Web 前端（单文件 SPA）
├── accounts.txt.example       # 账号配置模板（复制为 accounts.txt 后填写）
├── requirements.txt           # Python 依赖
│
├── data/                      # 运行时自动生成（配置/状态/数据库）
│   ├── farm.db                # SQLite 数据库（趋势/日志）
│   └── *_config.json          # 各守护进程配置
│   └── *_state.json           # 各守护进程状态
└── logs/                      # 运行时日志
```

---

## 二、架构概览

```
浏览器 (dashboard/index.html)
        │ HTTP
面板后端 (qpet_dashboard_server.py :8787)
        │ subprocess + import
   ┌────┴────────────────────────┐
   │                             │
业务操作模块               定时守护进程
(farm_helper/tip/chest/    (farm_daemon/auto_battle/
 battle/tournament/         auto_tournament/auto_tip/
 auction)                   auction)
   │                             │
   └──────────┬──────────────────┘
              │ ECDSA 签名 HTTPS
              ▼
     api.duanwuqiufenmao.top
```

- **签名层**：`qpet_farm_vip.py` 统一处理 ECDSA P-256 SHA-256 请求签名（GET query + POST body）。
- **守护进程**：各自独立进程，通过 JSON 配置/状态文件与面板解耦，面板热改配置、守护进程每轮重读。
- **数据层**：SQLite（`data/farm.db`）记录趋势快照和操作日志；JSON 文件存配置/状态。

---

## 三、功能说明

### 核心面板

| 功能 | 说明 |
|------|------|
| **账号田块** | 多账号卡片，按经验排序，显示等级（生长环，14级以上金色/以下绿色）、经验、今日收获经验、守护状态。支持单账号打赏/开箱/守护。 |
| **种植策略** | 按时段自动选种（如22点后种幽灵兰），支持全局策略 + 按账号独立 override。 |
| **生长趋势** | 全账号经验趋势图（收菜快照驱动）。 |
| **历史记录** | 打赏/宝箱/乐斗/大会报名/拍卖/守护事件，分类 tab 查看。 |

### 固定栏操作（批量）

| 按钮 | 说明 |
|------|------|
| **批量打赏** | 选择多个账号向指定帖子赠送经验。内含「⏰ 自动定时打赏守护」：可配置多个任务（帖子+经验+账号+星期+时刻）。 |
| **开典藏宝箱** | 批量开箱（免费单开/连开10次）。 |
| **启动/停止守护** | 批量管理农场守护进程（收菜种菜）。 |
| **自动乐斗** | 弹窗配置：参与账号、每日时刻、乐斗上限。守护进程自动执行快速乐斗+斗魂塔+世界Boss。 |
| **拍卖行** | 弹窗监控技能书行情，按限价自动购买。配置：买手账号、检查间隔、活跃时段、价格限制。 |
| **大会报名** | 弹窗一键报名武林+菜鸟。内含「⏰ 自动报名守护」：每周几+每日时刻自动报名。 |
| **账号管理** | 增删改账号，测试连通性。 |

### 定时守护进程一览

| 守护进程 | 功能 | 调度方式 |
|---------|------|---------|
| 农场守护 | 自动收菜、翻地、选种种植 | 每账号独立循环 |
| 自动乐斗 | 快速乐斗打光体力 + 斗魂塔6次 + 世界Boss参战 | 每日时刻（多时刻+随机抖动） |
| 自动大会报名 | 武林/菜鸟大会报名（已报名自动跳过） | 每周几 + 每日时刻 |
| 自动打赏 | 向指定帖子赠送经验（多任务） | 每周几 + 每日时刻 |
| 拍卖行监控 | 技能书行情抓取 + 命中限价自动购买 | 间隔分钟 + 活跃时段 |

> 所有守护进程都可在面板弹窗中启动/停止、热改配置，无需重启服务。

---

## 四、注意事项

1. **账号安全**：`accounts.txt` 含明文密码，请勿外传/提交到公开仓库。打包分发时仅含 `accounts.txt.example` 模板。
2. **签名密钥**：首次登录会在 `~/.qpet_keys/` 生成 ECDSA 私钥和 token 缓存，失效后自动重新登录。
3. **请求频率**：面板状态缓存 1 小时刷新一次，降低对游戏服务器的请求压力。
4. **局域网访问**：服务绑定 `0.0.0.0:8787`，同网段设备可直接访问。如不需局域网访问，可在 `qpet_dashboard_server.py` 末尾改为 `127.0.0.1`。
5. **Python 解释器**：守护进程由面板用启动面板的同一解释器拉起，请确保该解释器已安装 `requests` + `cryptography`。可用环境变量 `QPET_PYTHON` 指定解释器路径，`QPET_DASH_PORT` 指定端口。
