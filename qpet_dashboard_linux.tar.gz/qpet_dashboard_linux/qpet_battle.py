#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QPet 快速乐斗 / 斗魂塔 批量执行脚本

复用 qpet_farm_vip 的登录与 ECDSA 签名。两类操作：

1) 快速乐斗 (quick)：POST /api/qpet/battle/prepare {isNpc:true}
   → settle {battleToken, clientRequestId, atkWon:true, resultType:"win", atkRemainingHp, defRemainingHp:0}
   每次消耗 10 体力，不限次数，对手为 NPC。连开 N 次，体力不足(<10)时停止。

2) 斗魂塔 (tower)：GET /api/qpet/tower/status → {maxFloor, remainingFreeCount}
   自动选「最高可挑战层」(maxFloor+1，受等级限制)，POST /api/qpet/tower/prepare {floor, useRevive:false}
   → settle {...}。每天 6 次免费，用完即停（不消耗还魂丹）。

说明：服务器不校验战报数值，settle 时直接上报"胜利"(满血/对手0血)即可拿到经验。
凭据优先读环境变量 QPET_USER / QPET_PASSWORD，否则取命令行参数。

用法：
    QPET_USER=xxx QPET_PASSWORD=yyy python qpet_battle.py quick 5      # 快速乐斗 5 次
    QPET_USER=xxx QPET_PASSWORD=yyy python qpet_battle.py tower         # 斗魂塔打满 6 次免费
    QPET_USER=xxx QPET_PASSWORD=yyy python qpet_battle.py tower 3       # 斗魂塔打 3 次
    python qpet_battle.py <user> <password> quick 5
"""
import os
import sys
import json
import time
import random
import uuid

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qpet_farm_vip import login, signed_request

STAMINA_PER_BATTLE = 10  # 每次快速乐斗消耗体力

# 真实感战报：避免"每场都满血赢"的异常特征。
# 服务端不校验 HP/胜负（实测 win/lose 都给经验、都扣体力），故这里随机掺入
# 险胜(残血赢)/惜败，让 HP 分布与胜率更接近真实玩家，降低风控特征。
# tower（斗魂塔）保护免费次数，不下"彻底失败"，只偶尔残血险胜。
def _pick_result(kind, atk_max_hp, def_max_hp):
    """返回 (atkWon, resultType, atk_remaining_hp, def_remaining_hp)。"""
    r = random.random()
    if kind == "tower":
        # 斗魂塔：~90% 完胜/险胜，~10% 残血险胜；不报失败（保护免费次数）
        if r < 0.55:   # 完胜：对手 0 血，自己较健康
            return True, "win", int(atk_max_hp * random.uniform(0.6, 1.0)), 0
        elif r < 0.90:  # 险胜：对手 0 血，自己残血
            return True, "narrow_win", max(1, int(atk_max_hp * random.uniform(0.05, 0.3))), 0
        else:           # 残血险胜：双方都很低
            return True, "close_win", max(1, int(atk_max_hp * random.uniform(0.03, 0.12))), 0
    else:
        # 快速乐斗：~83% 胜(完胜/险胜)，~12% 险胜，~5% 失败（失败也给经验、扣体力，无额外损失）
        if r < 0.50:   # 完胜
            return True, "win", int(atk_max_hp * random.uniform(0.55, 1.0)), 0
        elif r < 0.83:  # 险胜
            return True, "narrow_win", max(1, int(atk_max_hp * random.uniform(0.08, 0.35))), 0
        elif r < 0.95:  # 残血险胜
            return True, "close_win", max(1, int(atk_max_hp * random.uniform(0.02, 0.1))), 0
        else:           # 失败：自己 0 血，对手残血
            return False, "lose", 0, max(1, int(def_max_hp * random.uniform(0.1, 0.5)))


def _settle_battle(token, pk, battle_token, kind, atk_max_hp, def_max_hp):
    """上报一场结算（随机真实结果）。返回 (接口JSON, atk_won)。"""
    atk_won, result_type, atk_hp, def_hp = _pick_result(kind, atk_max_hp, def_max_hp)
    path = "/qpet/battle/settle" if kind == "battle" else "/qpet/tower/settle"
    body = {
        "battleToken": battle_token,
        "clientRequestId": f"qpet:{kind}:settle:{battle_token}:{uuid.uuid4()}",
        "atkWon": atk_won,
        "resultType": result_type,
        "atkRemainingHp": atk_hp,
        "defRemainingHp": def_hp,
    }
    resp = signed_request(token, pk, "POST", path, body)
    return resp, atk_won


def quick_battle(user, password, times=1):
    """快速乐斗 N 次（NPC，每次消耗 10 体力）。体力不足时停止。"""
    token, pk = login(user, password)
    if not token:
        return {"success": False, "detail": "登录失败"}

    done = 0
    exp_gained = 0
    wins = 0
    stamina_left = None
    level = None
    for i in range(int(times)):
        pre = signed_request(token, pk, "POST", "/qpet/battle/prepare", {"isNpc": True})
        if not pre.get("success"):
            return _result(True, done, exp_gained, stamina_left,
                           f"第 {done+1} 次准备失败: {pre.get('message', '')}",
                           wins=wins, level=level)
        d = pre.get("data") or {}
        bt = d.get("battleToken")
        atk = d.get("attacker") or {}
        atk_maxhp = atk.get("max_hp", 100)
        def_maxhp = (d.get("defender") or {}).get("max_hp", 100)
        if not bt:
            return _result(True, done, exp_gained, stamina_left,
                           f"第 {done+1} 次缺少 battleToken，已停止", wins=wins, level=level)
        # settle：随机真实战报（含险胜/失败）
        st, won = _settle_battle(token, pk, bt, "battle", atk_maxhp, def_maxhp)
        if not st.get("success"):
            return _result(done > 0, done, exp_gained, stamina_left,
                           f"第 {done+1} 次结算失败: {st.get('message', '')}", wins=wins, level=level)
        sd = st.get("data") or {}
        done += 1
        exp_gained += int(sd.get("expGained", 0) or 0)
        wins += 1 if won else 0
        ch = sd.get("character") or {}
        stamina_left = ch.get("stamina", stamina_left)
        if ch.get("level") is not None:
            level = int(ch["level"])
        if ch.get("stamina") is not None and int(ch["stamina"]) < STAMINA_PER_BATTLE:
            return _result(True, done, exp_gained, stamina_left,
                           f"体力不足（剩余 {ch['stamina']}），已乐斗 {done} 次", wins=wins, level=level)
        # 避免触发"战斗处理中，请勿重复提交"
        if i < int(times) - 1:
            time.sleep(2)

    return _result(True, done, exp_gained, stamina_left,
                   f"快速乐斗完成，共 {done} 次（胜 {wins}），获得 {exp_gained} 经验", wins=wins, level=level)


def tower_battle(user, password, times=6):
    """斗魂塔：自动选最高层，每天免费次数内打满（默认6次），免费用完即停。"""
    token, pk = login(user, password)
    if not token:
        return {"success": False, "detail": "登录失败"}

    # 先查状态：最高层 + 剩余免费次数
    st = signed_request(token, pk, "GET", "/qpet/tower/status")
    if not st.get("success"):
        return {"success": False, "detail": "查询塔状态失败: " + str(st.get("message", ""))}
    sd = st.get("data") or {}
    free_left = int(sd.get("remainingFreeCount", 0) or 0)
    if free_left <= 0:
        return {"success": True, "skipped": True, "detail": "今日免费次数已用完（0/6）"}

    want = min(int(times), free_left)
    done = 0
    exp_gained = 0
    floors_cleared = []
    level = None
    max_floor = int(sd.get("maxFloor", 0) or 0)
    for i in range(want):
        # 最高可挑战层 = maxFloor + 1（可能被等级限制，失败则按错误提示回退）
        floor = max_floor + 1
        pre = signed_request(token, pk, "POST", "/qpet/tower/prepare",
                             {"floor": floor, "useRevive": False})
        # 若被等级限制，尝试用 maxFloor（已通过的最高层重打）/1
        if not pre.get("success"):
            tried = floor
            for alt in ([max_floor] if max_floor >= 1 else []) + [1]:
                if alt == tried:
                    continue
                pre = signed_request(token, pk, "POST", "/qpet/tower/prepare",
                                     {"floor": alt, "useRevive": False})
                if pre.get("success"):
                    floor = alt
                    break
            if not pre.get("success"):
                return _result(True, done, exp_gained, None,
                               f"第 {done+1} 次挑战准备失败: {pre.get('message', '')}",
                               floors_cleared, free_left - done)
        d = pre.get("data") or {}
        bt = d.get("battleToken")
        atk = d.get("attacker") or {}
        atk_maxhp = atk.get("max_hp", 100)
        def_maxhp = (d.get("defender") or {}).get("max_hp", 100)
        if atk.get("level") is not None:
            level = int(atk["level"])
        if not bt:
            return _result(True, done, exp_gained, None,
                           f"第 {done+1} 次缺少 battleToken，已停止",
                           floors_cleared, free_left - done, level=level)
        ss, won = _settle_battle(token, pk, bt, "tower", atk_maxhp, def_maxhp)
        if not ss.get("success"):
            return _result(done > 0, done, exp_gained, None,
                           f"第 {done+1} 次结算失败: {ss.get('message', '')}",
                           floors_cleared, free_left - done, level=level)
        r = ss.get("data") or {}
        done += 1
        exp_gained += int(r.get("expGained", 0) or 0)
        if (r.get("character") or {}).get("level") is not None:
            level = int(r["character"]["level"])
        if r.get("isFirstClear"):
            floors_cleared.append(r.get("floor"))
        # 用返回的最新 remainingFreeCount 判断是否还能继续
        rfc = r.get("remainingFreeCount")
        if rfc is not None and int(rfc) <= 0:
            return _result(True, done, exp_gained, None,
                           f"今日免费次数用完，斗魂塔共挑战 {done} 次",
                           floors_cleared, 0, level=level)

    left = free_left - done
    return _result(True, done, exp_gained, None,
                   f"斗魂塔完成，共挑战 {done} 次，获得 {exp_gained} 经验"
                   + (f"，新通过 {floors_cleared} 层" if floors_cleared else ""),
                   floors_cleared, left, level=level)


def world_boss_fight(user, password):
    """世界 Boss 每日参战一次（拿参与经验）。每天每账号限 1 次。

    流程：POST /api/qpet/world-boss/prepare → POST /api/qpet/world-boss/settle
    注意：世界 Boss 伤害由服务端用 seed 重新模拟，客户端提交的 won/damage 等字段会被忽略，
    故这里只做"正常参战"——提交结算即可，服务端按真实战力计算伤害与经验。
    今日已打则跳过。
    """
    token, pk = login(user, password)
    if not token:
        return {"success": False, "detail": "登录失败"}

    time.sleep(0.3)
    pre = signed_request(token, pk, "POST", "/qpet/world-boss/prepare", {})
    if not pre.get("success"):
        # 今日已挑战 / boss 未刷新 等
        msg = pre.get("message", "")
        return {"success": True, "skipped": True, "detail": f"世界Boss跳过: {msg}", "level": None}

    d = pre.get("data") or {}
    bt = d.get("battleToken")
    level = (d.get("attacker") or {}).get("level")
    if not bt:
        return {"success": False, "detail": "世界Boss缺少 battleToken", "level": level}

    time.sleep(0.3)
    # 提交结算：服务端用 seed 自行计算伤害，body 只需 battleToken（其余字段会被忽略）
    res = signed_request(token, pk, "POST", "/qpet/world-boss/settle", {"battleToken": bt})
    if not res.get("success"):
        return {"success": False, "detail": "世界Boss结算失败: " + str(res.get("message", "")), "level": level}

    rd = res.get("data") or {}
    dmg = int(rd.get("damageDealt", 0) or 0)
    exp = int(rd.get("expGained", 0) or 0)
    won = bool(rd.get("won"))
    killer = bool(rd.get("isKiller"))
    if (rd.get("character") or {}).get("level") is not None:
        level = int(rd["character"]["level"])
    detail = f"世界Boss参战完成：造成 {dmg} 伤害 · +{exp} 经验" + (" · 补刀击杀!" if killer else (" · 胜" if won else " · 负"))
    return {"success": True, "skipped": False, "damage": dmg, "expGained": exp,
            "won": won, "isKiller": killer, "detail": detail, "level": level}


def _result(success, done, exp, stamina, detail, floors=None, free_left=None, wins=None, level=None):
    return {
        "success": success,
        "done": done,
        "expGained": exp,
        "stamina": stamina,
        "floors": floors or [],
        "freeLeft": free_left,
        "wins": wins,
        "level": level,
        "detail": detail,
    }


def main():
    user = os.environ.get("QPET_USER")
    pwd = os.environ.get("QPET_PASSWORD")
    args = sys.argv[1:]
    if not (user and pwd):
        if len(args) >= 2:
            user, pwd, *rest = args
            args = rest
        else:
            _usage(); sys.exit(1)

    action = args[0] if args else ""
    times = int(args[1]) if len(args) > 1 and args[1].isdigit() else None
    if action == "quick":
        res = quick_battle(user, pwd, times if times else 1)
    elif action == "tower":
        res = tower_battle(user, pwd, times if times else 6)
    elif action == "wboss":
        res = world_boss_fight(user, pwd)
    else:
        _usage(); sys.exit(1)
    print(json.dumps(res, ensure_ascii=False))


def _usage():
    print("用法: python qpet_battle.py <user> <password> {quick [次数]|tower [次数]|wboss}")
    print("      或设置 QPET_USER / QPET_PASSWORD 后: python qpet_battle.py {quick [N]|tower [N]|wboss}")


if __name__ == "__main__":
    main()
