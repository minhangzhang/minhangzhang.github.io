#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QPet 武林大会 / 菜鸟大会 报名脚本

两类大会：
  - 武林大会 (tournament)：POST /api/qpet/tournament/register，需 20 级
  - 菜鸟大会 (loser-tournament)：POST /api/qpet/loser-tournament/register，需 100 级（minLevel）

报名逻辑：
  - 先查状态 registrationInfo.registered：已报名则跳过（不重复报）
  - 未报名则 POST register：成功/已报名/等级不足等结果如实返回

用法：
    QPET_USER=xxx QPET_PASSWORD=yyy python qpet_tournament.py register wulin      # 报名武林
    QPET_USER=xxx QPET_PASSWORD=yyy python qpet_tournament.py register rookie     # 报名菜鸟
    QPET_USER=xxx QPET_PASSWORD=yyy python qpet_tournament.py status              # 查两个大会状态
"""
import os
import sys
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qpet_farm_vip import login, signed_request

# 大会配置：(显示名, 状态路径, 报名路径)
TOURNAMENTS = {
    "wulin": ("武林大会", "/qpet/tournament/status", "/qpet/tournament/register"),
    "rookie": ("菜鸟大会", "/qpet/loser-tournament/status", "/qpet/loser-tournament/register"),
}


def _status(token, pk, kind):
    """查某大会报名状态。返回 (registered, reg_count, min_level) 或 None。"""
    name, status_path, _ = TOURNAMENTS[kind]
    st = signed_request(token, pk, "GET", status_path)
    if not st.get("success"):
        return None
    d = st.get("data") or {}
    ri = d.get("registrationInfo") or {}
    return {
        "registered": bool(ri.get("registered")),
        "regCount": ri.get("registrationCount"),
        "minLevel": d.get("minLevel"),
        "seasonNumber": ri.get("seasonNumber"),
    }


def register_tournament(user, password, kind):
    """报名某大会。已报名则跳过，未报名则尝试。返回结果 dict。"""
    if kind not in TOURNAMENTS:
        return {"success": False, "detail": f"未知大会类型: {kind}"}
    name, status_path, reg_path = TOURNAMENTS[kind]
    token, pk = login(user, password)
    if not token:
        return {"success": False, "detail": "登录失败"}

    # 1. 查状态
    import time
    time.sleep(0.3)
    s = _status(token, pk, kind)
    if s is None:
        return {"success": False, "detail": f"查询{name}状态失败"}
    if s["registered"]:
        return {"success": True, "skipped": True, "kind": kind, "name": name,
                "detail": f"{name}已报名（第{s.get('seasonNumber')}届），跳过"}

    # 2. 报名
    time.sleep(0.3)
    r = signed_request(token, pk, "POST", reg_path, {})
    if r.get("success"):
        return {"success": True, "skipped": False, "kind": kind, "name": name,
                "detail": f"{name}报名成功"}
    # 失败：等级不足 / 已报名 / 其它
    msg = r.get("message", "报名失败")
    return {"success": False, "skipped": "已报名" in msg, "kind": kind, "name": name,
            "detail": f"{name}报名失败: {msg}"}


def status_all(user, password):
    """查两个大会的报名状态。"""
    token, pk = login(user, password)
    if not token:
        return {"success": False, "detail": "登录失败"}
    out = {}
    for kind in TOURNAMENTS:
        s = _status(token, pk, kind)
        if s:
            out[kind] = s
    return {"success": True, "wulin": out.get("wulin"), "rookie": out.get("rookie")}


def main():
    user = os.environ.get("QPET_USER")
    pwd = os.environ.get("QPET_PASSWORD")
    args = sys.argv[1:]
    if not (user and pwd):
        if len(args) >= 2 and args[0] != "register" and args[0] != "status":
            user, pwd, *rest = args
            args = rest
        else:
            print("用法: python qpet_tournament.py <user> <password> {register wulin|rookie|status}")
            print("      或设置 QPET_USER / QPET_PASSWORD 后: python qpet_tournament.py {register wulin|rookie|status}")
            sys.exit(1)

    action = args[0] if args else "status"
    if action == "register":
        kind = args[1] if len(args) > 1 else "wulin"
        if kind not in TOURNAMENTS:
            print(f"未知大会: {kind}（可选: wulin 武林 / rookie 菜鸟）"); sys.exit(1)
        res = register_tournament(user, pwd, kind)
    elif action == "status":
        res = status_all(user, pwd)
    else:
        print(f"未知操作: {action}（可选: register / status）"); sys.exit(1)
    print(json.dumps(res, ensure_ascii=False))


if __name__ == "__main__":
    main()
