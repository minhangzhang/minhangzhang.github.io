#!/usr/bin/env python3
"""QPet农场VIP daemon - 无限循环版，零真空期
用法: python3 qpet_farm_daemon.py <用户名> <密码>
- 每轮收菜/种植后向 data/last_harvest 写入时间戳，触发面板快照（而非定时）。
- 种植作物遵循 crop_strategy.json（面板可编辑）。
"""
import sys, time, os, random, io

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qpet_farm_vip import login, signed_request, run
from qpet_auth_guard import AuthError, notify_and_exit
from crop_strategy import crop_now, CROPS

# 凭据来源：优先环境变量 QPET_USER / QPET_PASSWORD（平台 WorkerManager 以 env 方式 spawn，
# 杜绝命令行明文）；未设置时回退原 argv 行为，保持兼容。
USER = os.environ.get("QPET_USER")
PASS = os.environ.get("QPET_PASSWORD")
if not USER or not PASS:
    if len(sys.argv) >= 3:
        USER = sys.argv[1]
        PASS = sys.argv[2]
    else:
        print("用法: python3 qpet_farm_daemon.py <用户名> <密码>  (或设置环境变量 QPET_USER / QPET_PASSWORD)")
        sys.exit(1)

SIGNAL_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "last_harvest")
# 视为「有农事发生」的关键字（收菜 / 种植 / 翻地）
HARVEST_KEYS = ("翻地+收获", "一键收获", "一键种植", "一键翻地")


def write_harvest_signal():
    """本轮发生了收菜/种植，写入时间戳(ms)供面板触发快照。"""
    try:
        os.makedirs(os.path.dirname(SIGNAL_FILE), exist_ok=True)
        with open(SIGNAL_FILE, "w") as f:
            f.write(str(int(time.time() * 1000)))
    except Exception:
        pass


def get_min_remaining(user, pwd):
    """查询最近成熟剩余分钟"""
    token, pk = login(user, pwd)
    if not token:
        return -1
    time.sleep(0.3)
    farm = signed_request(token, pk, "GET", "/farm")
    if not farm.get("success"):
        return -1
    slots = farm["data"]["slots"]
    has_mature = any(s.get("canHarvest") for s in slots)
    if has_mature:
        return 0
    growing = [s["remainingMinutes"] for s in slots if s["state"] == "growing"]
    if not growing:
        return -1
    return int(min(growing)) + 1


def main():
    print(f"[{time.strftime('%m-%d %H:%M:%S')}] [{USER}] === Daemon启动 ===")
    while True:
        try:
            # 1. 执行收获+双倍+种植（作物由策略决定；按账号 override 优先）
            crop = crop_now(account=USER)
            print(f"[{time.strftime('%m-%d %H:%M:%S')}] [{USER}] --- 开始本轮 (种 {CROPS.get(crop,{}).get('name',crop)}) ---")
            # 捕获本轮输出以判断是否有农事发生
            buf = io.StringIO()
            real_stdout = sys.stdout
            sys.stdout = buf
            try:
                run(USER, PASS, crop_id=crop)
            finally:
                sys.stdout = real_stdout
                out = buf.getvalue()
                if out:
                    print(out, end="")
            print(f"[{time.strftime('%m-%d %H:%M:%S')}] [{USER}] --- 本轮完毕 ---")

            # 2. 有收菜/种植则通知面板快照一次
            if any(k in out for k in HARVEST_KEYS):
                write_harvest_signal()

            # 3. 查下次成熟时间
            remain = get_min_remaining(USER, PASS)

            if remain == -1:
                print(f"[{time.strftime('%m-%d %H:%M:%S')}] [{USER}] 无生长地块，5分钟后重试")
                time.sleep(300)
            elif remain == 0:
                jitter = random.randint(5, 60)
                print(f"[{time.strftime('%m-%d %H:%M:%S')}] [{USER}] 已成熟，{jitter}秒后收菜")
                time.sleep(jitter)
            else:
                jitter = random.randint(-3, 5)
                wait = remain + jitter
                print(f"[{time.strftime('%m-%d %H:%M:%S')}] [{USER}] 下次成熟约{wait}分钟，等待中...")
                time.sleep(wait * 60)
        except AuthError as ae:
            notify_and_exit(USER, str(ae))
        except Exception as e:
            print(f"[{time.strftime('%m-%d %H:%M:%S')}] [{USER}] 异常: {e}，5分钟后重试")
            time.sleep(300)

if __name__ == "__main__":
    main()
