#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""qpet_auction.py — 拍卖行技能书监控守护进程

单进程守护，循环逻辑：
  1. 读 data/auction_config.json：买手账号 / 检查间隔 / 活跃时段 / 自动购买开关 / 价格限制
  2. 到点（在活跃时段内、距上次检查超过间隔）后：
     - 登录买手账号（买手也是查行情用的账号）
     - GET /qpet/auction/listings?itemType=skill_book 拉取全部在售技能书
     - 按 limits{技能itemId: 单价上限} 筛出「命中」的（price<=limit）
     - 写行情 + 命中到 data/auction_state.json（供面板展示）
     - 若 autoBuy 且命中：逐个购买（POST /qpet/auction/buy），记录到 recentBuys
  3. 等待到下一次检查时刻

调度（间隔 + 时段叠加）：
  - intervalMin: 在活跃时段内，两次检查之间的分钟数（默认 30）
  - activeRanges: 形如 ["08:00-23:00"]，只在时段内才工作；
                 为空或 ["00:00-23:59"] 表示全天。时段外休眠到下一个时段开始。

配置文件 data/auction_config.json 格式：
    {
      "enabled": true,
      "intervalMin": 30,
      "activeRanges": ["00:00-23:59"],
      "buyer": "不想睡",                       // 固定单一买手账号
      "autoBuy": false,                        // 默认关闭，命中限价不会自动买
      "limits": {"skill_如来神掌": 800, "skill_天生大力": 500}  // itemId -> 单价上限(经验)
    }

用法：python qpet_auction.py              # 守护模式
      python qpet_auction.py --once       # 只跑一轮后退出（测试用）
"""
import os
import sys
import json
import time
import uuid
import random
import argparse
from datetime import datetime, timezone, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qpet_farm_vip import login, signed_request

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ACCOUNTS_FILE = os.path.join(BASE_DIR, "accounts.txt")
DATA_DIR = os.path.join(BASE_DIR, "data")
LOG_DIR = os.path.join(BASE_DIR, "logs")
STATE_FILE = os.path.join(DATA_DIR, "auction_state.json")
CONFIG_FILE = os.path.join(DATA_DIR, "auction_config.json")
PID_FILE = os.path.join(LOG_DIR, "auction.pid")

BJ = timezone(timedelta(hours=8))

DEFAULT_CONFIG = {
    "enabled": True,
    "intervalMin": 30,
    "activeRanges": ["00:00-23:59"],
    "buyer": "",                 # 留空则取第一个账号
    "autoBuy": False,
    "limits": {},
}


# ---------------------------------------------------------------------------
# 账号 / 配置 / 状态 / pidfile
# ---------------------------------------------------------------------------
def read_accounts():
    """返回 [(user, pass), ...]，跳过注释/空行。"""
    accs = []
    if not os.path.exists(ACCOUNTS_FILE):
        return accs
    with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                accs.append((parts[0], parts[1]))
    return accs


def _buyer_creds(cfg):
    """根据 cfg['buyer'] 找到买手账号的 (user, pass)。buyer 为空取第一个。"""
    accs = read_accounts()
    if not accs:
        return None
    name = cfg.get("buyer")
    if name:
        for u, p in accs:
            if u == name:
                return (u, p)
    return accs[0]


def load_config():
    """读取 auction_config.json。缺失返回默认配置。"""
    cfg = dict(DEFAULT_CONFIG)
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                cfg.update(data)
    except Exception:
        pass
    # 规范化
    try:
        cfg["intervalMin"] = max(5, int(cfg.get("intervalMin", 30) or 30))
    except Exception:
        cfg["intervalMin"] = 30
    cfg["autoBuy"] = bool(cfg.get("autoBuy", False))
    ranges = cfg.get("activeRanges")
    if not isinstance(ranges, list) or not ranges:
        ranges = ["00:00-23:59"]
    cfg["activeRanges"] = ranges
    limits = cfg.get("limits")
    if not isinstance(limits, dict):
        limits = {}
    # 规范化 limit 值为 int
    cfg["limits"] = {str(k): int(v) for k, v in limits.items() if _to_int(v) is not None}
    cfg["buyer"] = str(cfg.get("buyer") or "")
    return cfg


def _to_int(v):
    try:
        return int(v)
    except Exception:
        return None


def write_state(state):
    """写入状态文件供面板读取。"""
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        state["updated"] = int(time.time() * 1000)
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def write_pid():
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(PID_FILE, "w") as f:
            f.write(str(os.getpid()))
    except Exception:
        pass


def clear_pid():
    try:
        if os.path.exists(PID_FILE):
            os.remove(PID_FILE)
    except Exception:
        pass


def log(msg):
    ts = time.strftime("%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(os.path.join(LOG_DIR, "auction.log"), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


# ---------------------------------------------------------------------------
# 调度：活跃时段 + 间隔
# ---------------------------------------------------------------------------
def _parse_hm(s):
    h, m = s.split(":", 1)
    return int(h), int(m)


def _in_active_range(now, ranges):
    """now 为北京时间。判断是否落在任一活跃时段内。"""
    nm = now.hour * 60 + now.minute
    for rng in ranges:
        try:
            a, b = rng.split("-", 1)
            ah, am = _parse_hm(a.strip())
            bh, bm = _parse_hm(b.strip())
            start, end = ah * 60 + am, bh * 60 + bm
            if start <= end:
                if start <= nm <= end:
                    return True
            else:
                # 跨天时段，如 22:00-06:00
                if nm >= start or nm <= end:
                    return True
        except Exception:
            continue
    return False


def seconds_until_next_active(now, ranges):
    """若当前在活跃时段内返回 0；否则返回到下一个时段开始的秒数。"""
    if _in_active_range(now, ranges):
        return 0
    nm = now.hour * 60 + now.minute
    candidates = []
    for rng in ranges:
        try:
            a, _ = rng.split("-", 1)
            ah, am = _parse_hm(a.strip())
            start = ah * 60 + am
            delta = start - nm
            if delta <= 0:
                delta += 24 * 60
            candidates.append(delta)
        except Exception:
            continue
    if not candidates:
        return 60
    return max(60, min(candidates) * 60)


def sleep_seconds(cfg, now=None):
    """下一次检查需要睡眠的秒数（活跃时段内按 intervalMin，否则睡到下一个时段）。"""
    now = now or datetime.now(BJ)
    ranges = cfg.get("activeRanges") or ["00:00-23:59"]
    wait_active = seconds_until_next_active(now, ranges)
    if wait_active > 0:
        # 不在活跃时段，先睡到时段开始
        return wait_active, "休眠至活跃时段"
    # 在活跃时段内：按 intervalMin 间隔（带 0~60s 抖动）
    interval = max(5, int(cfg.get("intervalMin", 30))) * 60
    jitter = random.randint(0, 60)
    return max(60, interval + jitter), None


# ---------------------------------------------------------------------------
# 拍卖 API
# ---------------------------------------------------------------------------
def fetch_skill_books(token, pk, page_size=100):
    """拉取所有在售技能书（按单价升序）。返回 (listings, total)。"""
    all_listings = []
    total = 0
    page = 1
    while True:
        r = signed_request(token, pk, "GET", "/qpet/auction/listings", query={
            "itemType": "skill_book",
            "page": page,
            "pageSize": page_size,
            "sortBy": "price",
            "order": "ASC",
        })
        if not r.get("success"):
            return all_listings, total
        data = r.get("data") or {}
        ls = data.get("listings") or []
        total = int(data.get("total", 0) or 0)
        all_listings.extend(ls)
        if len(ls) < page_size or len(all_listings) >= total:
            break
        page += 1
        if page > 50:  # 保护上限
            break
        time.sleep(0.3)
    return all_listings, total


def check_limits(listings, limits):
    """返回命中的 listing 列表：itemId 在 limits 且 price<=limit，按价格升序。"""
    if not limits:
        return []
    matched = []
    for it in listings:
        iid = it.get("item_id")
        if iid not in limits:
            continue
        limit = limits.get(iid)
        if limit is None:
            continue
        price = _to_int(it.get("price"))
        if price is None:
            continue
        if price <= int(limit):
            matched.append(it)
    # 单价升序，优先买最便宜的
    matched.sort(key=lambda x: _to_int(x.get("price", 0)) or 0)
    return matched


def buy_one(token, pk, listing_id):
    """购买一个 listing。返回 dict：{success, detail}。"""
    res = signed_request(token, pk, "POST", "/qpet/auction/buy", {
        "listingId": listing_id,
        "clientRequestId": f"qpet-auction-buy-{uuid.uuid4()}",
    })
    ok = bool(res.get("success"))
    return {"success": ok, "detail": "购买成功" if ok else ("购买失败: " + str(res.get("message", "")))}


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------
def run_once(cfg):
    """执行一轮：拉行情 → 算命中 → 写状态 → 视情况购买。返回本轮 state。"""
    creds = _buyer_creds(cfg)
    state = {"running": True, "listings": [], "matched": [], "total": 0,
             "recentBuys": _load_recent_buys(), "nextCheck": None}
    if not creds:
        log("无可用账号，跳过本轮")
        write_state(state)
        return state

    token, pk = login(creds[0], creds[1])
    if not token:
        log("买手登录失败，跳过本轮")
        state["error"] = "买手登录失败"
        write_state(state)
        return state

    time.sleep(0.3)
    listings, total = fetch_skill_books(token, pk)
    limits = cfg.get("limits") or {}
    matched = check_limits(listings, limits)
    log(f"拉取到 {total} 本技能书，命中限价 {len(matched)} 本")

    # 精简 listing（只保留面板需要的字段）
    slim = []
    for it in listings:
        slim.append({
            "id": it.get("id"),
            "item_id": it.get("item_id"),
            "item_name": it.get("item_name"),
            "price": it.get("price"),
            "quantity": it.get("quantity", 1),
            "seller_nickname": it.get("seller_nickname"),
            "created_at": it.get("created_at"),
        })
    state["listings"] = slim
    state["total"] = total
    state["matched"] = [
        {"id": m.get("id"), "item_id": m.get("item_id"), "item_name": m.get("item_name"),
         "price": m.get("price"), "limit": limits.get(m.get("item_id"))}
        for m in matched
    ]

    # 自动购买
    if cfg.get("autoBuy") and matched:
        for m in matched:
            time.sleep(0.5)
            b = buy_one(token, pk, m.get("id"))
            rec = {"item_name": m.get("item_name"), "item_id": m.get("item_id"),
                   "price": m.get("price"), "account": creds[0],
                   "ts": int(time.time() * 1000),
                   "detail": b.get("detail"), "success": b.get("success")}
            state["recentBuys"].insert(0, rec)
            log(f"自动购买 {m.get('item_name')} @ {m.get('price')}：{b.get('detail')}")
        # 只留最近 20 条
        state["recentBuys"] = state["recentBuys"][:20]
        _save_recent_buys(state["recentBuys"])

    write_state(state)
    return state


_RECENT_BUY_FILE = os.path.join(DATA_DIR, "auction_buys.json")


def _load_recent_buys():
    try:
        if os.path.exists(_RECENT_BUY_FILE):
            with open(_RECENT_BUY_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                return data
    except Exception:
        pass
    return []


def _save_recent_buys(buys):
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(_RECENT_BUY_FILE, "w", encoding="utf-8") as f:
            json.dump(buys, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def main():
    parser = argparse.ArgumentParser(description="QPet 拍卖行技能书监控守护进程")
    parser.add_argument("--once", action="store_true", help="只跑一轮后退出（测试用）")
    args = parser.parse_args()

    write_pid()
    log(f"=== 拍卖行监控守护启动 (PID {os.getpid()}) ===")
    try:
        while True:
            cfg = load_config()
            if not cfg.get("enabled", True):
                log("配置已禁用(enabled=false)，1 小时后再查")
                if args.once:
                    break
                time.sleep(3600)
                continue
            # 调度：先看是否在活跃时段
            wait, reason = sleep_seconds(cfg)
            if reason:
                log(f"非活跃时段，{reason}（约 {wait/60:.0f} 分钟后）")
                if args.once:
                    log("--once 模式，非活跃时段也强制执行一次")
                    run_once(cfg)
                    break
                time.sleep(min(wait, 3600))  # 最多睡 1 小时再重查配置
                continue
            try:
                run_once(cfg)
            except Exception as e:
                log(f"执行异常: {e}")
            if args.once:
                log("--once 模式，退出")
                break
            wait, _ = sleep_seconds(cfg)
            mins = cfg.get("intervalMin", 30)
            log(f"下次检查：约 {wait/60:.0f} 分钟后（间隔 {mins} 分钟）")
            time.sleep(wait)
    finally:
        clear_pid()


if __name__ == "__main__":
    main()
