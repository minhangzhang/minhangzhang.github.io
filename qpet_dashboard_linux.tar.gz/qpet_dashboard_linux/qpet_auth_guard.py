#!/usr/bin/env python3
"""QPet 认证异常守卫 - 检测验证码/封号等认证类异常，触发飞书告警

用法（qpet_farm_vip.py 和 daemon 中导入）：
    from qpet_auth_guard import AuthError, check_auth_error

    # 在 login() 和 signed_request() 返回处调用：
    check_auth_error(resp, account="manq")

    # daemon 中捕获：
    try:
        ...
    except AuthError:
        notify_and_exit(account, str(e))
"""
import json, time, os

# ── 触发认证异常的关键词 ──
CAPTCHA_KEYWORDS = [
    # 天御 / 腾讯验证码
    "captcha", "ticket", "randstr", "天御",
    # 通用验证码
    "验证码", "图像验证", "人机验证", "verify_code",
    "needCaptcha", "captchaRequired", "need_verify",
    "CAPTCHA",
    # 封号
    "封禁", "已封号", "account suspended", "banned",
    "account_banned", "违规",
]

# ── 认证失败重试上限（超过即判定为验证码/封号） ──
# 通过文件记录连续失败次数
FAIL_COUNTER_DIR = "/tmp/qpet_auth_fail"


class AuthError(Exception):
    """认证类异常（验证码/封号），daemon 应捕获后停止并通知"""
    pass


def _read_fail_count(account):
    path = os.path.join(FAIL_COUNTER_DIR, account.replace("@", "_").replace("/", "_"))
    try:
        with open(path) as f:
            return int(f.read().strip() or "0")
    except Exception:
        return 0


def _write_fail_count(account, count):
    os.makedirs(FAIL_COUNTER_DIR, exist_ok=True)
    path = os.path.join(FAIL_COUNTER_DIR, account.replace("@", "_").replace("/", "_"))
    try:
        with open(path, "w") as f:
            f.write(str(count))
    except Exception:
        pass


def _reset_fail_count(account):
    _write_fail_count(account, 0)


def _contains_keyword(text):
    if not text:
        return False
    text_lower = text.lower()
    for kw in CAPTCHA_KEYWORDS:
        if kw.lower() in text_lower:
            return kw
    return False


def check_auth_error(resp, account="unknown"):
    """检查 API 响应是否包含验证码/封号信号。命中则 raise AuthError。

    resp: dict 或 str，API 返回的 JSON 或原始文本。
    account: 账号名，用于告警。
    """
    if not resp:
        return

    # 统一转成文本检查
    if isinstance(resp, dict):
        text = json.dumps(resp, ensure_ascii=False)
        success = resp.get("success")
        message = resp.get("message", "")
        # HTTP 状态码 / 特定错误码
        status = resp.get("status") or resp.get("code")
    else:
        text = str(resp)
        success = None
        message = ""
        status = None

    # 1. 关键词命中（最可靠）
    kw = _contains_keyword(text)
    if kw:
        _reset_fail_count(account)
        raise AuthError(f"[{account}] 检测到验证码/封号信号(关键词:{kw}): {message or text[:200]}")

    # 2. 连续认证失败累计（防止服务器只返回模糊错误如"登录失败"）
    if success is False and account != "unknown":
        # 只有 login/签名验证 相关的失败才计数
        auth_fail_hints = ["login", "auth", "token", "unauthorized", "登录", "认证", "签名", "凭据"]
        if any(h.lower() in text.lower() for h in auth_fail_hints):
            count = _read_fail_count(account) + 1
            _write_fail_count(account, count)
            if count >= 3:
                _reset_fail_count(account)
                raise AuthError(f"[{account}] 连续{count}次认证失败: {message or text[:200]}")
        else:
            # 非认证类失败不计数
            _reset_fail_count(account)
    elif success is True:
        _reset_fail_count(account)


def notify_and_exit(account, reason):
    """发送飞书告警并退出进程"""
    msg = f"🚨 QPet自动化异常停止\n账号: {account}\n原因: {reason}\n时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n请手动检查，验证码/token问题需人工处理。"
    print(f"\n{'='*50}")
    print(f"⚠️ 认证异常，停止任务: {account}")
    print(f"   {reason}")
    print(f"{'='*50}")

    # 尝试飞书通知
    try:
        sys_path_backup = list(__import__("sys").path)
        __import__("sys").path.insert(0, "/root")
        from feishu_push import send
        send(msg)
    except Exception as e:
        print(f"  飞书通知失败: {e}，消息:\n{msg}")
    finally:
        pass

    # 退出
    os._exit(1)
