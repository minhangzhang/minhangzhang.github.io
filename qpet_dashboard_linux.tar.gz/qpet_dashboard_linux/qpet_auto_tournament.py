#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""qpet_auto_tournament.py — 大会自动报名守护进程（按配置的每日时刻自动报名）

单进程守护，循环逻辑（与 qpet_auto_battle.py 同构）：
  1. 读 data/auto_tournament_config.json：参与账号 + 每日执行时刻(可多个) + 报名类型
  2. 到点后对每个参与账号：
     - 武林大会报名（已报名/等级不足自动跳过）
     - 菜鸟大会报名（已报名/等级不足自动跳过）
  3. 写汇总到 data/auto_tournament_state.json（供面板展示）
  4. 等待到下一个配置时刻

配置文件 data/auto_tournament_config.json 格式：
    {
      "enabled": true,
      "accounts": ["不想睡"],          // 空数组=全部账号
      "times": ["00:30"],              // 每日北京时间点(可多个)
      "weekdays": [1,2,3,4,5],         // 执行星期(1=周一…7=周日, 0=周日)；空=每天
      "kinds": ["wulin", "rookie"]     // 报名类型：wulin 武林 / rookie 菜鸟
    }

用法：python qpet_auto_tournament.py              # 守护模式，按配置时刻循环
      python qpet_auto_tournament.py --once       # 只跑一轮后退出（测试用）
"""
import os
import sys
import json
import time
import random
import argparse
import sqlite3
from datetime import datetime, timezone, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qpet_tournament import register_tournament

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ACCOUNTS_FILE = os.path.join(BASE_DIR, "accounts.txt")
DATA_DIR = os.path.join(BASE_DIR, "data")
LOG_DIR = os.path.join(BASE_DIR, "logs")
DB_FILE = os.path.join(DATA_DIR, "farm.db")
STATE_FILE = os.path.join(DATA_DIR, "auto_tournament_state.json")
CONFIG_FILE = os.path.join(DATA_DIR, "auto_tournament_config.json")
PID_FILE = os.path.join(LOG_DIR, "auto_tournament.pid")

BJ = timezone(timedelta(hours=8))

DEFAULT_CONFIG = {
    "enabled": True,
    "accounts": [],                 # 空=全部账号
    "times": ["00:30"],             # 默认每日 00:30
    "weekdays": [1, 2, 3, 4, 5],    # 执行星期（1=周一…7=周日，0=周日）；空=每天。默认工作日
    "kinds": ["wulin", "rookie"],   # 默认两类都报
}

# 大会显示名
KIND_NAMES = {"wulin": "武林大会", "rookie": "菜鸟大会"}


# ---------------------------------------------------------------------------
# 账号 / 配置 / 状态 / pidfile
# ---------------------------------------------------------------------------
def read_accounts():
    """返回 [(user, pass), ...]，跳过注释/空行。"""
    accs = []
    if not os.path.exists(ACCOUNTS_FILE):
        return accs
    with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                accs.append((parts[0], parts[1]))
    return accs


def load_config():
    """读取 auto_tournament_config.json。缺失时返回默认配置。"""
    cfg = dict(DEFAULT_CONFIG)
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                cfg.update(data)
    except Exception:
        pass
    # 规范化
    if not isinstance(cfg.get("accounts"), list):
        cfg["accounts"] = []
    if not isinstance(cfg.get("times"), list):
        cfg["times"] = ["00:30"]
    if not isinstance(cfg.get("kinds"), list):
        cfg["kinds"] = ["wulin", "rookie"]
    # 过滤无效时刻，排序去重
    valid = []
    for t in cfg["times"]:
        s = str(t).strip()
        if ":" in s:
            h, m = s.split(":", 1)
            if h.isdigit() and m.isdigit():
                valid.append(f"{int(h):02d}:{int(m):02d}")
    cfg["times"] = sorted(set(valid)) or ["00:30"]
    # 规范化 weekdays：0-7（0 和 7 都表示周日），空=每天
    wds = []
    if isinstance(cfg.get("weekdays"), list):
        for w in cfg["weekdays"]:
            try:
                w = int(w)
            except Exception:
                continue
            # 7 视作周日(0)
            if w == 7:
                w = 0
            if 0 <= w <= 6 and w not in wds:
                wds.append(w)
    cfg["weekdays"] = sorted(wds)  # 空=每天
    # 规范化 kinds：只保留 wulin/rookie，去重保序
    kinds = []
    for k in cfg["kinds"]:
        if k in ("wulin", "rookie") and k not in kinds:
            kinds.append(k)
    cfg["kinds"] = kinds or ["wulin", "rookie"]
    return cfg


def selected_accounts(cfg):
    """根据配置返回 [(user, pass), ...]：配置 accounts 为空则全部，否则取交集。"""
    all_accs = read_accounts()
    sel = cfg.get("accounts") or []
    if not sel:
        return all_accs
    selset = set(sel)
    return [(u, p) for u, p in all_accs if u in selset]


def write_state(state):
    """写入状态文件供面板读取。"""
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        state["updated"] = int(time.time() * 1000)
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def write_pid():
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(PID_FILE, "w") as f:
            f.write(str(os.getpid()))
    except Exception:
        pass


def clear_pid():
    try:
        if os.path.exists(PID_FILE):
            os.remove(PID_FILE)
    except Exception:
        pass


def log(msg):
    ts = time.strftime("%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(os.path.join(LOG_DIR, "auto_tournament.log"), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def db_log(account, kind, success, skipped, detail):
    """记录到 tournament_log（与面板报名共用一张表）。失败也记。"""
    try:
        con = sqlite3.connect(DB_FILE)
        con.execute(
            "INSERT INTO tournament_log(account, ts, kind, success, skipped, detail) "
            "VALUES(?,?,?,?,?,?)",
            (account, int(time.time() * 1000), kind, 1 if success else 0,
             1 if skipped else 0, detail))
        con.commit()
        con.close()
    except Exception:
        pass


def seconds_until_next_run(cfg, now=None):
    """距离下一个「选中星期 + 配置时刻」的秒数。

    weekdays 限制生效星期（1=周一…6=周六, 0=周日）；空=不限制（每天）。
    带随机抖动避免整点扎堆。
    """
    now = now or datetime.now(BJ)
    times = cfg.get("times") or ["00:30"]
    weekdays = cfg.get("weekdays") or []  # 空=每天
    wdset = set(int(w) for w in weekdays) if weekdays else set(range(7))  # 空=全选
    # 7 天内逐日扫描，找到第一个「命中星期 且 时刻在未来」的点
    candidates = []
    for day_offset in range(8):  # 最多看一周
        d = now + timedelta(days=day_offset)
        # datetime.weekday(): 周一=0…周日=6；而配置里周日=0，周一=1…周六=6
        cfg_wd = 0 if d.weekday() == 6 else d.weekday() + 1
        if cfg_wd not in wdset:
            continue
        for t in times:
            h, m = t.split(":", 1)
            target = d.replace(hour=int(h), minute=int(m), second=0, microsecond=0)
            if target > now:
                candidates.append(target)
    nxt = min(candidates) if candidates else now + timedelta(days=7)
    jitter = random.randint(0, 600)  # 0~10 分钟
    return max(60, int((nxt - now).total_seconds()) + jitter)


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------
def run_once(cfg):
    """对配置选中的账号执行一轮：按 kinds 报名武林/菜鸟。返回汇总 dict。"""
    accounts = selected_accounts(cfg)
    kinds = cfg.get("kinds") or ["wulin", "rookie"]
    results = []
    total_ok = 0       # 报名成功（含首次报名）
    total_skip = 0     # 已报名跳过
    for user, pwd in accounts:
        per = {"account": user, "results": []}
        for kind in kinds:
            log(f"[{user}] === 自动报名：{KIND_NAMES.get(kind, kind)} ===")
            r = register_tournament(user, pwd, kind)
            ok = bool(r.get("success"))
            skip = bool(r.get("skipped"))
            detail = r.get("detail", "")
            log(f"[{user}] {KIND_NAMES.get(kind, kind)}: {detail}")
            per["results"].append({
                "kind": kind, "name": KIND_NAMES.get(kind, kind),
                "success": ok, "skipped": skip, "detail": detail,
            })
            if ok:
                total_ok += 1
                if skip:
                    total_skip += 1
            # 记录到数据库（与面板报名同表，历史记录可见）
            db_log(user, kind, ok, skip, detail)
            time.sleep(0.5)
        results.append(per)
        time.sleep(1)  # 账号间隔
    state = {
        "lastRun": datetime.now(BJ).strftime("%Y-%m-%d %H:%M:%S"),
        "accounts": results,
        "totalOk": total_ok,
        "totalSkip": total_skip,
        "totalAccounts": len(accounts),
        "kinds": kinds,
    }
    write_state(state)
    log(f"本轮完成：{len(accounts)} 账号 · 报名成功 {total_ok}（跳过 {total_skip}）")
    return state


def main():
    parser = argparse.ArgumentParser(description="QPet 大会自动报名守护进程")
    parser.add_argument("--once", action="store_true", help="只跑一轮后退出（测试用）")
    args = parser.parse_args()

    write_pid()
    log(f"=== 大会自动报名守护启动 (PID {os.getpid()}) ===")
    try:
        while True:
            cfg = load_config()  # 每轮重读配置（面板可热改）
            if not cfg.get("enabled", True):
                log("配置已禁用(enabled=false)，1 小时后再查")
                if args.once:
                    break
                time.sleep(3600)
                continue
            try:
                run_once(cfg)
            except Exception as e:
                log(f"执行异常: {e}")
            if args.once:
                log("--once 模式，退出")
                break
            wait = seconds_until_next_run(cfg)
            log(f"下次执行：约 {wait/3600:.1f} 小时后（配置时刻 {cfg.get('times')}）")
            time.sleep(wait)
    finally:
        clear_pid()


if __name__ == "__main__":
    main()
