#!/usr/bin/env bash
# QPet 监控面板一键启动（Linux / macOS）
cd "$(dirname "$0")"
export QPET_DASH_PORT="${QPET_DASH_PORT:-8787}"
# 优先使用 .venv（已安装依赖），其次系统 python3
if [ -x ".venv/bin/python" ]; then
  PY=".venv/bin/python"
else
  PY="${PYTHON:-python3}"
  command -v "$PY" >/dev/null 2>&1 || PY=python
fi
echo "启动 QPet 监控面板 → http://127.0.0.1:${QPET_DASH_PORT}/"
echo "解释器: $PY"
exec "$PY" -u qpet_dashboard_server.py
