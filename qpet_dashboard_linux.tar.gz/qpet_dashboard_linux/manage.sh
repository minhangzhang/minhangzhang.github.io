#!/usr/bin/env bash
# QPet 农场多账号守护进程管理
# 用法:
#   ./manage.sh start   [账号]                     启动全部 (或指定) 账号
#   ./manage.sh stop    [账号]                     停止全部 (或指定) 账号
#   ./manage.sh restart [账号]                     重启
#   ./manage.sh status                             查看各账号运行状态
#   ./manage.sh log <账号>                         实时查看某账号日志 (Ctrl-C 退出)
#   ./manage.sh tip [账号] <post_id> <经验> [留言] 对全部 (或指定) 账号打赏帖子
set -u

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Python 解释器（需含 requests/cryptography 依赖）。优先级：
#   1) 环境变量 PYTHON  2) 原 macOS venv  3) PATH 上的 python3 / python
_pick_python() {
  if [ -n "${PYTHON:-}" ]; then echo "$PYTHON"; return; fi
  if [ -x "/Users/zx/happy_farm/venv/bin/python3" ]; then echo "/Users/zx/happy_farm/venv/bin/python3"; return; fi
  if command -v python3 >/dev/null 2>&1; then echo "python3"; return; fi
  echo "python"
}
PYTHON="$(_pick_python)"
DAEMON="$DIR/qpet_farm_daemon.py"
TIP="$DIR/qpet_tip.py"
ACCOUNTS="$DIR/accounts.txt"
LOG_DIR="$DIR/logs"
TIP_LOG="$LOG_DIR/tips.log"
mkdir -p "$LOG_DIR"

# 读取账号列表，每行输出 "user\tpass"。$1 可指定只读某个账号
read_accounts() {
  local target="${1:-}"
  if [ ! -f "$ACCOUNTS" ]; then
    echo "✗ 未找到 $ACCOUNTS，请先执行: cp accounts.txt.example accounts.txt 并填写账号" >&2
    return 1
  fi
  while IFS=$' \t' read -r user pass _ || [ -n "$user" ]; do
    case "$user" in ""|\#*) continue ;; esac           # 跳过空行和注释
    [ -z "$pass" ] && { echo "⚠️  跳过 $user：缺少密码" >&2; continue; }
    [ -n "$target" ] && [ "$user" != "$target" ] && continue
    printf '%s\t%s\n' "$user" "$pass"
  done < "$ACCOUNTS"
}

# 判断某账号是否在运行 (user 后加空格，避免账号名互为前缀时误匹配)
is_running() { pgrep -f "qpet_farm_daemon.py $1 " >/dev/null 2>&1; }
pid_of()      { pgrep -f "qpet_farm_daemon.py $1 " 2>/dev/null | head -1; }

cmd_start() {
  local target="${1:-}" n=0
  while IFS=$'\t' read -r user pass; do
    if is_running "$user"; then echo "→ $user 已在运行，跳过"; continue; fi
    nohup "$PYTHON" -u "$DAEMON" "$user" "$pass" > "$LOG_DIR/$user.log" 2>&1 &
    echo "✓ 启动 $user (PID $!) → logs/$user.log"
    n=$((n+1))
  done < <(read_accounts "$target")
  echo "完成，本次启动 $n 个进程"
}

cmd_stop() {
  local target="${1:-}" pids
  if [ -n "$target" ]; then
    pids=$(pgrep -f "qpet_farm_daemon.py $target " 2>/dev/null)
  else
    pids=$(pgrep -f "qpet_farm_daemon.py" 2>/dev/null)
  fi
  [ -z "$pids" ] && { echo "没有运行中的进程"; return; }
  echo "$pids" | while read -r pid; do kill "$pid" 2>/dev/null && echo "✓ 停止 PID $pid"; done
}

cmd_status() {
  local found=0
  while IFS=$'\t' read -r user pass; do
    if is_running "$user"; then
      printf '  ✓ %-16s 运行中 (PID %s)\n' "$user" "$(pid_of "$user")"
      found=1
    else
      printf '  ✗ %-16s 未运行\n' "$user"
    fi
  done < <(read_accounts)
  [ "$found" = 0 ] && echo "(无运行中进程)"
}

cmd_log() {
  local user="${1:-}"
  [ -z "$user" ] && { echo "用法: ./manage.sh log <账号>"; return 1; }
  local f="$LOG_DIR/$user.log"
  [ -f "$f" ] || { echo "✗ 无日志文件 $f"; return 1; }
  echo "—— 实时日志 $user (Ctrl-C 退出) ——"
  tail -f "$f"
}

# 打赏: tip [账号] <post_id> <经验> [留言]
# 若第一个参数为纯数字, 视为 post_id (对全部账号); 否则视为指定账号。
cmd_tip() {
  local target="" post_id amount message
  if [[ "${1:-}" =~ ^[0-9]+$ ]]; then
    target=""; post_id="${1:-}"; amount="${2:-}"; message="${3:-}"
  else
    target="${1:-}"; post_id="${2:-}"; amount="${3:-}"; message="${4:-}"
  fi
  if [ -z "$post_id" ] || [ -z "$amount" ]; then
    echo "用法: ./manage.sh tip [账号] <post_id> <经验> [留言]"
    return 1
  fi

  local n=0 ok=0
  while IFS=$'\t' read -r user pass; do
    n=$((n+1))
    local out ts
    out="$(QPET_USER="$user" QPET_PASSWORD="$pass" "$PYTHON" "$TIP" "$post_id" "$amount" "$message" 2>&1)"
    ts="$(date '+%Y-%m-%d %H:%M:%S')"
    if echo "$out" | grep -q "'success': True"; then
      echo "✓ $user 打赏 $post_id +$amount 经验"
      ok=$((ok+1))
      echo "$ts	$user	$post_id	$amount	SUCCESS	${message}" >> "$TIP_LOG"
    else
      local msg
      msg="$(echo "$out" | tail -1)"
      echo "✗ $user 打赏失败: $msg"
      echo "$ts	$user	$post_id	$amount	FAIL	$msg" >> "$TIP_LOG"
    fi
  done < <(read_accounts "$target")
  echo "完成，成功 $ok / 共 $n 个账号，记录写入 logs/tips.log"
}

# 启动监控面板（dashboard 后端）
cmd_serve() {
  local port="${QPET_DASH_PORT:-8787}"
  mkdir -p "$LOG_DIR"
  echo "启动监控面板 → http://127.0.0.1:${port}/"
  nohup "$PYTHON" -u "$DIR/qpet_dashboard_server.py" > "$LOG_DIR/dashboard.log" 2>&1 &
  echo "✓ 已启动 (PID $!) → logs/dashboard.log"
  echo "浏览器打开: http://127.0.0.1:${port}/"
}

case "${1:-}" in
  start)        shift; cmd_start "$@" ;;
  stop)         shift; cmd_stop  "$@" ;;
  restart) shift; cmd_stop "$@"; sleep 1; cmd_start "$@" ;;
  status)       cmd_status ;;
  log)          shift; cmd_log "$@" ;;
  tip)          shift; cmd_tip "$@" ;;
  serve)        shift; cmd_serve "$@" ;;
  *) cat <<'EOF'
用法: ./manage.sh <命令> [参数]
命令:
  start   [账号]                     启动全部 (或指定) 账号
  stop    [账号]                     停止全部 (或指定) 账号
  restart [账号]                     重启
  status                             查看各账号运行状态
  log     <账号>                     实时查看某账号日志
  tip     [账号] <post_id> <经验> [留言]  打赏帖子 (全部或指定账号)
  serve                             启动监控面板 (http://127.0.0.1:8787)
EOF
    ;;
esac
