#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QPet 典藏宝箱自动开启（每日首次免费）

复用 qpet_farm_vip 的登录与 ECDSA 签名机制，对接展厅典藏宝箱接口：
    GET  /api/qpet/exhibition-hall/chest-status   状态: {todayCount, nextCost, availableExp, ...}
    POST /api/qpet/exhibition-hall/chest-open     开启: Body {requestId} -> {success, data:{drops, status}}

每日首次 nextCost==0（免费）；2-10 次 100 EXP，11-20 次 200 EXP，21-30 次 300 EXP。
两种模式：
    - 默认（无 --times）：「只开免费的」，先查状态，若 nextCost>0（今日免费已用）则跳过，不消耗经验。
    - --times N：连开 N 次（不管免费/付费，消耗经验）。经验不足以开下一箱时立即停止并如实报告。

输出：JSON（供后端解析）。跳过时返回 {"success": true, "skipped": true, ...}。
凭据优先读环境变量 QPET_USER / QPET_PASSWORD，否则取命令行参数。

用法：
    QPET_USER=xxx QPET_PASSWORD=yyy python qpet_chest.py              # 仅开当天免费那次
    QPET_USER=xxx QPET_PASSWORD=yyy python qpet_chest.py --times 10   # 连开 10 次（消耗经验）
    python qpet_chest.py <user> <password> [--times N]
"""
import os
import sys
import time
import uuid
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qpet_farm_vip import login, signed_request

# ── 稀有掉落通报 ──
ZODIAC_IDS = {
    'aries', 'taurus', 'gemini', 'cancer', 'leo', 'virgo',
    'libra', 'scorpio', 'sagittarius', 'capricorn', 'aquarius', 'pisces',
}
ZODIAC_CN = {
    'aries': '白羊座', 'taurus': '金牛座', 'gemini': '双子座', 'cancer': '巨蟹座',
    'leo': '狮子座', 'virgo': '处女座', 'libra': '天秤座', 'scorpio': '天蝎座',
    'sagittarius': '射手座', 'capricorn': '摩羯座', 'aquarius': '水瓶座', 'pisces': '双鱼座',
}
# 技能书/武器书关键词
VALUABLE_KEYWORDS = ['技能书', '武器书', '秘籍', '图谱']


def _check_rare_drops(drops, user):
    """检测稀有掉落，命中则飞书通报。返回稀有物品列表。"""
    rare_items = []
    for d in drops:
        item_id = (d.get('item_id') or '').lower()
        item_name = d.get('item_name') or ''
        rarity = (d.get('rarity') or '').lower()

        is_zodiac = item_id in ZODIAC_IDS
        is_valuable = any(kw in item_name for kw in VALUABLE_KEYWORDS)
        # epic/legendary rarity 也通报
        is_high_rarity = rarity in ('epic', 'legendary', 'mythic')

        if is_zodiac or is_valuable or is_high_rarity:
            label = ''
            if is_zodiac:
                label = f'⭐十二星座·{ZODIAC_CN.get(item_id, item_name)}'
            elif is_valuable:
                label = f'📚珍稀·{item_name}'
            else:
                label = f'💎{rarity}·{item_name}'
            rare_items.append(f'{label} x{d.get("quantity", 1)}')

    if rare_items:
        try:
            # 动态import避免没装requests的环境报错
            feishu_path = '/root'
            if feishu_path not in sys.path:
                sys.path.insert(0, feishu_path)
            from feishu_push import send as feishu_send
            msg = f'🎁【{user}】典藏宝箱出好东西了！\n\n' + '\n'.join(rare_items)
            feishu_send(msg)
        except Exception as e:
            print(f'[通报] 飞书推送失败: {e}', file=sys.stderr)

    return rare_items


def _drops_summary(drops):
    """把掉落列表拼成可读摘要：物品名x数量。"""
    names = [f"{d.get('item_name', '?')}x{d.get('quantity', 1)}" for d in drops]
    return "、".join(names) if names else "(无掉落)"


def _query_status(token, pk):
    """查询宝箱状态。返回 (ok, sdata)。"""
    st = signed_request(token, pk, "GET", "/qpet/exhibition-hall/chest-status")
    if not st.get("success"):
        return False, None
    return True, (st.get("data") or {})


def open_chest_free(user, password):
    """开启典藏宝箱（仅当今日还有免费次数）。

    返回 dict，含 success / skipped / drops / detail 等字段：
      - 今日免费可用 -> 开启，返回 {success, skipped:False, drops:[...], reward:...}
      - 今日免费已用 (nextCost>0) -> {success:True, skipped:True, nextCost, detail:"今日免费已用"}
      - 登录/请求失败 -> {success:False, detail:"..."}
    """
    token, pk = login(user, password)
    if not token:
        return {"success": False, "detail": "登录失败"}

    # 1. 查状态：确认今日是否还有免费
    time.sleep(0.3)
    ok, sdata = _query_status(token, pk)
    if not ok:
        return {"success": False, "detail": "查询宝箱状态失败"}

    next_cost = sdata.get("nextCost", 0)
    today_count = sdata.get("todayCount", 0)

    # nextCost==0 表示免费（今日首次）；>0 表示今日免费已用，需消耗经验 -> 跳过
    if next_cost and int(next_cost) > 0:
        return {
            "success": True,
            "skipped": True,
            "free": False,
            "todayCount": today_count,
            "nextCost": next_cost,
            "detail": f"今日免费已用（今日已开 {today_count} 次，下次需 {next_cost} 经验）",
        }

    # 2. 开启（免费这次）
    time.sleep(0.3)
    res = signed_request(token, pk, "POST", "/qpet/exhibition-hall/chest-open",
                         {"requestId": f"qpet-chest-{uuid.uuid4()}"})

    if not res.get("success"):
        return {"success": False, "detail": "开启失败: " + str(res.get("message", ""))}

    data = res.get("data") or {}
    drops = data.get("drops") or []
    reward = _drops_summary(drops)
    _check_rare_drops(drops, user)
    return {
        "success": True,
        "skipped": False,
        "free": True,
        "drops": drops,
        "reward": reward,
        "detail": f"免费开启成功，获得：{reward}",
    }


def open_chest_multi(user, password, times=10):
    """连开多次（不管免费/付费，消耗经验）。

    每轮：查状态 -> 若 nextCost>可用经验 则停止（经验不足）-> 否则开一次。
    累计所有掉落与消耗，返回汇总。经验不足或接口失败时立即停止。
    """
    token, pk = login(user, password)
    if not token:
        return {"success": False, "detail": "登录失败"}

    all_drops = []      # 累计掉落
    opened = 0          # 实际开启次数
    spent = 0           # 累计消耗经验
    free_used = 0       # 其中免费次数
    last_status = {}

    for i in range(int(times)):
        time.sleep(0.3)
        ok, sdata = _query_status(token, pk)
        if not ok:
            return _multi_result(True, opened, spent, free_used, all_drops,
                                 last_status, f"第 {opened+1} 次查询状态失败，已停止")
        next_cost = int(sdata.get("nextCost", 0) or 0)
        avail_exp = int(sdata.get("availableExp", 0) or 0)
        last_status = sdata

        # 经验不足开下一箱（与前端 u.value>_.value 判断一致）-> 停止
        if next_cost > avail_exp:
            return _multi_result(True, opened, spent, free_used, all_drops,
                                 last_status,
                                 f"经验不足，已开 {opened} 次（下次需 {next_cost}，剩余 {avail_exp}）")

        # 开一次
        time.sleep(0.3)
        res = signed_request(token, pk, "POST", "/qpet/exhibition-hall/chest-open",
                             {"requestId": f"qpet-chest-{uuid.uuid4()}"})
        if not res.get("success"):
            return _multi_result(opened > 0, opened, spent, free_used, all_drops,
                                 last_status,
                                 f"第 {opened+1} 次开启失败: {res.get('message', '')}")

        data = res.get("data") or {}
        drops = data.get("drops") or []
        all_drops.extend(drops)
        _check_rare_drops(drops, user)
        opened += 1
        # 本次消耗：nextCost==0 为免费，否则消耗 nextCost 经验
        if next_cost == 0:
            free_used += 1
        else:
            spent += next_cost
        # 用接口返回的最新状态更新（含更新后的 availableExp / nextCost）
        if isinstance(data.get("status"), dict):
            last_status = data["status"]

    return _multi_result(True, opened, spent, free_used, all_drops, last_status,
                         f"连开完成，共开 {opened} 次（免费 {free_used} 次，消耗 {spent} 经验）")


def _multi_result(success, opened, spent, free_used, all_drops, status, detail):
    """汇总连开结果为统一 dict。"""
    # 按物品名合并数量，拼摘要
    agg = {}
    order = []
    for d in all_drops:
        name = d.get("item_name", "?")
        if name not in agg:
            agg[name] = 0
            order.append(name)
        agg[name] += int(d.get("quantity", 1) or 1)
    reward = "、".join(f"{n}x{agg[n]}" for n in order) if order else "(无掉落)"
    return {
        "success": success,
        "skipped": False,
        "free": False,
        "multi": True,
        "opened": opened,
        "spent": spent,
        "freeCount": free_used,
        "drops": all_drops,
        "reward": reward,
        "availableExp": status.get("availableExp"),
        "detail": detail + f"｜获得：{reward}" if all_drops else detail,
    }


def main():
    user = os.environ.get("QPET_USER")
    pwd = os.environ.get("QPET_PASSWORD")
    args = sys.argv[1:]
    # 解析可选的 --times N（连开模式）；无则单开（仅免费）
    times = None
    positional = []
    it = iter(args)
    for a in it:
        if a == "--times":
            times = int(next(it))
        elif a.startswith("--times="):
            times = int(a.split("=", 1)[1])
        else:
            positional.append(a)

    if not (user and pwd):
        if len(positional) >= 2:
            user, pwd = positional[0], positional[1]
        else:
            print("用法: python qpet_chest.py [user password] [--times N]")
            print("      或设置环境变量 QPET_USER / QPET_PASSWORD 后: python qpet_chest.py [--times N]")
            print("      无 --times：仅开当天免费那次；--times N：连开 N 次（消耗经验）")
            sys.exit(1)

    if times and times > 1:
        res = open_chest_multi(user, pwd, times)
    else:
        res = open_chest_free(user, pwd)
    print(json.dumps(res, ensure_ascii=False))


if __name__ == "__main__":
    main()
