#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""farm_helper.py — 薄农场状态查询助手（设计 §1.2 方案(b) / §5 T04）

复用 qpet_farm_vip.login() 与 signed_request('GET', '/farm')：
  - 凭据从环境变量 QPET_USER / QPET_PASSWORD 读取（禁止 argv 明文）。
  - 成功后仅向 stdout 打印 json.dumps(farm["data"])，由 Node 端解析。
  - 仅只读复用 ~/.qpet_keys 会话（login 优先复用，避免与 daemon 并发写会话）。

用法（由平台 WorkerManager / FarmStatusService 以 env 方式 spawn）：
  QPET_USER=xxx QPET_PASSWORD=yyy python farm_helper.py
"""
import os
import sys
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from qpet_farm_vip import login, signed_request


def main():
    user = os.environ.get("QPET_USER")
    pwd = os.environ.get("QPET_PASSWORD")
    if not user or not pwd:
        print(json.dumps({"success": False, "message": "缺少环境变量 QPET_USER / QPET_PASSWORD"}),
              file=sys.stderr)
        sys.exit(2)

    token, pk = login(user, pwd)
    if not token:
        print(json.dumps({"success": False, "message": "登录失败"}), file=sys.stderr)
        sys.exit(3)

    farm = signed_request(token, pk, "GET", "/farm")
    if not farm.get("success"):
        print(json.dumps({"success": False, "message": farm.get("message", "未知错误")}),
              file=sys.stderr)
        sys.exit(4)

    # 仅输出 farm data 到 stdout，供 Node 解析
    print(json.dumps(farm["data"], ensure_ascii=False))


if __name__ == "__main__":
    main()
