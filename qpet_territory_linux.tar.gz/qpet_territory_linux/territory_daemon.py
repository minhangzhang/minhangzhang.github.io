#!/usr/bin/env python3
"""领地自动抢占 daemon v3 - API版
九天仙域+冥界魔城 | 6:00-次日1:00 | 保护期内零API请求
"""
import sys, json, time
from datetime import datetime, timezone, timedelta

import os as _os; sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
from qpet_farm_vip import login, signed_request
from qpet_auth_guard import AuthError, notify_and_exit

USER = 'guest_1772247226481'
PASS = 'a19971011'
TARGET_MAPS = ['celestial_realm', 'nether_fortress']  # 九天仙域 + 冥界魔城
LOG_FILE = os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'territory_log.jsonl')
STATE_FILE = os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'territory_state.json')  # 持久化保护期状态

STAMINA_THRESHOLD = 30  # 体力低于此值自动喝药
STAMINA_ITEM = {'itemType': 'consumable', 'itemId': 'stamina_medium', 'name': '中瓶体力药水'}

PROTECTION_HOURS = 2  # 保护期时长

BEIJING_TZ = timezone(timedelta(hours=8))

# 全局
token, pk = None, None
protection_until = None  # 本地记录的保护期结束时间(北京)
api_synced = False  # 是否已执行过首次API同步


def now_beijing():
    return datetime.now(BEIJING_TZ)


def is_active_time():
    """6:00 - 次日1:00 之间才活动"""
    h = now_beijing().hour
    return h >= 6 or h < 1


def log(msg):
    ts = now_beijing().strftime('%m-%d %H:%M:%S')
    line = f'[{ts}] {msg}'
    print(line, flush=True)
    with open(LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(line + '\n')


def log_json(data):
    with open(LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(json.dumps(data, ensure_ascii=False) + '\n')


def save_state():
    """持久化保护期状态到文件"""
    if protection_until:
        with open(STATE_FILE, 'w') as f:
            json.dump({'protection_until': protection_until.isoformat()}, f)
    else:
        try:
            import os
            os.remove(STATE_FILE)
        except:
            pass


def load_state():
    """从文件恢复保护期状态"""
    global protection_until
    try:
        with open(STATE_FILE) as f:
            data = json.load(f)
            protection_until = datetime.fromisoformat(data['protection_until'])
            return True
    except:
        return False


def ensure_login():
    global token, pk
    if token and pk:
        test = signed_request(token, pk, 'GET', '/qpet/territory/my')
        if test.get('success'):
            return True
    token, pk = login(USER, PASS)
    return token is not None


def sync_protection_from_api():
    """启动时请求一次API确认当前保护期状态（仅此一次）"""
    global protection_until
    r = signed_request(token, pk, 'GET', '/qpet/territory/my')
    if not r['success']:
        return
    my = r['data']
    if not my:
        protection_until = None
        return
    latest = None
    for t in my:
        occupied_at_str = t.get('occupiedAt', '')
        if not occupied_at_str:
            continue
        try:
            occupied_at = datetime.strptime(occupied_at_str, '%Y-%m-%d %H:%M:%S').replace(tzinfo=BEIJING_TZ)
            prot_end = occupied_at + timedelta(hours=PROTECTION_HOURS)
            if latest is None or prot_end > latest:
                latest = prot_end
        except:
            pass
    protection_until = latest


def get_attackable_slots():
    """获取所有目标地图可打的槽位（含空地）"""
    r = signed_request(token, pk, 'GET', '/qpet/territory/maps')
    if not r['success']:
        return [], 0
    attacks_remaining = r['data'].get('attacksRemaining', 0)
    attackable = []
    for m in r['data']['maps']:
        if m['id'] not in TARGET_MAPS:
            continue
        map_name = m.get('name', m['id'])
        for s in m['slots']:
            if s.get('attackedTodayByMe'):
                continue
            occupier = s.get('occupier')
            attackable.append({
                'mapId': m['id'],
                'mapName': map_name,
                'slotId': s['id'],
                'slotName': s['name'],
                'occupier': occupier['nickname'] if occupier else None,
                'gang': occupier.get('gangName', '-') if occupier else '-',
                'level': occupier.get('level', 0) if occupier else 0,
                'expPerHour': s.get('expPerHour', 0),
                'isEmpty': occupier is None,  # 空地标记
                'occupiedAt': occupier.get('occupiedAt') if occupier else None,  # 占领时间(用于本地算保护期)
            })
    return attackable, attacks_remaining


def prepare_slot(map_id, slot_id):
    """prepare探测一个槽位，返回状态和battleToken"""
    r = signed_request(token, pk, 'POST', '/qpet/territory/prepare', {
        'mapId': map_id, 'slotId': slot_id
    })
    if not r['success']:
        msg = r.get('message', '')
        if '保护期' in msg:
            return {'ok': False, 'reason': 'protection'}
        if '体力' in msg or 'stamina' in msg.lower():
            return {'ok': False, 'reason': 'no_stamina', 'msg': msg}
        return {'ok': False, 'reason': 'error', 'msg': msg}

    data = r['data']
    if data.get('isEmpty'):
        return {'ok': False, 'reason': 'empty'}

    return {'ok': True, 'battleToken': data['battleToken']}


def settle_slot(battle_token):
    """settle结算战斗，传atkWon=true全胜"""
    r = signed_request(token, pk, 'POST', '/qpet/territory/settle', {
        'battleToken': battle_token, 'atkWon': 'true'
    })
    if not r['success']:
        msg = r.get('message', '')
        if '体力' in msg or 'stamina' in msg.lower():
            return {'ok': False, 'reason': 'no_stamina', 'msg': msg}
        return {'ok': False, 'reason': 'settle_fail', 'msg': msg}

    d = r['data']
    return {
        'ok': True,
        'result': d.get('result', '?'),
        'exp': d.get('expReward', 0),
        'coins': d.get('coinReward', 0),
        'stamina': d.get('stamina'),
    }


def check_and_use_stamina():
    """检查体力，低于阈值自动喝中瓶体力药水"""
    r = signed_request(token, pk, 'GET', '/qpet/character')
    if not r['success']:
        return None
    stamina = r['data'].get('stamina', 100)
    if stamina >= STAMINA_THRESHOLD:
        return stamina

    log(f'💊 体力{stamina}<{STAMINA_THRESHOLD}，使用{STAMINA_ITEM["name"]}')
    r2 = signed_request(token, pk, 'POST', '/qpet/inventory/use', {
        'itemType': STAMINA_ITEM['itemType'],
        'itemId': STAMINA_ITEM['itemId'],
        'quantity': 1
    })
    if r2.get('success'):
        new_stamina = r2['data'].get('stamina', '?')
        log(f'  ✅ 恢复50体力，当前{new_stamina}')
        return new_stamina
    else:
        log(f'  ❌ 使用失败: {r2.get("message", "")}')
        return stamina


def do_attack_round():
    """保护期已过：先扫描可打目标，再逐个攻打。优先九天仙域。"""
    # 攻打前检查体力
    stamina = check_and_use_stamina()
    if stamina is not None:
        log(f'❤️ 当前体力: {stamina}')

    slots, attacks_left = get_attackable_slots()

    # 按地图分组统计（仅展示）
    by_map = {}
    for s in slots:
        by_map.setdefault(s['mapName'], 0)
        by_map[s['mapName']] += 1
    map_summary = ' | '.join(f'{k}:{v}个' for k, v in by_map.items())
    log(f'⚔️ 攻击次数剩余:{attacks_left} | {map_summary}')

    if attacks_left <= 0:
        log('  攻击次数用完，等明天0点刷新')
        return 'no_attacks'

    if not slots:
        log('  没有可打目标，60秒后再查')
        return 'no_targets'

    # === 第1步：从maps数据本地判断保护期（不prepare！不消耗体力！）===
    # 按优先级排序：空地最优先(无需战斗) > 九天仙域 > 冥界魔城
    priority = {'celestial_realm': 1, 'nether_fortress': 2}
    slots_sorted = sorted(slots, key=lambda s: (0 if s.get('isEmpty') else priority.get(s['mapId'], 99)))

    now = now_beijing()
    attackable = []
    protected_count = 0
    empty_count = 0
    for s in slots_sorted:
        if s.get('isEmpty'):
            attackable.append(s)
            empty_count += 1
            continue
        # 用occupiedAt本地算保护期
        occupied_at_str = s.get('occupiedAt')
        if occupied_at_str:
            try:
                occupied_at = datetime.strptime(occupied_at_str, '%Y-%m-%d %H:%M:%S').replace(tzinfo=BEIJING_TZ)
                prot_end = occupied_at + timedelta(hours=PROTECTION_HOURS)
                if now < prot_end:
                    protected_count += 1
                    continue
            except:
                pass
        attackable.append(s)

    log(f'  📋 本地扫描完毕: 可打{len(attackable)}个(其中空地{empty_count}) | 保护期{protected_count}个')

    if not attackable:
        log('  全部在保护期，60秒后再查')
        return 'no_targets'

    # === 第2步：逐个攻打（每次重新prepare拿新token，立即settle）===
    attacked = 0
    for s in attackable:
        if attacks_left <= 0:
            break

        tag = s['mapName']
        target = '空地' if s.get('isEmpty') else f'{s["occupier"]}({s["gang"]})'
        log(f'  攻打 [{tag}] {s["slotName"]} ← {target}')

        # 重新prepare拿新token
        prep = prepare_slot(s['mapId'], s['slotId'])
        if not prep['ok']:
            log(f'  ❌ 重新prepare失败: {prep.get("reason","?")}（可能刚进入保护期，跳过）')
            continue

        # 立即settle（battleToken不会过期）
        time.sleep(0.3)
        result = settle_slot(prep['battleToken'])

        if result['ok']:
            is_win = result.get('result') == 'win'
            tag_result = '✅ 赢了！占领成功' if is_win else f'💔 打输了(result={result["result"]})'
            log(f'  {tag_result} | 经验+{result["exp"]} 金币+{result["coins"]}')
            log_json({'type': 'attack', 'time': now_beijing().isoformat(),
                      'map': s['mapName'], 'slot': s['slotName'],
                      'occupier': s['occupier'], 'gang': s['gang'],
                      **{k: v for k, v in result.items() if k != 'ok'}})
            attacks_left -= 1
            if is_win:
                attacked += 1  # 只有赢了才算占领成功
                break  # 占领成功，立刻停止，进入保护期sleep
            else:
                log(f'  ⚠️ 输了不算占领，不进入保护期，继续打下一个')
            # 体力检查
            if result.get('stamina') and result['stamina'] < STAMINA_THRESHOLD:
                log(f'  ⚠️ 体力{result["stamina"]}偏低')
                check_and_use_stamina()
        elif result.get('reason') == 'no_stamina':
            log(f'  💔 体力不足: {result.get("msg","")}')
            check_and_use_stamina()
            # 喝完药重新prepare+settle
            prep2 = prepare_slot(s['mapId'], s['slotId'])
            if prep2['ok']:
                time.sleep(0.3)
                result2 = settle_slot(prep2['battleToken'])
                if result2['ok']:
                    is_win2 = result2.get('result') == 'win'
                    tag2 = '✅ 赢了！占领成功' if is_win2 else f'💔 打输了(result={result2["result"]})'
                    log(f'  {tag2}(补体力后) | 经验+{result2["exp"]} 金币+{result2["coins"]}')
                    log_json({'type': 'attack', 'time': now_beijing().isoformat(),
                              'map': s['mapName'], 'slot': s['slotName'],
                              'occupier': s['occupier'], 'gang': s['gang'],
                              **{k: v for k, v in result2.items() if k != 'ok'}})
                    attacks_left -= 1
                    if is_win2:
                        attacked += 1
                        break  # 占领成功，立刻停止，进入保护期sleep
                else:
                    log(f'  ❌ 补体力后仍失败: {result2.get("msg","")}')
                    break
            else:
                log(f'  ❌ 补体力后prepare失败，跳过')
        else:
            log(f'  ❌ 异常: {result.get("msg", "未知")}（未消耗次数）')

        time.sleep(1.5)

    log(f'  本轮打了{attacked}个')
    return 'done' if attacked > 0 else 'no_targets'


def sleep_precise(seconds, label=''):
    """精确睡眠，支持中途停止（如到活跃时间边界）"""
    # 分段sleep，每60秒检查一次时间窗口
    slept = 0
    while slept < seconds:
        chunk = min(60, seconds - slept)
        time.sleep(chunk)
        slept += chunk
        # 如果非活跃时间了，可以提前退出让主循环处理
        if not is_active_time() and label != 'non_active':
            break


def main():
    global protection_until, api_synced
    log('=' * 50)
    log('🚀 领地自动抢占 daemon v3 启动')
    log('   保护期内零API请求，纯本地计时')
    log(f'   账号: {USER}')
    log(f'   目标: 九天仙域 + 冥界魔城')
    log(f'   活跃时段: 6:00-次日1:00')
    log(f'   体力<{STAMINA_THRESHOLD}自动喝中瓶体力药水')
    log('=' * 50)

    # 1. 恢复持久化状态
    if load_state():
        log(f'📂 恢复保护期状态: 到 {protection_until:%H:%M}')
    else:
        log('📂 无持久化状态，首次启动')

    while True:
        try:
            now = now_beijing()

            # 2. 检查活跃时间
            if not is_active_time():
                h = now.hour
                log(f'💤 非活跃时间(当前{h}点)，1:00-6:00休战')
                # 算到今天6:00（非活跃时间在1:00-6:00之间，6:00就是今天的）
                next_6 = now.replace(hour=6, minute=0, second=0, microsecond=0)
                wait = (next_6 - now).total_seconds()
                sleep_precise(wait, 'non_active')
                continue

            # 3. 检查本地保护期（不请求API！）
            if protection_until and now < protection_until:
                wait_sec = (protection_until - now).total_seconds()
                remain_min = int(wait_sec / 60)
                log(f'🛡️ 本地计时保护中，剩余{remain_min}分钟（{protection_until:%H:%M}解除），零API')
                sleep_precise(wait_sec)
                continue

            # 保护期已过，清除状态
            if protection_until and now >= protection_until:
                log(f'✅ 保护期结束（{protection_until:%H:%M}），恢复活动')
                protection_until = None
                save_state()

            # 4. 确保登录
            if not ensure_login():
                log('❌ 登录失败，5分钟后重试')
                time.sleep(300)
                continue

            # 5. 首次启动时同步一次API确认保护期状态（仅执行一次）
            if not api_synced:
                api_synced = True
                sync_protection_from_api()
                if protection_until and now_beijing() < protection_until:
                    wait_sec = (protection_until - now_beijing()).total_seconds()
                    log(f'📡 首次同步: 仍在保护期，到{protection_until:%H:%M}（剩余{int(wait_sec/60)}分钟）')
                    save_state()
                    sleep_precise(wait_sec)
                    continue

            # 6. 攻打
            result = do_attack_round()

            if result == 'done':
                # 打完了，设置本地保护期（2小时）
                protection_until = now_beijing() + timedelta(hours=PROTECTION_HOURS)
                save_state()
                log(f'🔒 本地记录保护期到 {protection_until:%H:%M}，期间零API')
                continue  # 下轮循环会直接sleep

            elif result == 'no_attacks':
                # 次数用完，休眠到明天0:00（刷新次数）
                now2 = now_beijing()
                tomorrow_0 = (now2 + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
                wait = (tomorrow_0 - now2).total_seconds()
                log(f'  今日次数用完，休眠到明天0:00（{int(wait/3600)}小时后刷新）')
                sleep_precise(wait, 'non_active')
                continue

            elif result == 'no_targets':
                time.sleep(60)
                continue

        except AuthError as ae:
            notify_and_exit(USER, str(ae))
        except KeyboardInterrupt:
            log('手动退出')
            break
        except Exception as e:
            log(f'⚠️ 异常: {e}，30秒后重试')
            import traceback
            traceback.print_exc()
            time.sleep(30)


if __name__ == '__main__':
    main()
