#!/usr/bin/env bash
cd "$(dirname "$0")"
PY="${PYTHON:-python3}"
echo "=== QPet 领地守护 daemon (Linux) ==="
echo "账号: guest (在 territory_daemon.py 顶部修改)"
echo "按 Ctrl+C 停止"
echo ""
exec "$PY" -u territory_daemon.py
