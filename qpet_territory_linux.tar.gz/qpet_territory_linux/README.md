# QPet 领地守护 daemon (Linux)

## 使用方法
1. pip install -r requirements.txt
2. 修改 territory_daemon.py 顶部的 USER/PASS
3. bash start.sh

## 说明
- 自动抢占九天仙域+冥界魔城空地
- 6:00-次日1:00运行，保护期内零请求
- 检测到验证码/封禁自动停止
- token缓存在 keys/ 目录
