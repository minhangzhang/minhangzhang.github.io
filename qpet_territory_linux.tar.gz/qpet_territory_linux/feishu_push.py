#!/usr/bin/env python3
"""飞书推送公共模块 - 带重试+失败兜底"""
import requests, json, time, subprocess

APP_ID = "cli_a92430db13badbc2"
APP_SECRET = "tG2uYm2HHsDnPfylUO45zewhVP1TxacJ"
DEFAULT_CHAT = "oc_a01fbbbaddf0e9011ba863463d1e9079"

def _get_token():
    for attempt in range(3):
        try:
            r = requests.post(
                "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
                json={"app_id": APP_ID, "app_secret": APP_SECRET},
                timeout=10
            )
            d = r.json()
            token = d.get("tenant_access_token")
            if token:
                return token
            print(f"[WARN] 获取token失败({attempt+1}/3): {d}")
        except Exception as e:
            print(f"[WARN] 获取token异常({attempt+1}/3): {e}")
        time.sleep(2)
    return None

def send(text, chat_id=None):
    """发送飞书消息，带3次重试。成功返回True，失败返回False。"""
    chat_id = chat_id or DEFAULT_CHAT
    token = _get_token()
    if not token:
        print("[FAIL] ❌ 飞书token获取失败，消息未发送！")
        print(f"[FAIL] 消息内容: {text[:200]}")
        return False

    for attempt in range(3):
        try:
            r = requests.post(
                "https://open.feishu.cn/open-apis/im/v1/messages",
                headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                params={"receive_id_type": "chat_id"},
                json={"receive_id": chat_id, "msg_type": "text", "content": json.dumps({"text": text})},
                timeout=10
            )
            d = r.json()
            if d.get("code") == 0:
                print("[OK] ✅ 飞书推送成功")
                return True
            print(f"[WARN] 发送失败({attempt+1}/3): code={d.get('code')} msg={d.get('msg')}")
        except Exception as e:
            print(f"[WARN] 发送异常({attempt+1}/3): {e}")
        time.sleep(2)

    print("[FAIL] ❌ 飞书推送3次重试全部失败！")
    print(f"[FAIL] 消息内容: {text[:200]}")
    return False
