#!/usr/bin/env python3
"""QPet农场VIP自动种菜收菜 - ECDSA签名版 (2026-06更新)
签名机制: ECDSA P-256, 每次登录生成新密钥对, 公钥注册到服务器
"""
import time, json, os, urllib.parse, requests, urllib3, sys, random, base64, string
from cryptography.hazmat.primitives.asymmetric import ec, utils
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend

urllib3.disable_warnings()

API_BASE = "https://api.duanwuqiufenmao.top"
API_PREFIX = "/api"
CROP = "vanilla"
TIMEOUT = 30
MAX_RETRY = 2
KEY_DIR = "/root/.qpet_keys"

def req_with_retry(method, url, **kwargs):
    kwargs.setdefault("verify", False)
    kwargs.setdefault("timeout", TIMEOUT)
    for attempt in range(MAX_RETRY):
        try:
            return requests.request(method, url, **kwargs)
        except requests.exceptions.RequestException:
            if attempt < MAX_RETRY - 1:
                time.sleep(1)
            else:
                raise

def generate_nonce(length=16):
    return ''.join(random.choice(string.ascii_lowercase + string.digits) for _ in range(length))

def encodeURIComponent(s):
    return urllib.parse.quote(str(s), safe='')

def build_sign_string(method, path, params, timestamp, nonce):
    """path必须包含/api前缀, 如 /api/farm"""
    m = method.upper()
    p = path.rstrip("/") or "/"
    filtered = {}
    if params:
        for k, v in params.items():
            if k in ("signature", "timestamp", "nonce"): continue
            if v is None: continue
            filtered[k] = v
    parts = []
    for k in sorted(filtered.keys()):
        v = filtered[k]
        if isinstance(v, (dict, list)):
            parts.append(f"{k}={encodeURIComponent(json.dumps(v, separators=(',', ':')))}")
        else:
            parts.append(f"{k}={encodeURIComponent(v)}")
    qs = "&".join(parts)
    return f"{m}{p}{qs}{timestamp}{nonce}"

def ecdsa_sign(private_key, sign_string):
    der_sig = private_key.sign(sign_string.encode(), ec.ECDSA(hashes.SHA256()))
    r, s = utils.decode_dss_signature(der_sig)
    raw = r.to_bytes(32, 'big') + s.to_bytes(32, 'big')
    return base64.urlsafe_b64encode(raw).rstrip(b'=').decode()

def signed_request(token, private_key, method, path, body=None):
    """path不含/api前缀, 如 /farm. 签名和URL都会自动加/api"""
    full_path = f"{API_PREFIX}{path}"  # 签名用完整path: /api/farm
    ts = str(int(time.time() * 1000))
    nonce = generate_nonce()
    
    # POST请求自动注入clientRequestId
    if method.upper() == "POST" and body is None:
        body = {}
    if method.upper() == "POST" and isinstance(body, dict):
        body.setdefault("clientRequestId", str(__import__('uuid').uuid4()))
    
    params = {}
    if body and isinstance(body, dict):
        params.update(body)
    
    sign_str = build_sign_string(method, full_path, params, ts, nonce)
    sig = ecdsa_sign(private_key, sign_str)
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}",
        "x-api-signature": sig,
        "x-api-timestamp": ts,
        "x-api-nonce": nonce
    }
    
    url = f"{API_BASE}{full_path}"
    if method.upper() == "GET":
        return req_with_retry("GET", url, headers=headers).json()
    else:
        return req_with_retry("POST", url, headers=headers, json=body if body else {}).json()

KEY_DIR = "/root/.qpet_keys"

def _key_path(username):
    os.makedirs(KEY_DIR, exist_ok=True)
    return os.path.join(KEY_DIR, f"{username}.pem")

def _token_path(username):
    os.makedirs(KEY_DIR, exist_ok=True)
    return os.path.join(KEY_DIR, f"{username}.token")

def _save_session(username, token, private_key):
    # save key
    pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )
    with open(_key_path(username), "wb") as f:
        f.write(pem)
    # save token
    with open(_token_path(username), "w") as f:
        f.write(token)

def _load_session(username):
    tp = _token_path(username)
    kp = _key_path(username)
    if not os.path.exists(tp) or not os.path.exists(kp):
        return None, None
    try:
        with open(tp, "r") as f:
            token = f.read().strip()
        with open(kp, "rb") as f:
            pk = serialization.load_pem_private_key(f.read(), password=None, backend=default_backend())
        return token, pk
    except Exception:
        return None, None

def _register_new_key(username, token):
    """生成新密钥对，注册公钥到服务器"""
    private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
    pub = private_key.public_key().public_numbers()
    jwk = {
        "kty": "EC", "crv": "P-256",
        "x": base64.urlsafe_b64encode(pub.x.to_bytes(32, 'big')).rstrip(b'=').decode(),
        "y": base64.urlsafe_b64encode(pub.y.to_bytes(32, 'big')).rstrip(b'=').decode(),
        "ext": True
    }
    r = req_with_retry("POST", f"{API_BASE}{API_PREFIX}/auth/register-signing-key",
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"},
        json={"publicKey": jwk})
    d = r.json()
    if not d.get("success"):
        raise Exception(f"签名公钥注册失败: {d.get('message')}")
    _save_session(username, token, private_key)
    return private_key

from cryptography.hazmat.primitives import serialization

def login(username, password):
    from qpet_auth_guard import check_auth_error, AuthError
    # 优先复用已有session（token+key）
    saved_token, saved_pk = _load_session(username)
    if saved_token and saved_pk:
        time.sleep(0.3)
        test = signed_request(saved_token, saved_pk, "GET", "/farm")
        if test.get("success"):
            print(f"[会话] ✅ 复用已有token+密钥")
            return saved_token, saved_pk
        check_auth_error(test, account=username)
        print(f"[会话] 已有session失效({test.get('message','')}), 重新登录")
    
    # 新登录
    r = req_with_retry("POST", f"{API_BASE}{API_PREFIX}/auth/login",
        json={"username": username, "password": password},
        headers={"Content-Type": "application/json"})
    d = r.json()
    check_auth_error(d, account=username)
    if not d.get("success"):
        print(f"[登录失败] {d.get('message')}")
        return None, None
    token = d["data"]["token"]
    user = d["data"].get("user", {})
    print(f"[登录] ✅ {user.get('username', username)}")
    
    pk = _register_new_key(username, token)
    print("[签名] ✅ 新密钥注册成功")
    return token, pk

# ============ _farmProof ============

def get_action_token(token, pk):
    """获取actionToken用于构造_farmProof"""
    r = signed_request(token, pk, "GET", "/farm/ad-bonus/status")
    if r.get("success") and r["data"].get("actionToken"):
        return r["data"]["actionToken"]["token"]
    print(f"[INFO] actionToken为null，尝试无proof操作")
    return None

def make_farm_proof(action, jwt_token):
    """构造_farmProof对象"""
    import uuid as _uuid
    now = int(time.time() * 1000)
    started = now - random.randint(300, 800)
    ended = started + random.randint(200, 600)
    trail = []
    t = started
    for _ in range(random.randint(3, 5)):
        t += random.randint(50, 200)
        trail.append({"x": random.randint(100, 600), "y": random.randint(100, 500), "t": t})
    return {
        "action": action,
        "token": jwt_token,
        "clientActionId": str(_uuid.uuid4()),
        "startedAt": started,
        "endedAt": ended,
        "durationMs": ended - started,
        "visibility": "visible",
        "pointerType": "mouse",
        "trail": trail
    }

# ============ 主逻辑 ============

def run(username, password):
    token, pk = login(username, password)
    if not token:
        sys.exit(1)
    
    time.sleep(0.5)
    
    # 1. 查农场
    farm = signed_request(token, pk, "GET", "/farm")
    if not farm.get("success"):
        print(f"[FATAL] {farm.get('message')}")
        sys.exit(1)
    
    has_harvest = any(s.get("canHarvest") for s in farm["data"]["slots"])
    has_empty = any(s["state"] == "empty" for s in farm["data"]["slots"])
    exp_status = farm.get("data", {}).get("explorationStatus", {})
    can_explore = exp_status.get("canExplore", False) and exp_status.get("todayCount", 99) < exp_status.get("dailyLimit", 50)
    
    # 2. 一键翻地并收菜（合并接口）or 仅收获
    if has_harvest:
        time.sleep(0.5)
        if can_explore:
            # 一键翻地+收菜
            r = signed_request(token, pk, "POST", "/farm/actions/explore-harvest-all", {})
            if r.get("success"):
                d = r["data"]
                print(f"[一键翻地收菜] ✅ 翻{d.get('exploreCount',0)}块 收{d.get('harvestCount',0)}块 经验+{d.get('expGained',0)}")
                for f in d.get("exploreResults", [])[:5]:
                    item = f.get("item", {})
                    new = "🆕" if f.get("isNew") else ""
                    print(f"    💎 {item.get('name','?')} [{item.get('rarity','?')}] ×{f.get('fragmentAmount',1)} {new}")
            else:
                print(f"[一键翻地收菜失败] {r.get('message')}, 降级为仅收获")
                r = signed_request(token, pk, "POST", "/farm/actions/harvest-all", {})
                if r.get("success"):
                    print(f"[一键收获] ✅ 收了{r['data'].get('count',0)}块, 经验+{r['data'].get('expGained',0)}")
        else:
            # 今日翻地次数用完，仅收获
            r = signed_request(token, pk, "POST", "/farm/actions/harvest-all", {})
            if r.get("success"):
                print(f"[一键收获] ✅ 收了{r['data'].get('count',0)}块, 经验+{r['data'].get('expGained',0)}")
            else:
                print(f"[一键收获失败] {r.get('message')}")
        time.sleep(2)
    
    # 3. 种植
    if has_empty or has_harvest:
        time.sleep(2)  # 增加延迟，等服务器更新empty状态
        farm2 = signed_request(token, pk, "GET", "/farm")
        if farm2.get("success") and any(s["state"] == "empty" for s in farm2["data"]["slots"]):
            at3 = get_action_token(token, pk)
            proof3 = make_farm_proof("plant", at3) if at3 else {}
            body = {"cropId": CROP}
            if at3:
                body.update(proof3)
            time.sleep(0.3)
            r = signed_request(token, pk, "POST", "/farm/actions/plant-all", body)
            if r.get("success"):
                print(f"[一键种植] ✅ 种了{r['data'].get('count',0)}块 {CROP}")
            else:
                print(f"[一键种植失败] {r.get('message')}")
    
    # 4. 双倍经验（种完后对growing的地块使用）
    time.sleep(1)
    at2 = get_action_token(token, pk)
    proof2 = make_farm_proof("harvest", at2) if at2 else {}
    time.sleep(0.3)
    r2 = signed_request(token, pk, "POST", "/farm/actions/double-exp-all", proof2 if at2 else {})
    if r2.get("success"):
        print(f"[一键双倍] ✅ {r2['data'].get('count',0)}块双倍经验, 经验+{r2['data'].get('expGained',0)}")
    else:
        print(f"[一键双倍] {r2.get('message')}")
    
    # 5. 状态摘要
    time.sleep(0.5)
    farm3 = signed_request(token, pk, "GET", "/farm")
    if farm3.get("success"):
        for s in farm3["data"]["slots"]:
            state = s["state"]
            crop = s.get("cropId", "?")
            rem = s.get("remainingMinutes", 0)
            h = "✅可收" if s.get("canHarvest") else ""
            print(f"  [{s['slotIndex']}] {state} {crop} {f'{rem}分钟' if state=='growing' else ''} {h}")

if __name__ == "__main__":
    u = sys.argv[1] if len(sys.argv) > 1 else "manq"
    p = sys.argv[2] if len(sys.argv) > 2 else "a19971011"
    run(u, p)
