# QPet 领地自动抢占 (Windows版)

## 快速开始

1. 解压到一个文件夹
2. 双击 `start.bat`
3. 首次运行会自动安装依赖（需要联网）

## 文件说明

| 文件 | 说明 |
|------|------|
| `start.bat` | 启动脚本，双击即可 |
| `territory_daemon.py` | 主程序 |
| `qpet_farm_vip.py` | API核心（ECDSA签名） |
| `qpet_auth_guard.py` | 验证码/封号检测 |
| `requirements.txt` | Python依赖 |

## 功能

- 自动抢占 **九天仙域 + 冥界魔城** 地盘
- 活跃时段 6:00 ~ 次日1:00，夜间自动休战
- 保护期内零API请求（本地计时）
- 体力<30自动喝中瓶体力药水
- 检测到验证码/封号 → 弹窗提示并停止
- 日志写到同目录 `territory_log.txt`

## 换账号

编辑 `start.bat` 最后一行：
```
python territory_daemon.py 你的用户名 你的密码
```

## 前置条件

- Windows 7+
- Python 3.8+（勾选 Add to PATH）
- 安装时会自动 `pip install requests cryptography`

## 注意

- 密钥文件存在 `C:\Users\你的用户名\.qpet_keys\`
- 不要同时开多个实例抢同一个号
- Ctrl+C 停止
