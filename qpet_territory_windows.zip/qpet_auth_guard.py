#!/usr/bin/env python3
"""QPet 认证异常守卫 - 检测验证码/封号等认证类异常，弹出Windows提示并退出"""
import json, time, os, tempfile

CAPTCHA_KEYWORDS = [
    "captcha", "ticket", "randstr", "天御",
    "验证码", "图像验证", "人机验证", "verify_code",
    "needCaptcha", "captchaRequired", "need_verify",
    "封禁", "已封号", "account suspended", "banned",
    "account_banned", "违规",
]

# Windows版：临时文件目录
FAIL_COUNTER_DIR = os.path.join(tempfile.gettempdir(), "qpet_auth_fail")


class AuthError(Exception):
    pass


def _safe_name(account):
    return account.replace("@", "_").replace("/", "_").replace("\\", "_")

def _read_fail_count(account):
    path = os.path.join(FAIL_COUNTER_DIR, _safe_name(account))
    try:
        with open(path) as f:
            return int(f.read().strip() or "0")
    except Exception:
        return 0

def _write_fail_count(account, count):
    os.makedirs(FAIL_COUNTER_DIR, exist_ok=True)
    path = os.path.join(FAIL_COUNTER_DIR, _safe_name(account))
    try:
        with open(path, "w") as f:
            f.write(str(count))
    except Exception:
        pass

def _reset_fail_count(account):
    _write_fail_count(account, 0)

def _contains_keyword(text):
    if not text:
        return False
    text_lower = text.lower()
    for kw in CAPTCHA_KEYWORDS:
        if kw.lower() in text_lower:
            return kw
    return False

def check_auth_error(resp, account="unknown"):
    if not resp:
        return
    if isinstance(resp, dict):
        text = json.dumps(resp, ensure_ascii=False)
        success = resp.get("success")
        message = resp.get("message", "")
    else:
        text = str(resp)
        success = None
        message = ""

    kw = _contains_keyword(text)
    if kw:
        _reset_fail_count(account)
        raise AuthError(f"[{account}] 检测到验证码/封号信号(关键词:{kw}): {message or text[:200]}")

    if success is False and account != "unknown":
        auth_fail_hints = ["login", "auth", "token", "unauthorized", "登录", "认证", "签名", "凭据"]
        if any(h.lower() in text.lower() for h in auth_fail_hints):
            count = _read_fail_count(account) + 1
            _write_fail_count(account, count)
            if count >= 3:
                _reset_fail_count(account)
                raise AuthError(f"[{account}] 连续{count}次认证失败: {message or text[:200]}")
        else:
            _reset_fail_count(account)
    elif success is True:
        _reset_fail_count(account)

def notify_and_exit(account, reason):
    """弹出Windows对话框提示并退出"""
    msg = f"QPet自动化异常停止\n账号: {account}\n原因: {reason}\n时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n请手动检查。"
    print(f"\n{'='*50}")
    print(f"认证异常，停止任务: {account}")
    print(f"   {reason}")
    print(f"{'='*50}")

    # Windows弹出消息框
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, msg, "QPet抢地盘 - 异常停止", 0x10)  # MB_ICONERROR
    except Exception:
        pass  # 非Windows平台静默

    os._exit(1)
