@echo off
chcp 65001 >nul 2>&1
title QPet 领地自动抢占

echo ========================================
echo   QPet 领地自动抢占 (Windows)
echo ========================================
echo.

REM 检查Python
where python >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 未找到Python，请先安装 Python 3.8+
    echo 下载地址: https://www.python.org/downloads/
    echo 安装时请勾选 "Add Python to PATH"
    pause
    exit /b 1
)

REM 检查依赖
python -c "import requests, cryptography" >nul 2>&1
if %errorlevel% neq 0 (
    echo [安装依赖] 首次运行，正在安装依赖...
    pip install -r "%~dp0requirements.txt"
    if %errorlevel% neq 0 (
        echo [错误] 依赖安装失败，请手动执行:
        echo   pip install requests cryptography
        pause
        exit /b 1
    )
    echo [完成] 依赖安装成功
    echo.
)

REM 启动
echo 正在启动领地抢占...
echo 账号: guest_1772247226481
echo 按 Ctrl+C 停止
echo.
python "%~dp0territory_daemon.py" guest_1772247226481 a19971011

pause
