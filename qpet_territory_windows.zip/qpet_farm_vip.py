#!/usr/bin/env python3
"""QPet农场VIP自动种菜收菜 - ECDSA签名版 (Windows版 2026-07)
签名机制: ECDSA P-256, 每次登录生成新密钥对, 公钥注册到服务器
"""
import time, json, os, urllib.parse, requests, urllib3, sys, random, base64, string
from cryptography.hazmat.primitives.asymmetric import ec, utils
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization

urllib3.disable_warnings()

API_BASE = "https://api.duanwuqiufenmao.top"
API_PREFIX = "/api"
CROP = "vanilla"
TIMEOUT = 30
MAX_RETRY = 2

# Windows版：密钥存到用户目录
KEY_DIR = os.path.join(os.path.expanduser("~"), ".qpet_keys")

def req_with_retry(method, url, **kwargs):
    kwargs.setdefault("verify", False)
    kwargs.setdefault("timeout", TIMEOUT)
    for attempt in range(MAX_RETRY):
        try:
            return requests.request(method, url, **kwargs)
        except requests.exceptions.RequestException:
            if attempt < MAX_RETRY - 1:
                time.sleep(1)
            else:
                raise

def generate_nonce(length=16):
    return ''.join(random.choice(string.ascii_lowercase + string.digits) for _ in range(length))

def encodeURIComponent(s):
    return urllib.parse.quote(str(s), safe='')

def build_sign_string(method, path, params, timestamp, nonce):
    m = method.upper()
    p = path.rstrip("/") or "/"
    filtered = {}
    if params:
        for k, v in params.items():
            if k in ("signature", "timestamp", "nonce"): continue
            if v is None: continue
            filtered[k] = v
    parts = []
    for k in sorted(filtered.keys()):
        v = filtered[k]
        if isinstance(v, bool):
            parts.append(f"{k}={'true' if v else 'false'}")
        elif isinstance(v, (dict, list)):
            parts.append(f"{k}={encodeURIComponent(json.dumps(v, separators=(',', ':')))}")
        else:
            parts.append(f"{k}={encodeURIComponent(v)}")
    qs = "&".join(parts)
    return f"{m}{p}{qs}{timestamp}{nonce}"

def ecdsa_sign(private_key, sign_string):
    der_sig = private_key.sign(sign_string.encode(), ec.ECDSA(hashes.SHA256()))
    r, s = utils.decode_dss_signature(der_sig)
    raw = r.to_bytes(32, 'big') + s.to_bytes(32, 'big')
    return base64.urlsafe_b64encode(raw).rstrip(b'=').decode()

def signed_request(token, private_key, method, path, body=None, query=None):
    full_path = f"{API_PREFIX}{path}"
    ts = str(int(time.time() * 1000))
    nonce = generate_nonce()

    if method.upper() == "POST" and body is None:
        body = {}
    if method.upper() == "POST" and isinstance(body, dict):
        body.setdefault("clientRequestId", str(__import__('uuid').uuid4()))

    params = {}
    if body and isinstance(body, dict):
        params.update(body)
    if query and isinstance(query, dict):
        params.update(query)

    sign_str = build_sign_string(method, full_path, params, ts, nonce)
    sig = ecdsa_sign(private_key, sign_str)

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}",
        "x-api-signature": sig,
        "x-api-timestamp": ts,
        "x-api-nonce": nonce
    }

    url = f"{API_BASE}{full_path}"
    if method.upper() == "GET":
        if query:
            qs = "&".join(
                f"{k}={'true' if v is True else 'false' if v is False else encodeURIComponent(v)}"
                for k, v in sorted(query.items()) if v is not None
            )
            if qs:
                url = f"{url}?{qs}"
        return req_with_retry("GET", url, headers=headers).json()
    else:
        return req_with_retry("POST", url, headers=headers, json=body if body else {}).json()

def _safe_name(username):
    return username.replace("@", "_").replace("/", "_").replace("\\", "_")

def _key_path(username):
    os.makedirs(KEY_DIR, exist_ok=True)
    return os.path.join(KEY_DIR, f"{_safe_name(username)}.pem")

def _token_path(username):
    os.makedirs(KEY_DIR, exist_ok=True)
    return os.path.join(KEY_DIR, f"{_safe_name(username)}.token")

def _save_session(username, token, private_key):
    pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )
    with open(_key_path(username), "wb") as f:
        f.write(pem)
    with open(_token_path(username), "w") as f:
        f.write(token)

def _load_session(username):
    tp = _token_path(username)
    kp = _key_path(username)
    if not os.path.exists(tp) or not os.path.exists(kp):
        return None, None
    try:
        with open(tp, "r") as f:
            token = f.read().strip()
        with open(kp, "rb") as f:
            pk = serialization.load_pem_private_key(f.read(), password=None, backend=default_backend())
        return token, pk
    except Exception:
        return None, None

def _register_new_key(username, token):
    private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
    pub = private_key.public_key().public_numbers()
    jwk = {
        "kty": "EC", "crv": "P-256",
        "x": base64.urlsafe_b64encode(pub.x.to_bytes(32, 'big')).rstrip(b'=').decode(),
        "y": base64.urlsafe_b64encode(pub.y.to_bytes(32, 'big')).rstrip(b'=').decode(),
        "ext": True
    }
    r = req_with_retry("POST", f"{API_BASE}{API_PREFIX}/auth/register-signing-key",
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"},
        json={"publicKey": jwk})
    d = r.json()
    if not d.get("success"):
        raise Exception(f"签名公钥注册失败: {d.get('message')}")
    _save_session(username, token, private_key)
    return private_key

def login(username, password):
    from qpet_auth_guard import check_auth_error
    saved_token, saved_pk = _load_session(username)
    if saved_token and saved_pk:
        time.sleep(0.3)
        test = signed_request(saved_token, saved_pk, "GET", "/farm")
        if test.get("success"):
            print(f"[会话] 复用已有token+密钥")
            return saved_token, saved_pk
        check_auth_error(test, account=username)
        print(f"[会话] 已有session失效({test.get('message','')}), 重新登录")

    r = req_with_retry("POST", f"{API_BASE}{API_PREFIX}/auth/login",
        json={"username": username, "password": password},
        headers={"Content-Type": "application/json"})
    d = r.json()
    check_auth_error(d, account=username)
    if not d.get("success"):
        print(f"[登录失败] {d.get('message')}")
        return None, None
    token = d["data"]["token"]
    user = d["data"].get("user", {})
    print(f"[登录] {user.get('username', username)}")

    pk = _register_new_key(username, token)
    print("[签名] 新密钥注册成功")
    return token, pk
