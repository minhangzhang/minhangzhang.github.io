#!/usr/bin/env python3
"""领地自动抢占 daemon v3 - Windows版 (2026-07)
九天仙域+冥界魔城 | 6:00-次日1:00 | 保护期内零API请求

用法:
    python territory_daemon.py [用户名] [密码]
    python territory_daemon.py guest_1772247226481 a19971011

不传参数则用下方默认账号。
双击 start.bat 可一键启动。
"""
import sys, os, json, time
from datetime import datetime, timezone, timedelta

# Windows版：路径自适应
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)

from qpet_farm_vip import login, signed_request
from qpet_auth_guard import AuthError, notify_and_exit

# ── 配置 ──
USER = sys.argv[1] if len(sys.argv) > 1 else 'guest_1772247226481'
PASS = sys.argv[2] if len(sys.argv) > 2 else 'a19971011'
TARGET_MAPS = ['celestial_realm', 'nether_fortress']  # 九天仙域 + 冥界魔城
LOG_FILE = os.path.join(SCRIPT_DIR, 'territory_log.txt')
STATE_FILE = os.path.join(SCRIPT_DIR, 'territory_state.json')

STAMINA_THRESHOLD = 30
STAMINA_ITEM = {'itemType': 'consumable', 'itemId': 'stamina_medium', 'name': '中瓶体力药水'}
PROTECTION_HOURS = 2

BEIJING_TZ = timezone(timedelta(hours=8))

token, pk = None, None
protection_until = None
api_synced = False


def now_beijing():
    return datetime.now(BEIJING_TZ)

def is_active_time():
    h = now_beijing().hour
    return h >= 6 or h < 1

def log(msg):
    ts = now_beijing().strftime('%m-%d %H:%M:%S')
    line = f'[{ts}] {msg}'
    print(line, flush=True)
    try:
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(line + '\n')
    except Exception:
        pass

def log_json(data):
    try:
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(json.dumps(data, ensure_ascii=False) + '\n')
    except Exception:
        pass

def save_state():
    if protection_until:
        try:
            with open(STATE_FILE, 'w') as f:
                json.dump({'protection_until': protection_until.isoformat()}, f)
        except Exception:
            pass
    else:
        try:
            os.remove(STATE_FILE)
        except Exception:
            pass

def load_state():
    global protection_until
    try:
        with open(STATE_FILE) as f:
            data = json.load(f)
            protection_until = datetime.fromisoformat(data['protection_until'])
            return True
    except Exception:
        return False

def ensure_login():
    global token, pk
    if token and pk:
        test = signed_request(token, pk, 'GET', '/qpet/territory/my')
        if test.get('success'):
            return True
    token, pk = login(USER, PASS)
    return token is not None

def sync_protection_from_api():
    global protection_until
    r = signed_request(token, pk, 'GET', '/qpet/territory/my')
    if not r['success']:
        return
    my = r['data']
    if not my:
        protection_until = None
        return
    latest = None
    for t in my:
        occupied_at_str = t.get('occupiedAt', '')
        if not occupied_at_str:
            continue
        try:
            occupied_at = datetime.strptime(occupied_at_str, '%Y-%m-%d %H:%M:%S').replace(tzinfo=BEIJING_TZ)
            prot_end = occupied_at + timedelta(hours=PROTECTION_HOURS)
            if latest is None or prot_end > latest:
                latest = prot_end
        except Exception:
            pass
    protection_until = latest

def get_attackable_slots():
    r = signed_request(token, pk, 'GET', '/qpet/territory/maps')
    if not r['success']:
        return [], 0
    attacks_remaining = r['data'].get('attacksRemaining', 0)
    attackable = []
    for m in r['data']['maps']:
        if m['id'] not in TARGET_MAPS:
            continue
        map_name = m.get('name', m['id'])
        for s in m['slots']:
            if s.get('attackedTodayByMe'):
                continue
            # 用服务器新增的 canAttack 字段判断（更准确）
            if 'canAttack' in s and not s.get('canAttack'):
                continue
            occupier = s.get('occupier')
            attackable.append({
                'mapId': m['id'],
                'mapName': map_name,
                'slotId': s['id'],
                'slotName': s['name'],
                'occupier': occupier['nickname'] if occupier else None,
                'gang': occupier.get('gangName', '-') if occupier else '-',
                'level': occupier.get('level', 0) if occupier else 0,
                'expPerHour': s.get('expPerHour', 0),
                'isEmpty': occupier is None,
                'occupiedAt': occupier.get('occupiedAt') if occupier else None,
                'protectionRemainingSeconds': s.get('protectionRemainingSeconds', 0),
            })
    return attackable, attacks_remaining

def prepare_slot(map_id, slot_id):
    r = signed_request(token, pk, 'POST', '/qpet/territory/prepare', {
        'mapId': map_id, 'slotId': slot_id
    })
    if not r['success']:
        msg = r.get('message', '')
        if '保护期' in msg:
            return {'ok': False, 'reason': 'protection'}
        if '体力' in msg or 'stamina' in msg.lower():
            return {'ok': False, 'reason': 'no_stamina', 'msg': msg}
        return {'ok': False, 'reason': 'error', 'msg': msg}
    data = r['data']
    if data.get('isEmpty'):
        return {'ok': False, 'reason': 'empty'}
    return {'ok': True, 'battleToken': data['battleToken']}

def settle_slot(battle_token):
    r = signed_request(token, pk, 'POST', '/qpet/territory/settle', {
        'battleToken': battle_token, 'atkWon': 'true'
    })
    if not r['success']:
        msg = r.get('message', '')
        if '体力' in msg or 'stamina' in msg.lower():
            return {'ok': False, 'reason': 'no_stamina', 'msg': msg}
        return {'ok': False, 'reason': 'settle_fail', 'msg': msg}
    d = r['data']
    return {
        'ok': True,
        'result': d.get('result', '?'),
        'exp': d.get('expReward', 0),
        'coins': d.get('coinReward', 0),
        'stamina': d.get('stamina'),
    }

def check_and_use_stamina():
    r = signed_request(token, pk, 'GET', '/qpet/character')
    if not r['success']:
        return None
    stamina = r['data'].get('stamina', 100)
    if stamina >= STAMINA_THRESHOLD:
        return stamina
    log(f'体力{stamina}<{STAMINA_THRESHOLD}，使用{STAMINA_ITEM["name"]}')
    r2 = signed_request(token, pk, 'POST', '/qpet/inventory/use', {
        'itemType': STAMINA_ITEM['itemType'],
        'itemId': STAMINA_ITEM['itemId'],
        'quantity': 1
    })
    if r2.get('success'):
        new_stamina = r2['data'].get('stamina', '?')
        log(f'  恢复50体力，当前{new_stamina}')
        return new_stamina
    else:
        log(f'  使用失败: {r2.get("message", "")}')
        return stamina

def do_attack_round():
    stamina = check_and_use_stamina()
    if stamina is not None:
        log(f'当前体力: {stamina}')

    slots, attacks_left = get_attackable_slots()
    by_map = {}
    for s in slots:
        by_map.setdefault(s['mapName'], 0)
        by_map[s['mapName']] += 1
    map_summary = ' | '.join(f'{k}:{v}个' for k, v in by_map.items())
    log(f'攻击次数剩余:{attacks_left} | {map_summary}')

    if attacks_left <= 0:
        log('  攻击次数用完，等明天0点刷新')
        return 'no_attacks'
    if not slots:
        log('  没有可打目标，60秒后再查')
        return 'no_targets'

    priority = {'celestial_realm': 1, 'nether_fortress': 2}
    slots_sorted = sorted(slots, key=lambda s: (0 if s.get('isEmpty') else priority.get(s['mapId'], 99)))

    now = now_beijing()
    attackable = []
    protected_count = 0
    empty_count = 0
    for s in slots_sorted:
        if s.get('isEmpty'):
            attackable.append(s)
            empty_count += 1
            continue
        # 优先用服务器返回的 protectionRemainingSeconds
        prot_remain = s.get('protectionRemainingSeconds', 0)
        if prot_remain and prot_remain > 0:
            protected_count += 1
            continue
        # 回退：用 occupiedAt 本地算
        occupied_at_str = s.get('occupiedAt')
        if occupied_at_str:
            try:
                occupied_at = datetime.strptime(occupied_at_str, '%Y-%m-%d %H:%M:%S').replace(tzinfo=BEIJING_TZ)
                prot_end = occupied_at + timedelta(hours=PROTECTION_HOURS)
                if now < prot_end:
                    protected_count += 1
                    continue
            except Exception:
                pass
        attackable.append(s)

    log(f'  本地扫描: 可打{len(attackable)}个(空地{empty_count}) | 保护期{protected_count}个')
    if not attackable:
        log('  全部在保护期，60秒后再查')
        return 'no_targets'

    attacked = 0
    for s in attackable:
        if attacks_left <= 0:
            break
        tag = s['mapName']
        target = '空地' if s.get('isEmpty') else f'{s["occupier"]}({s["gang"]})'
        log(f'  攻打 [{tag}] {s["slotName"]} <- {target}')

        prep = prepare_slot(s['mapId'], s['slotId'])
        if not prep['ok']:
            log(f'  prepare失败: {prep.get("reason","?")}，跳过')
            continue

        time.sleep(0.3)
        result = settle_slot(prep['battleToken'])

        if result['ok']:
            is_win = result.get('result') == 'win'
            tag_result = '赢了! 占领成功' if is_win else f'打输了(result={result["result"]})'
            log(f'  {tag_result} | 经验+{result["exp"]} 金币+{result["coins"]}')
            log_json({'type': 'attack', 'time': now_beijing().isoformat(),
                      'map': s['mapName'], 'slot': s['slotName'],
                      'occupier': s['occupier'], 'gang': s['gang'],
                      **{k: v for k, v in result.items() if k != 'ok'}})
            attacks_left -= 1
            if is_win:
                attacked += 1
                break
            else:
                log(f'  输了不算占领，继续打下一个')
            if result.get('stamina') and result['stamina'] < STAMINA_THRESHOLD:
                log(f'  体力{result["stamina"]}偏低')
                check_and_use_stamina()
        elif result.get('reason') == 'no_stamina':
            log(f'  体力不足: {result.get("msg","")}')
            check_and_use_stamina()
            prep2 = prepare_slot(s['mapId'], s['slotId'])
            if prep2['ok']:
                time.sleep(0.3)
                result2 = settle_slot(prep2['battleToken'])
                if result2['ok']:
                    is_win2 = result2.get('result') == 'win'
                    tag2 = '赢了! 占领成功' if is_win2 else f'打输了(result={result2["result"]})'
                    log(f'  {tag2}(补体力后) | 经验+{result2["exp"]} 金币+{result2["coins"]}')
                    log_json({'type': 'attack', 'time': now_beijing().isoformat(),
                              'map': s['mapName'], 'slot': s['slotName'],
                              'occupier': s['occupier'], 'gang': s['gang'],
                              **{k: v for k, v in result2.items() if k != 'ok'}})
                    attacks_left -= 1
                    if is_win2:
                        attacked += 1
                        break
                else:
                    log(f'  补体力后仍失败: {result2.get("msg","")}')
                    break
            else:
                log(f'  补体力后prepare失败，跳过')
        else:
            log(f'  异常: {result.get("msg", "未知")}')

        time.sleep(1.5)

    log(f'  本轮打了{attacked}个')
    return 'done' if attacked > 0 else 'no_targets'

def sleep_precise(seconds, label=''):
    slept = 0
    while slept < seconds:
        chunk = min(60, seconds - slept)
        time.sleep(chunk)
        slept += chunk
        if not is_active_time() and label != 'non_active':
            break

def main():
    global protection_until, api_synced
    log('=' * 50)
    log('领地自动抢占 daemon v3 (Windows) 启动')
    log(f'   账号: {USER}')
    log(f'   目标: 九天仙域 + 冥界魔城')
    log(f'   活跃时段: 6:00-次日1:00')
    log(f'   体力<{STAMINA_THRESHOLD}自动喝中瓶体力药水')
    log(f'   日志: {LOG_FILE}')
    log('=' * 50)

    if load_state():
        log(f'恢复保护期状态: 到 {protection_until:%H:%M}')
    else:
        log('无持久化状态，首次启动')

    while True:
        try:
            now = now_beijing()
            if not is_active_time():
                h = now.hour
                log(f'非活跃时间(当前{h}点)，1:00-6:00休战')
                next_6 = now.replace(hour=6, minute=0, second=0, microsecond=0)
                wait = (next_6 - now).total_seconds()
                sleep_precise(wait, 'non_active')
                continue

            if protection_until and now < protection_until:
                wait_sec = (protection_until - now).total_seconds()
                remain_min = int(wait_sec / 60)
                log(f'本地计时保护中，剩余{remain_min}分钟（{protection_until:%H:%M}解除）')
                sleep_precise(wait_sec)
                continue

            if protection_until and now >= protection_until:
                log(f'保护期结束（{protection_until:%H:%M}），恢复活动')
                protection_until = None
                save_state()

            if not ensure_login():
                log('登录失败，5分钟后重试')
                time.sleep(300)
                continue

            if not api_synced:
                api_synced = True
                sync_protection_from_api()
                if protection_until and now_beijing() < protection_until:
                    wait_sec = (protection_until - now_beijing()).total_seconds()
                    log(f'首次同步: 仍在保护期，到{protection_until:%H:%M}（剩余{int(wait_sec/60)}分钟）')
                    save_state()
                    sleep_precise(wait_sec)
                    continue

            result = do_attack_round()

            if result == 'done':
                protection_until = now_beijing() + timedelta(hours=PROTECTION_HOURS)
                save_state()
                log(f'本地记录保护期到 {protection_until:%H:%M}')
                continue
            elif result == 'no_attacks':
                now2 = now_beijing()
                tomorrow_0 = (now2 + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
                wait = (tomorrow_0 - now2).total_seconds()
                log(f'  今日次数用完，休眠到明天0:00（{int(wait/3600)}小时后刷新）')
                sleep_precise(wait, 'non_active')
                continue
            elif result == 'no_targets':
                time.sleep(60)
                continue

        except AuthError as ae:
            notify_and_exit(USER, str(ae))
        except KeyboardInterrupt:
            log('手动退出')
            print('\n按任意键退出...')
            try:
                import msvcrt
                msvcrt.getch()
            except ImportError:
                input()
            break
        except Exception as e:
            log(f'异常: {e}，30秒后重试')
            import traceback
            traceback.print_exc()
            time.sleep(30)

if __name__ == '__main__':
    main()
